"""
Sovereign-Grade Problem Decomposition System - Decomposition Engine

This module orchestrates problem decomposition using multiple strategies to create
verifiable sub-problems with clear success criteria and dependency relationships.
"""

import logging
from typing import List, Dict, Any, Optional
from abc import ABC, abstractmethod

from sovereign_data_models import (
    ProblemDefinition, SubProblem, DecompositionPlan, DecompositionStrategy,
    SubProblemType, ComplexityScore, SuccessCriterion, DependencyGraph,
    QualityScores, ValidationCheckpoint, generate_id
)
from problem_analyzer import ProblemAnalyzer

logger = logging.getLogger(__name__)


class DecompositionStrategyBase(ABC):
    """Base class for decomposition strategies."""
    
    @abstractmethod
    def decompose(self, problem: ProblemDefinition) -> List[SubProblem]:
        """
        Decompose problem into sub-problems.
        
        Args:
            problem: The problem to decompose
            
        Returns:
            List of SubProblem objects
        """
        pass
    
    @abstractmethod
    def get_strategy_name(self) -> str:
        """Get the name of this strategy."""
        pass


class SemanticDecomposition(DecompositionStrategyBase):
    """Decomposes based on semantic concept relationships."""
    
    def get_strategy_name(self) -> str:
        return "semantic"
    
    def decompose(self, problem: ProblemDefinition) -> List[SubProblem]:
        """
        Identifies semantic clusters and creates sub-problems.
        
        Analyzes the problem description to identify distinct semantic concepts
        and creates sub-problems around each concept cluster.
        """
        logger.info(f"Semantic decomposition for problem: {problem.id}")
        
        sub_problems = []
        text = problem.description.lower()
        
        # Identify semantic concepts based on problem type
        if problem.problem_type.value == "research":
            concepts = self._identify_research_concepts(problem)
        elif problem.problem_type.value == "implementation":
            concepts = self._identify_implementation_concepts(problem)
        elif problem.problem_type.value == "analysis":
            concepts = self._identify_analysis_concepts(problem)
        elif problem.problem_type.value == "optimization":
            concepts = self._identify_optimization_concepts(problem)
        elif problem.problem_type.value == "design":
            concepts = self._identify_design_concepts(problem)
        else:
            concepts = self._identify_general_concepts(problem)
        
        # Create sub-problems for each concept
        for i, concept in enumerate(concepts):
            sub_problem = SubProblem(
                id=generate_id("subproblem"),
                parent_id=problem.id,
                title=concept['title'],
                description=concept['description'],
                type=concept['type'],
                complexity_score=self._estimate_complexity(concept, problem),
                dependencies=concept.get('dependencies', []),
                success_criteria=[
                    SuccessCriterion(
                        id=generate_id("criterion"),
                        description=concept['success_criterion'],
                        metric=concept.get('metric', 'completion'),
                        threshold=concept.get('threshold', 1.0),
                        validation_method=concept.get('validation', 'review')
                    )
                ],
                validation_gauntlet="coherence",
                priority=concept.get('priority', 5),
                estimated_effort=concept.get('effort', 8)
            )
            sub_problems.append(sub_problem)
        
        logger.info(f"Created {len(sub_problems)} sub-problems via semantic decomposition")
        return sub_problems
    
    def _identify_research_concepts(self, problem: ProblemDefinition) -> List[Dict[str, Any]]:
        """Identify concepts for research problems."""
        return [
            {
                'title': 'Literature Review',
                'description': f'Review existing research and literature related to: {problem.title}',
                'type': SubProblemType.RESEARCH,
                'success_criterion': 'Comprehensive literature review completed',
                'metric': 'coverage',
                'threshold': 0.9,
                'validation': 'peer_review',
                'priority': 8,
                'effort': 16
            },
            {
                'title': 'Hypothesis Formation',
                'description': 'Develop testable hypotheses based on problem analysis',
                'type': SubProblemType.ANALYSIS,
                'success_criterion': 'Clear, testable hypotheses defined',
                'metric': 'clarity',
                'threshold': 0.85,
                'validation': 'expert_review',
                'priority': 7,
                'effort': 8
            },
            {
                'title': 'Experimental Design',
                'description': 'Design experiments to test hypotheses',
                'type': SubProblemType.RESEARCH,
                'success_criterion': 'Experimental methodology documented',
                'metric': 'completeness',
                'threshold': 1.0,
                'validation': 'methodology_review',
                'priority': 6,
                'effort': 12
            },
            {
                'title': 'Data Collection and Analysis',
                'description': 'Collect data and perform analysis',
                'type': SubProblemType.ANALYSIS,
                'success_criterion': 'Data collected and analyzed',
                'metric': 'statistical_significance',
                'threshold': 0.95,
                'validation': 'statistical_test',
                'priority': 5,
                'effort': 20
            }
        ]
    
    def _identify_implementation_concepts(self, problem: ProblemDefinition) -> List[Dict[str, Any]]:
        """Identify concepts for implementation problems."""
        return [
            {
                'title': 'Requirements Analysis',
                'description': f'Analyze and document requirements for: {problem.title}',
                'type': SubProblemType.ANALYSIS,
                'success_criterion': 'All requirements documented and validated',
                'metric': 'completeness',
                'threshold': 1.0,
                'validation': 'requirements_review',
                'priority': 9,
                'effort': 8
            },
            {
                'title': 'Architecture Design',
                'description': 'Design system architecture and components',
                'type': SubProblemType.ANALYSIS,
                'success_criterion': 'Architecture design approved',
                'metric': 'design_quality',
                'threshold': 0.9,
                'validation': 'design_review',
                'priority': 8,
                'effort': 12
            },
            {
                'title': 'Core Implementation',
                'description': 'Implement core functionality',
                'type': SubProblemType.IMPLEMENTATION,
                'success_criterion': 'Core features implemented and tested',
                'metric': 'test_coverage',
                'threshold': 0.8,
                'validation': 'automated_testing',
                'priority': 7,
                'effort': 40
            },
            {
                'title': 'Integration and Testing',
                'description': 'Integrate components and perform testing',
                'type': SubProblemType.VALIDATION,
                'success_criterion': 'All integration tests passing',
                'metric': 'test_pass_rate',
                'threshold': 0.95,
                'validation': 'automated_testing',
                'priority': 6,
                'effort': 16
            }
        ]
    
    def _identify_analysis_concepts(self, problem: ProblemDefinition) -> List[Dict[str, Any]]:
        """Identify concepts for analysis problems."""
        return [
            {
                'title': 'Data Collection',
                'description': f'Collect relevant data for analysis of: {problem.title}',
                'type': SubProblemType.RESEARCH,
                'success_criterion': 'Sufficient data collected',
                'metric': 'data_completeness',
                'threshold': 0.9,
                'validation': 'data_review',
                'priority': 8,
                'effort': 12
            },
            {
                'title': 'Data Processing',
                'description': 'Clean and process collected data',
                'type': SubProblemType.IMPLEMENTATION,
                'success_criterion': 'Data processed and validated',
                'metric': 'data_quality',
                'threshold': 0.95,
                'validation': 'quality_check',
                'priority': 7,
                'effort': 16
            },
            {
                'title': 'Analysis Execution',
                'description': 'Perform detailed analysis',
                'type': SubProblemType.ANALYSIS,
                'success_criterion': 'Analysis completed with insights',
                'metric': 'insight_quality',
                'threshold': 0.8,
                'validation': 'expert_review',
                'priority': 6,
                'effort': 20
            },
            {
                'title': 'Reporting and Recommendations',
                'description': 'Document findings and provide recommendations',
                'type': SubProblemType.ANALYSIS,
                'success_criterion': 'Report completed with actionable recommendations',
                'metric': 'actionability',
                'threshold': 0.85,
                'validation': 'stakeholder_review',
                'priority': 5,
                'effort': 12
            }
        ]
    
    def _identify_optimization_concepts(self, problem: ProblemDefinition) -> List[Dict[str, Any]]:
        """Identify concepts for optimization problems."""
        return [
            {
                'title': 'Baseline Measurement',
                'description': f'Establish baseline metrics for: {problem.title}',
                'type': SubProblemType.ANALYSIS,
                'success_criterion': 'Baseline metrics documented',
                'metric': 'measurement_accuracy',
                'threshold': 0.95,
                'validation': 'measurement_validation',
                'priority': 9,
                'effort': 8
            },
            {
                'title': 'Bottleneck Identification',
                'description': 'Identify performance bottlenecks',
                'type': SubProblemType.ANALYSIS,
                'success_criterion': 'Bottlenecks identified and prioritized',
                'metric': 'identification_accuracy',
                'threshold': 0.9,
                'validation': 'analysis_review',
                'priority': 8,
                'effort': 12
            },
            {
                'title': 'Optimization Implementation',
                'description': 'Implement optimization strategies',
                'type': SubProblemType.IMPLEMENTATION,
                'success_criterion': 'Optimizations implemented',
                'metric': 'implementation_completeness',
                'threshold': 1.0,
                'validation': 'code_review',
                'priority': 7,
                'effort': 24
            },
            {
                'title': 'Performance Validation',
                'description': 'Validate performance improvements',
                'type': SubProblemType.VALIDATION,
                'success_criterion': 'Performance targets met',
                'metric': 'performance_gain',
                'threshold': 0.2,  # 20% improvement
                'validation': 'benchmark_testing',
                'priority': 6,
                'effort': 12
            }
        ]
    
    def _identify_design_concepts(self, problem: ProblemDefinition) -> List[Dict[str, Any]]:
        """Identify concepts for design problems."""
        return [
            {
                'title': 'Requirements Gathering',
                'description': f'Gather design requirements for: {problem.title}',
                'type': SubProblemType.RESEARCH,
                'success_criterion': 'All requirements documented',
                'metric': 'completeness',
                'threshold': 1.0,
                'validation': 'requirements_review',
                'priority': 9,
                'effort': 8
            },
            {
                'title': 'Conceptual Design',
                'description': 'Create conceptual design and architecture',
                'type': SubProblemType.ANALYSIS,
                'success_criterion': 'Conceptual design approved',
                'metric': 'design_quality',
                'threshold': 0.85,
                'validation': 'design_review',
                'priority': 8,
                'effort': 16
            },
            {
                'title': 'Detailed Design',
                'description': 'Develop detailed design specifications',
                'type': SubProblemType.ANALYSIS,
                'success_criterion': 'Detailed specifications complete',
                'metric': 'specification_completeness',
                'threshold': 0.95,
                'validation': 'specification_review',
                'priority': 7,
                'effort': 20
            },
            {
                'title': 'Design Validation',
                'description': 'Validate design against requirements',
                'type': SubProblemType.VALIDATION,
                'success_criterion': 'Design validated and approved',
                'metric': 'requirement_coverage',
                'threshold': 1.0,
                'validation': 'validation_review',
                'priority': 6,
                'effort': 12
            }
        ]
    
    def _identify_general_concepts(self, problem: ProblemDefinition) -> List[Dict[str, Any]]:
        """Identify concepts for general problems."""
        return [
            {
                'title': 'Problem Understanding',
                'description': f'Develop deep understanding of: {problem.title}',
                'type': SubProblemType.RESEARCH,
                'success_criterion': 'Problem fully understood and documented',
                'metric': 'understanding_depth',
                'threshold': 0.9,
                'validation': 'expert_review',
                'priority': 8,
                'effort': 8
            },
            {
                'title': 'Solution Approach',
                'description': 'Define solution approach and methodology',
                'type': SubProblemType.ANALYSIS,
                'success_criterion': 'Approach defined and validated',
                'metric': 'approach_viability',
                'threshold': 0.85,
                'validation': 'approach_review',
                'priority': 7,
                'effort': 12
            },
            {
                'title': 'Implementation',
                'description': 'Execute solution implementation',
                'type': SubProblemType.IMPLEMENTATION,
                'success_criterion': 'Solution implemented',
                'metric': 'completeness',
                'threshold': 1.0,
                'validation': 'implementation_review',
                'priority': 6,
                'effort': 24
            },
            {
                'title': 'Validation',
                'description': 'Validate solution effectiveness',
                'type': SubProblemType.VALIDATION,
                'success_criterion': 'Solution validated',
                'metric': 'effectiveness',
                'threshold': 0.8,
                'validation': 'effectiveness_test',
                'priority': 5,
                'effort': 12
            }
        ]
    
    def _estimate_complexity(self, concept: Dict[str, Any], problem: ProblemDefinition) -> ComplexityScore:
        """Estimate complexity for a sub-problem concept."""
        # Base complexity on problem complexity
        base = problem.complexity_score.overall_complexity
        
        # Adjust based on sub-problem type
        type_adjustments = {
            SubProblemType.RESEARCH: -1.0,
            SubProblemType.ANALYSIS: -0.5,
            SubProblemType.IMPLEMENTATION: 0.5,
            SubProblemType.VALIDATION: -1.5,
            SubProblemType.INTEGRATION: 1.0
        }
        
        adjustment = type_adjustments.get(concept['type'], 0.0)
        adjusted = max(1.0, min(10.0, base + adjustment))
        
        return ComplexityScore(
            cognitive_complexity=adjusted,
            computational_complexity=adjusted,
            domain_complexity=problem.complexity_score.domain_complexity * 0.8,
            integration_complexity=adjusted * 0.7,
            overall_complexity=adjusted,
            explanation=f"Derived from parent problem complexity ({base}) with type adjustment ({adjustment})"
        )


class DependencyDecomposition(DecompositionStrategyBase):
    """Decomposes based on causal and prerequisite relationships."""
    
    def get_strategy_name(self) -> str:
        return "dependency"
    
    def decompose(self, problem: ProblemDefinition) -> List[SubProblem]:
        """
        Identifies dependencies and creates ordered sub-problems.
        
        Analyzes the problem to identify prerequisite relationships and
        creates sub-problems in dependency order.
        """
        logger.info(f"Dependency decomposition for problem: {problem.id}")
        
        # Start with semantic decomposition as base
        semantic = SemanticDecomposition()
        sub_problems = semantic.decompose(problem)
        
        # Add dependency relationships
        if len(sub_problems) > 1:
            for i in range(1, len(sub_problems)):
                # Each sub-problem depends on the previous one
                sub_problems[i].dependencies = [sub_problems[i-1].id]
        
        logger.info(f"Created {len(sub_problems)} sub-problems with dependencies")
        return sub_problems


class ComplexityDecomposition(DecompositionStrategyBase):
    """Decomposes to balance cognitive load and resource requirements."""
    
    def get_strategy_name(self) -> str:
        return "complexity"
    
    def decompose(self, problem: ProblemDefinition) -> List[SubProblem]:
        """
        Creates sub-problems with balanced complexity.
        
        Breaks down the problem to ensure each sub-problem has
        manageable complexity.
        """
        logger.info(f"Complexity decomposition for problem: {problem.id}")
        
        # Start with semantic decomposition
        semantic = SemanticDecomposition()
        sub_problems = semantic.decompose(problem)
        
        # If any sub-problem is too complex, split it further
        max_complexity = 7.0
        refined_sub_problems = []
        
        for sp in sub_problems:
            if sp.complexity_score.overall_complexity > max_complexity:
                # Split complex sub-problem
                refined_sub_problems.extend(self._split_complex_subproblem(sp))
            else:
                refined_sub_problems.append(sp)
        
        logger.info(f"Created {len(refined_sub_problems)} sub-problems with balanced complexity")
        return refined_sub_problems
    
    def _split_complex_subproblem(self, sub_problem: SubProblem) -> List[SubProblem]:
        """Split a complex sub-problem into simpler ones."""
        # Create two simpler sub-problems
        sp1 = SubProblem(
            id=generate_id("subproblem"),
            parent_id=sub_problem.parent_id,
            title=f"{sub_problem.title} - Part 1",
            description=f"First part of: {sub_problem.description}",
            type=sub_problem.type,
            complexity_score=ComplexityScore(
                cognitive_complexity=sub_problem.complexity_score.cognitive_complexity * 0.6,
                computational_complexity=sub_problem.complexity_score.computational_complexity * 0.6,
                domain_complexity=sub_problem.complexity_score.domain_complexity * 0.8,
                integration_complexity=sub_problem.complexity_score.integration_complexity * 0.5,
                overall_complexity=sub_problem.complexity_score.overall_complexity * 0.6,
                explanation="Split from complex sub-problem"
            ),
            dependencies=sub_problem.dependencies,
            success_criteria=sub_problem.success_criteria[:len(sub_problem.success_criteria)//2] if sub_problem.success_criteria else [],
            validation_gauntlet=sub_problem.validation_gauntlet,
            priority=sub_problem.priority,
            estimated_effort=sub_problem.estimated_effort // 2
        )
        
        sp2 = SubProblem(
            id=generate_id("subproblem"),
            parent_id=sub_problem.parent_id,
            title=f"{sub_problem.title} - Part 2",
            description=f"Second part of: {sub_problem.description}",
            type=sub_problem.type,
            complexity_score=ComplexityScore(
                cognitive_complexity=sub_problem.complexity_score.cognitive_complexity * 0.6,
                computational_complexity=sub_problem.complexity_score.computational_complexity * 0.6,
                domain_complexity=sub_problem.complexity_score.domain_complexity * 0.8,
                integration_complexity=sub_problem.complexity_score.integration_complexity * 0.5,
                overall_complexity=sub_problem.complexity_score.overall_complexity * 0.6,
                explanation="Split from complex sub-problem"
            ),
            dependencies=[sp1.id],  # Depends on part 1
            success_criteria=sub_problem.success_criteria[len(sub_problem.success_criteria)//2:] if sub_problem.success_criteria else [],
            validation_gauntlet=sub_problem.validation_gauntlet,
            priority=sub_problem.priority - 1,
            estimated_effort=sub_problem.estimated_effort // 2
        )
        
        return [sp1, sp2]


class HybridDecomposition(DecompositionStrategyBase):
    """Combines multiple strategies adaptively."""
    
    def get_strategy_name(self) -> str:
        return "hybrid"
    
    def decompose(self, problem: ProblemDefinition) -> List[SubProblem]:
        """
        Applies multiple strategies and merges results intelligently.
        
        Uses semantic decomposition as base, then enhances with
        dependency analysis and complexity balancing.
        """
        logger.info(f"Hybrid decomposition for problem: {problem.id}")
        
        # Step 1: Get results from multiple strategies
        semantic_strategy = SemanticDecomposition()
        dependency_strategy = DependencyDecomposition()
        complexity_strategy = ComplexityDecomposition()
        
        semantic_results = semantic_strategy.decompose(problem)
        dependency_results = dependency_strategy.decompose(problem)
        
        # Step 2: Merge strategies intelligently
        # Use semantic as base structure
        merged_sub_problems = self._merge_semantic_and_dependency(
            semantic_results, 
            dependency_results
        )
        
        # Step 3: Apply complexity balancing
        balanced_sub_problems = self._apply_complexity_balancing(
            merged_sub_problems,
            max_complexity=7.0
        )
        
        # Step 4: Optimize dependencies
        optimized_sub_problems = self._optimize_dependencies(balanced_sub_problems)
        
        logger.info(f"Created {len(optimized_sub_problems)} sub-problems via hybrid decomposition")
        return optimized_sub_problems
    
    def _merge_semantic_and_dependency(
        self,
        semantic_results: List[SubProblem],
        dependency_results: List[SubProblem]
    ) -> List[SubProblem]:
        """
        Merge semantic and dependency-based decompositions.
        
        Uses semantic structure but enhances with dependency information.
        """
        # Use semantic results as base
        merged = []
        
        for semantic_sp in semantic_results:
            # Find similar sub-problems in dependency results
            similar_deps = self._find_similar_subproblems(
                semantic_sp,
                dependency_results
            )
            
            # Enhance with dependency information
            enhanced_dependencies = list(set(
                semantic_sp.dependencies + 
                [dep for sp in similar_deps for dep in sp.dependencies]
            ))
            
            # Create enhanced sub-problem
            enhanced_sp = SubProblem(
                id=semantic_sp.id,
                parent_id=semantic_sp.parent_id,
                title=semantic_sp.title,
                description=semantic_sp.description,
                type=semantic_sp.type,
                complexity_score=semantic_sp.complexity_score,
                dependencies=enhanced_dependencies,
                success_criteria=semantic_sp.success_criteria,
                validation_gauntlet=semantic_sp.validation_gauntlet,
                priority=semantic_sp.priority,
                estimated_effort=semantic_sp.estimated_effort
            )
            merged.append(enhanced_sp)
        
        return merged
    
    def _find_similar_subproblems(
        self,
        target: SubProblem,
        candidates: List[SubProblem]
    ) -> List[SubProblem]:
        """Find sub-problems similar to target based on title/description."""
        similar = []
        target_words = set(target.title.lower().split() + target.description.lower().split())
        
        for candidate in candidates:
            candidate_words = set(candidate.title.lower().split() + candidate.description.lower().split())
            overlap = len(target_words & candidate_words)
            
            # If significant overlap, consider similar
            if overlap >= 3:
                similar.append(candidate)
        
        return similar
    
    def _apply_complexity_balancing(
        self,
        sub_problems: List[SubProblem],
        max_complexity: float = 7.0
    ) -> List[SubProblem]:
        """Balance complexity across sub-problems."""
        balanced = []
        
        for sp in sub_problems:
            if sp.complexity_score.overall_complexity > max_complexity:
                # Split complex sub-problem
                balanced.extend(self._split_complex_subproblem(sp))
            else:
                balanced.append(sp)
        
        return balanced
    
    def _split_complex_subproblem(self, sub_problem: SubProblem) -> List[SubProblem]:
        """Split a complex sub-problem into simpler ones."""
        # Create two simpler sub-problems
        sp1 = SubProblem(
            id=generate_id("subproblem"),
            parent_id=sub_problem.parent_id,
            title=f"{sub_problem.title} - Phase 1",
            description=f"Initial phase: {sub_problem.description[:100]}...",
            type=sub_problem.type,
            complexity_score=ComplexityScore(
                cognitive_complexity=sub_problem.complexity_score.cognitive_complexity * 0.6,
                computational_complexity=sub_problem.complexity_score.computational_complexity * 0.6,
                domain_complexity=sub_problem.complexity_score.domain_complexity * 0.8,
                integration_complexity=sub_problem.complexity_score.integration_complexity * 0.5,
                overall_complexity=sub_problem.complexity_score.overall_complexity * 0.6,
                explanation="Split from complex sub-problem (hybrid strategy)"
            ),
            dependencies=sub_problem.dependencies,
            success_criteria=sub_problem.success_criteria[:max(1, len(sub_problem.success_criteria)//2)] if sub_problem.success_criteria else [],
            validation_gauntlet=sub_problem.validation_gauntlet,
            priority=sub_problem.priority,
            estimated_effort=max(4, sub_problem.estimated_effort // 2)
        )
        
        sp2 = SubProblem(
            id=generate_id("subproblem"),
            parent_id=sub_problem.parent_id,
            title=f"{sub_problem.title} - Phase 2",
            description=f"Advanced phase: {sub_problem.description[:100]}...",
            type=sub_problem.type,
            complexity_score=ComplexityScore(
                cognitive_complexity=sub_problem.complexity_score.cognitive_complexity * 0.6,
                computational_complexity=sub_problem.complexity_score.computational_complexity * 0.6,
                domain_complexity=sub_problem.complexity_score.domain_complexity * 0.8,
                integration_complexity=sub_problem.complexity_score.integration_complexity * 0.5,
                overall_complexity=sub_problem.complexity_score.overall_complexity * 0.6,
                explanation="Split from complex sub-problem (hybrid strategy)"
            ),
            dependencies=[sp1.id] + sub_problem.dependencies,  # Depends on phase 1
            success_criteria=sub_problem.success_criteria[len(sub_problem.success_criteria)//2:] if sub_problem.success_criteria else [],
            validation_gauntlet=sub_problem.validation_gauntlet,
            priority=sub_problem.priority - 1,
            estimated_effort=max(4, sub_problem.estimated_effort // 2)
        )
        
        return [sp1, sp2]
    
    def _optimize_dependencies(self, sub_problems: List[SubProblem]) -> List[SubProblem]:
        """Optimize dependency relationships to remove redundancies."""
        # Build dependency graph
        dep_graph = {sp.id: set(sp.dependencies) for sp in sub_problems}
        
        # Remove transitive dependencies
        for sp_id in dep_graph:
            # Find all transitive dependencies
            transitive = set()
            for dep in list(dep_graph[sp_id]):
                if dep in dep_graph:
                    transitive.update(dep_graph[dep])
            
            # Remove transitive dependencies from direct dependencies
            dep_graph[sp_id] -= transitive
        
        # Update sub-problems with optimized dependencies
        optimized = []
        for sp in sub_problems:
            optimized_sp = SubProblem(
                id=sp.id,
                parent_id=sp.parent_id,
                title=sp.title,
                description=sp.description,
                type=sp.type,
                complexity_score=sp.complexity_score,
                dependencies=list(dep_graph.get(sp.id, [])),
                success_criteria=sp.success_criteria,
                validation_gauntlet=sp.validation_gauntlet,
                priority=sp.priority,
                estimated_effort=sp.estimated_effort
            )
            optimized.append(optimized_sp)
        
        return optimized


class DecompositionEngine:
    """Orchestrates problem decomposition using multiple strategies."""
    
    def __init__(self, problem_analyzer: Optional[ProblemAnalyzer] = None):
        """
        Initialize decomposition engine.
        
        Args:
            problem_analyzer: Optional ProblemAnalyzer instance
        """
        self.strategies: Dict[str, DecompositionStrategyBase] = {
            'semantic': SemanticDecomposition(),
            'dependency': DependencyDecomposition(),
            'complexity': ComplexityDecomposition(),
            'hybrid': HybridDecomposition()
        }
        self.problem_analyzer = problem_analyzer or ProblemAnalyzer()
        self.logger = logging.getLogger(__name__)
    
    def decompose(self, problem: ProblemDefinition, strategy: Optional[str] = None) -> DecompositionPlan:
        """
        Decomposes problem using optimal strategy.
        
        Args:
            problem: The problem to decompose
            strategy: Optional strategy name (auto-selected if not provided)
            
        Returns:
            DecompositionPlan with sub-problems, dependencies, execution order
        """
        self.logger.info(f"Decomposing problem: {problem.id}")
        
        # Select strategy if not provided
        if not strategy:
            strategy = self.select_strategy(problem)
        
        self.logger.info(f"Using strategy: {strategy}")
        
        # Get strategy instance
        strategy_instance = self.strategies.get(strategy)
        if not strategy_instance:
            raise ValueError(f"Unknown strategy: {strategy}")
        
        # Generate sub-problems
        sub_problems = strategy_instance.decompose(problem)
        
        # Build dependency graph
        dependency_graph = self._build_dependency_graph(sub_problems)
        
        # Create quality scores (initial assessment)
        quality_scores = self._assess_quality(problem, sub_problems)
        
        # Create decomposition plan
        plan = DecompositionPlan(
            id=generate_id("plan"),
            problem_id=problem.id,
            strategy=DecompositionStrategy(strategy),
            sub_problems=sub_problems,
            dependency_graph=dependency_graph,
            validation_checkpoints=[],
            quality_scores=quality_scores,
            confidence_level=0.8,  # Initial confidence
            created_by="decomposition_engine"
        )
        
        self.logger.info(f"Decomposition complete: {len(sub_problems)} sub-problems created")
        return plan
    
    def select_strategy(self, problem: ProblemDefinition) -> str:
        """
        Chooses optimal decomposition strategy.
        
        Args:
            problem: The problem to analyze
            
        Returns:
            Strategy name
        """
        # Strategy selection based on problem characteristics
        complexity = problem.complexity_score.overall_complexity
        
        # High complexity problems benefit from complexity-based decomposition
        if complexity > 7.5:
            return 'complexity'
        
        # Problems with many constraints benefit from dependency-based
        if len(problem.constraints) > 3:
            return 'dependency'
        
        # Default to semantic decomposition
        return 'semantic'
    
    def _build_dependency_graph(self, sub_problems: List[SubProblem]) -> DependencyGraph:
        """Build dependency graph from sub-problems."""
        nodes = {sp.id: sp for sp in sub_problems}
        edges = {sp.id: sp.dependencies for sp in sub_problems}
        
        # Calculate execution order (topological sort)
        execution_order = self._topological_sort(sub_problems)
        
        return DependencyGraph(
            nodes=nodes,
            edges=edges,
            critical_path=[],  # Will be calculated by DependencyManager
            parallel_groups=[],  # Will be calculated by DependencyManager
            execution_order=execution_order
        )
    
    def _topological_sort(self, sub_problems: List[SubProblem]) -> List[str]:
        """Simple topological sort for execution order."""
        # Build adjacency list
        in_degree = {sp.id: len(sp.dependencies) for sp in sub_problems}
        
        # Find nodes with no dependencies
        queue = [sp.id for sp in sub_problems if len(sp.dependencies) == 0]
        result = []
        
        while queue:
            node = queue.pop(0)
            result.append(node)
            
            # Find nodes that depend on this node
            for sp in sub_problems:
                if node in sp.dependencies:
                    in_degree[sp.id] -= 1
                    if in_degree[sp.id] == 0:
                        queue.append(sp.id)
        
        return result
    
    def _assess_quality(self, problem: ProblemDefinition, sub_problems: List[SubProblem]) -> QualityScores:
        """Assess initial quality of decomposition."""
        from datetime import datetime
        
        # Simple quality assessment
        coherence = 0.8  # Placeholder
        completeness = 0.85  # Placeholder
        feasibility = 0.9  # Placeholder
        integration = 0.75  # Placeholder
        overall = (coherence + completeness + feasibility + integration) / 4.0
        
        return QualityScores(
            coherence_score=coherence,
            completeness_score=completeness,
            feasibility_score=feasibility,
            integration_score=integration,
            overall_score=overall,
            meets_thresholds=overall >= 0.8,
            details={'method': 'initial_assessment'},
            timestamp=datetime.now()
        )
