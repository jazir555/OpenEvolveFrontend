"""
LLM Response Caching Module

This module provides caching functionality for LLM API calls to improve performance
and reduce costs by avoiding redundant API calls for identical requests.
"""

import hashlib
import json
import os
import time
from typing import Dict, Any, Optional
from datetime import datetime, timedelta
import pickle


class LLMCache:
    """Caches LLM responses to avoid redundant API calls."""
    
    def __init__(self, cache_dir: str = "./llm_cache", ttl_hours: int = 24, max_cache_size_mb: int = 100):
        """
        Initialize the LLM cache.
        
        Args:
            cache_dir: Directory to store cache files
            ttl_hours: Time-to-live for cache entries in hours
            max_cache_size_mb: Maximum cache size in megabytes
        """
        self.cache_dir = cache_dir
        self.ttl_seconds = ttl_hours * 3600
        self.max_cache_size_bytes = max_cache_size_mb * 1024 * 1024
        self.cache_file = os.path.join(cache_dir, "llm_cache.pkl")
        self.metadata_file = os.path.join(cache_dir, "cache_metadata.json")
        
        os.makedirs(cache_dir, exist_ok=True)
        
        self.cache: Dict[str, Dict[str, Any]] = self._load_cache()
        self.metadata = self._load_metadata()
        
        # Clean expired entries on initialization
        self._clean_expired()
    
    def _load_cache(self) -> Dict[str, Dict[str, Any]]:
        """Load cache from disk."""
        if os.path.exists(self.cache_file):
            try:
                with open(self.cache_file, 'rb') as f:
                    return pickle.load(f)
            except Exception as e:
                print(f"Error loading cache: {e}")
                return {}
        return {}
    
    def _save_cache(self):
        """Save cache to disk."""
        try:
            with open(self.cache_file, 'wb') as f:
                pickle.dump(self.cache, f)
        except Exception as e:
            print(f"Error saving cache: {e}")
    
    def _load_metadata(self) -> Dict[str, Any]:
        """Load cache metadata."""
        if os.path.exists(self.metadata_file):
            try:
                with open(self.metadata_file, 'r') as f:
                    return json.load(f)
            except Exception as e:
                print(f"Error loading metadata: {e}")
                return {"hits": 0, "misses": 0, "total_saved_calls": 0}
        return {"hits": 0, "misses": 0, "total_saved_calls": 0}
    
    def _save_metadata(self):
        """Save cache metadata."""
        try:
            with open(self.metadata_file, 'w') as f:
                json.dump(self.metadata, f, indent=2)
        except Exception as e:
            print(f"Error saving metadata: {e}")
    
    def _generate_cache_key(
        self,
        model: str,
        messages: list,
        temperature: float,
        max_tokens: int,
        **kwargs
    ) -> str:
        """
        Generate a unique cache key for a request.
        
        Args:
            model: Model identifier
            messages: List of message dicts
            temperature: Temperature parameter
            max_tokens: Max tokens parameter
            **kwargs: Additional parameters
            
        Returns:
            Cache key (hash)
        """
        # Create a deterministic representation of the request
        cache_data = {
            "model": model,
            "messages": messages,
            "temperature": temperature,
            "max_tokens": max_tokens,
            # Include other relevant parameters
            "top_p": kwargs.get("top_p"),
            "frequency_penalty": kwargs.get("frequency_penalty"),
            "presence_penalty": kwargs.get("presence_penalty"),
        }
        
        # Convert to JSON string and hash
        cache_str = json.dumps(cache_data, sort_keys=True)
        return hashlib.sha256(cache_str.encode()).hexdigest()
    
    def get(
        self,
        model: str,
        messages: list,
        temperature: float,
        max_tokens: int,
        **kwargs
    ) -> Optional[str]:
        """
        Get cached response if available and not expired.
        
        Args:
            model: Model identifier
            messages: List of message dicts
            temperature: Temperature parameter
            max_tokens: Max tokens parameter
            **kwargs: Additional parameters
            
        Returns:
            Cached response or None if not found/expired
        """
        cache_key = self._generate_cache_key(model, messages, temperature, max_tokens, **kwargs)
        
        if cache_key in self.cache:
            entry = self.cache[cache_key]
            
            # Check if expired
            if time.time() - entry["timestamp"] > self.ttl_seconds:
                del self.cache[cache_key]
                self._save_cache()
                self.metadata["misses"] += 1
                self._save_metadata()
                return None
            
            # Cache hit
            self.metadata["hits"] += 1
            self.metadata["total_saved_calls"] += 1
            self._save_metadata()
            return entry["response"]
        
        # Cache miss
        self.metadata["misses"] += 1
        self._save_metadata()
        return None
    
    def set(
        self,
        model: str,
        messages: list,
        temperature: float,
        max_tokens: int,
        response: str,
        **kwargs
    ):
        """
        Store response in cache.
        
        Args:
            model: Model identifier
            messages: List of message dicts
            temperature: Temperature parameter
            max_tokens: Max tokens parameter
            response: Response to cache
            **kwargs: Additional parameters
        """
        cache_key = self._generate_cache_key(model, messages, temperature, max_tokens, **kwargs)
        
        self.cache[cache_key] = {
            "response": response,
            "timestamp": time.time(),
            "model": model
        }
        
        # Check cache size and clean if necessary
        self._enforce_size_limit()
        
        self._save_cache()
    
    def _clean_expired(self):
        """Remove expired entries from cache."""
        current_time = time.time()
        expired_keys = [
            key for key, entry in self.cache.items()
            if current_time - entry["timestamp"] > self.ttl_seconds
        ]
        
        for key in expired_keys:
            del self.cache[key]
        
        if expired_keys:
            self._save_cache()
    
    def _enforce_size_limit(self):
        """Enforce maximum cache size by removing oldest entries."""
        # Estimate cache size
        cache_size = os.path.getsize(self.cache_file) if os.path.exists(self.cache_file) else 0
        
        if cache_size > self.max_cache_size_bytes:
            # Sort by timestamp and remove oldest entries
            sorted_entries = sorted(
                self.cache.items(),
                key=lambda x: x[1]["timestamp"]
            )
            
            # Remove oldest 20% of entries
            num_to_remove = len(sorted_entries) // 5
            for key, _ in sorted_entries[:num_to_remove]:
                del self.cache[key]
            
            self._save_cache()
    
    def clear(self):
        """Clear all cache entries."""
        self.cache = {}
        self._save_cache()
        self.metadata = {"hits": 0, "misses": 0, "total_saved_calls": 0}
        self._save_metadata()
    
    def get_stats(self) -> Dict[str, Any]:
        """Get cache statistics."""
        total_requests = self.metadata["hits"] + self.metadata["misses"]
        hit_rate = self.metadata["hits"] / total_requests if total_requests > 0 else 0
        
        cache_size = os.path.getsize(self.cache_file) if os.path.exists(self.cache_file) else 0
        
        return {
            "total_entries": len(self.cache),
            "hits": self.metadata["hits"],
            "misses": self.metadata["misses"],
            "hit_rate": hit_rate,
            "total_saved_calls": self.metadata["total_saved_calls"],
            "cache_size_mb": cache_size / (1024 * 1024),
            "max_size_mb": self.max_cache_size_bytes / (1024 * 1024)
        }


# Global cache instance
_global_cache: Optional[LLMCache] = None


def get_cache() -> LLMCache:
    """Get or create the global cache instance."""
    global _global_cache
    if _global_cache is None:
        _global_cache = LLMCache()
    return _global_cache


def cached_llm_call(
    call_function,
    model: str,
    messages: list,
    temperature: float = 0.7,
    max_tokens: int = 1000,
    use_cache: bool = True,
    **kwargs
) -> str:
    """
    Wrapper for LLM calls with caching.
    
    Args:
        call_function: Function to call if cache miss
        model: Model identifier
        messages: List of message dicts
        temperature: Temperature parameter
        max_tokens: Max tokens parameter
        use_cache: Whether to use caching
        **kwargs: Additional parameters
        
    Returns:
        Response from cache or API call
    """
    if not use_cache:
        return call_function(model=model, messages=messages, temperature=temperature, max_tokens=max_tokens, **kwargs)
    
    cache = get_cache()
    
    # Try to get from cache
    cached_response = cache.get(model, messages, temperature, max_tokens, **kwargs)
    if cached_response is not None:
        return cached_response
    
    # Cache miss - make actual API call
    response = call_function(model=model, messages=messages, temperature=temperature, max_tokens=max_tokens, **kwargs)
    
    # Store in cache
    if response:
        cache.set(model, messages, temperature, max_tokens, response, **kwargs)
    
    return response
