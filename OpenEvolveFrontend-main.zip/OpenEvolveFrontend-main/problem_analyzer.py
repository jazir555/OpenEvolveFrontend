"""
Sovereign-Grade Problem Decomposition System - Problem Analyzer

This module provides semantic analysis of problems to extract domain context,
assess complexity, identify constraints, and generate success criteria.
"""

import logging
from typing import List, Dict, Any, Optional
from datetime import datetime
import re

from sovereign_data_models import (
    ProblemDefinition, ProblemType, DomainContext, ComplexityScore,
    Constraint, SuccessCriterion, generate_id
)

# Import OpenEvolve client for LLM-based analysis
try:
    import sys
    sys.path.append('..')
    from openevolve_client import OpenEvolveClient
    OPENEVOLVE_AVAILABLE = True
except ImportError:
    OPENEVOLVE_AVAILABLE = False
    logging.warning("OpenEvolve client not available - using fallback analysis")

logger = logging.getLogger(__name__)


class ProblemAnalyzer:
    """
    Analyzes problems to extract semantic information and structure.
    
    Uses LLM-based analysis for semantic understanding, domain classification,
    complexity assessment, and constraint identification.
    """
    
    def __init__(self, openevolve_client: Optional[OpenEvolveClient] = None):
        """
        Initialize problem analyzer.
        
        Args:
            openevolve_client: Optional OpenEvolve client for LLM analysis
        """
        self.openevolve_client = openevolve_client
        if not self.openevolve_client and OPENEVOLVE_AVAILABLE:
            self.openevolve_client = OpenEvolveClient()
        
        self.logger = logging.getLogger(__name__)
    
    def analyze_problem(self, problem_text: str, title: str = "") -> ProblemDefinition:
        """
        Performs comprehensive problem analysis.
        
        Args:
            problem_text: The problem description
            title: Optional problem title
            
        Returns:
            ProblemDefinition with domain, complexity, constraints, success criteria
        """
        self.logger.info(f"Analyzing problem: {title or 'Untitled'}")
        
        # Extract domain context
        domain_context = self.extract_domain_context(problem_text)
        
        # Classify problem type
        problem_type = self.classify_problem_type(problem_text)
        
        # Identify constraints
        constraints = self.identify_constraints(problem_text)
        
        # Create initial problem definition
        problem = ProblemDefinition(
            id=generate_id("problem"),
            title=title or self._extract_title(problem_text),
            description=problem_text,
            problem_type=problem_type,
            domain_context=domain_context,
            complexity_score=ComplexityScore(
                cognitive_complexity=5.0,
                computational_complexity=5.0,
                domain_complexity=5.0,
                integration_complexity=5.0,
                overall_complexity=5.0,
                explanation="Initial assessment"
            ),
            constraints=constraints,
            success_criteria=[],
            stakeholders=[],
            resources_available={}
        )
        
        # Assess complexity (needs full problem context)
        problem.complexity_score = self.assess_complexity(problem)
        
        # Generate success criteria
        problem.success_criteria = self.generate_success_criteria(problem)
        
        self.logger.info(f"Problem analysis complete: {problem.id}")
        return problem
    
    def extract_domain_context(self, problem_text: str) -> DomainContext:
        """
        Identifies problem domain and relevant context.
        
        Args:
            problem_text: The problem description
            
        Returns:
            DomainContext with domain, subdomain, and related domains
        """
        if self.openevolve_client and OPENEVOLVE_AVAILABLE:
            return self._extract_domain_context_llm(problem_text)
        else:
            return self._extract_domain_context_heuristic(problem_text)
    
    def _extract_domain_context_llm(self, problem_text: str) -> DomainContext:
        """Extract domain context using LLM analysis with sophisticated prompting."""
        prompt = f"""You are an expert domain analyst. Analyze this problem and identify its domain context with precision.

Problem:
{problem_text}

Provide a comprehensive domain analysis:

1. PRIMARY DOMAIN: Identify the main field (e.g., software_engineering, machine_learning, data_science, business_strategy, research, design, optimization, systems_engineering)

2. SUBDOMAIN: Identify specific subdomain if applicable (e.g., for software_engineering: web_development, distributed_systems, security, etc.)

3. RELATED DOMAINS: List 3-5 closely related fields that provide relevant context

4. KEY CONCEPTS: Identify 5-7 domain-specific concepts, techniques, or principles that are central to this problem

5. DOMAIN COMPLEXITY: Rate domain specialization (1-10, where 10 is highly specialized)

6. REQUIRED EXPERTISE: List specific expertise areas needed

Format your response EXACTLY as:
Domain: <primary_domain>
Subdomain: <subdomain or "none">
Related: <domain1>, <domain2>, <domain3>
Concepts: <concept1>, <concept2>, <concept3>, <concept4>, <concept5>
Complexity: <1-10>
Expertise: <expertise1>, <expertise2>, <expertise3>

Be specific and precise. Use underscores for multi-word domains (e.g., machine_learning not "machine learning")."""
        
        try:
            # Use OpenEvolve with optimized parameters for analysis
            result = self.openevolve_client.evolve(
                content=prompt,
                evolution_mode="standard",
                content_type="analysis",
                max_iterations=1,
                temperature=0.3,  # Lower temperature for more focused analysis
                max_tokens=500
            )
            
            if result.success and result.best_code:
                parsed = self._parse_domain_response(result.best_code)
                # Validate parsed result has meaningful content
                if parsed.domain and parsed.domain != "general":
                    self.logger.info(f"LLM domain extraction successful: {parsed.domain}")
                    return parsed
                else:
                    self.logger.warning("LLM returned generic domain, using fallback")
        except Exception as e:
            self.logger.warning(f"LLM domain extraction failed: {e}")
        
        # Fallback to heuristic
        return self._extract_domain_context_heuristic(problem_text)
    
    def _extract_domain_context_heuristic(self, problem_text: str) -> DomainContext:
        """Extract domain context using heuristic analysis."""
        text_lower = problem_text.lower()
        
        # Domain keywords mapping
        domain_keywords = {
            "software_engineering": ["software", "code", "system", "application", "api", "database"],
            "machine_learning": ["model", "training", "neural", "algorithm", "prediction", "data"],
            "data_science": ["data", "analysis", "statistics", "visualization", "insights"],
            "business_strategy": ["business", "strategy", "market", "revenue", "customer"],
            "research": ["research", "study", "hypothesis", "experiment", "investigation"],
            "design": ["design", "user", "interface", "experience", "prototype"],
        }
        
        # Count keyword matches
        domain_scores = {}
        for domain, keywords in domain_keywords.items():
            score = sum(1 for keyword in keywords if keyword in text_lower)
            if score > 0:
                domain_scores[domain] = score
        
        # Determine primary domain
        if domain_scores:
            primary_domain = max(domain_scores, key=domain_scores.get)
            related_domains = [d for d, s in sorted(domain_scores.items(), key=lambda x: x[1], reverse=True)[1:4]]
        else:
            primary_domain = "general"
            related_domains = []
        
        return DomainContext(
            domain=primary_domain,
            subdomain=None,
            related_domains=related_domains,
            domain_knowledge={"extraction_method": "heuristic"}
        )
    
    def _parse_domain_response(self, response: str) -> DomainContext:
        """Parse LLM response for domain context with enhanced extraction."""
        lines = response.strip().split('\n')
        domain = "general"
        subdomain = None
        related_domains = []
        concepts = []
        complexity = 5.0
        expertise = []
        
        for line in lines:
            line = line.strip()
            if not line:
                continue
                
            if line.startswith("Domain:"):
                domain = line.split(":", 1)[1].strip().lower().replace(" ", "_")
            elif line.startswith("Subdomain:"):
                sub = line.split(":", 1)[1].strip()
                subdomain = sub.lower().replace(" ", "_") if sub.lower() != "none" else None
            elif line.startswith("Related:"):
                related = line.split(":", 1)[1].strip()
                related_domains = [d.strip().lower().replace(" ", "_") for d in related.split(",") if d.strip()]
            elif line.startswith("Concepts:"):
                concepts_str = line.split(":", 1)[1].strip()
                concepts = [c.strip() for c in concepts_str.split(",") if c.strip()]
            elif line.startswith("Complexity:"):
                try:
                    complexity = float(line.split(":", 1)[1].strip())
                except:
                    complexity = 5.0
            elif line.startswith("Expertise:"):
                expertise_str = line.split(":", 1)[1].strip()
                expertise = [e.strip() for e in expertise_str.split(",") if e.strip()]
        
        return DomainContext(
            domain=domain,
            subdomain=subdomain,
            related_domains=related_domains[:5],  # Limit to 5
            domain_knowledge={
                "key_concepts": concepts[:7],  # Limit to 7
                "extraction_method": "llm",
                "domain_complexity": complexity,
                "required_expertise": expertise[:5]  # Limit to 5
            }
        )
    
    def classify_problem_type(self, problem_text: str) -> ProblemType:
        """
        Determines problem category for strategy selection.
        
        Args:
            problem_text: The problem description
            
        Returns:
            ProblemType enum value
        """
        text_lower = problem_text.lower()
        
        # Type indicators
        type_indicators = {
            ProblemType.RESEARCH: ["research", "investigate", "study", "explore", "understand", "discover"],
            ProblemType.IMPLEMENTATION: ["implement", "build", "create", "develop", "code", "construct"],
            ProblemType.ANALYSIS: ["analyze", "evaluate", "assess", "examine", "review", "compare"],
            ProblemType.OPTIMIZATION: ["optimize", "improve", "enhance", "maximize", "minimize", "efficient"],
            ProblemType.DESIGN: ["design", "architect", "plan", "structure", "model", "prototype"],
        }
        
        # Count indicators for each type
        type_scores = {}
        for problem_type, indicators in type_indicators.items():
            score = sum(1 for indicator in indicators if indicator in text_lower)
            if score > 0:
                type_scores[problem_type] = score
        
        # Return type with highest score, default to ANALYSIS
        if type_scores:
            return max(type_scores, key=type_scores.get)
        return ProblemType.ANALYSIS
    
    def assess_complexity(self, problem: ProblemDefinition) -> ComplexityScore:
        """
        Calculates cognitive and computational complexity.
        
        Args:
            problem: The problem definition
            
        Returns:
            ComplexityScore with multi-dimensional assessment
        """
        if self.openevolve_client and OPENEVOLVE_AVAILABLE:
            return self._assess_complexity_llm(problem)
        else:
            return self._assess_complexity_heuristic(problem)
    
    def _assess_complexity_heuristic(self, problem: ProblemDefinition) -> ComplexityScore:
        """Assess complexity using heuristic analysis."""
        text = problem.description
        text_lower = text.lower()
        
        # Cognitive complexity factors
        word_count = len(text.split())
        sentence_count = len(re.split(r'[.!?]+', text))
        avg_sentence_length = word_count / max(sentence_count, 1)
        
        # Cognitive complexity (based on text complexity and technical terms)
        cognitive = min(10.0, 3.0 + (avg_sentence_length / 5.0))
        # Boost for technical complexity indicators
        complexity_indicators = ["distributed", "scalable", "fault-tolerant", "real-time", 
                                "optimize", "integrate", "complex", "advanced"]
        cognitive += sum(0.3 for indicator in complexity_indicators if indicator in text_lower)
        cognitive = min(10.0, cognitive)
        
        # Computational complexity (based on problem type and constraints)
        computational = 5.0
        if problem.problem_type == ProblemType.OPTIMIZATION:
            computational += 2.0
        if problem.problem_type == ProblemType.IMPLEMENTATION:
            computational += 1.0
        if problem.problem_type == ProblemType.DESIGN:
            computational += 1.5
        computational += len(problem.constraints) * 0.5
        # Boost for performance/scale requirements
        if any(term in text_lower for term in ["performance", "scale", "millions", "high-load"]):
            computational += 1.5
        computational = min(10.0, computational)
        
        # Domain complexity (based on domain knowledge and specialization)
        domain = 5.0
        if problem.domain_context.subdomain:
            domain += 1.5
        if len(problem.domain_context.related_domains) > 2:
            domain += 1.0
        # Boost for specialized domains
        if problem.domain_context.domain in ["machine_learning", "distributed_systems"]:
            domain += 1.0
        domain = min(10.0, domain)
        
        # Integration complexity (based on constraints, stakeholders, and integration needs)
        integration = 4.0 + len(problem.constraints) * 0.4 + len(problem.stakeholders) * 0.3
        if any(term in text_lower for term in ["integrate", "existing", "legacy", "pipeline"]):
            integration += 1.5
        integration = min(10.0, integration)
        
        # Overall complexity (weighted average)
        overall = (cognitive * 0.3 + computational * 0.3 + domain * 0.2 + integration * 0.2)
        
        explanation = f"Heuristic assessment: {word_count} words, {sentence_count} sentences, "
        explanation += f"{len(problem.constraints)} constraints"
        
        return ComplexityScore(
            cognitive_complexity=round(cognitive, 1),
            computational_complexity=round(computational, 1),
            domain_complexity=round(domain, 1),
            integration_complexity=round(integration, 1),
            overall_complexity=round(overall, 1),
            explanation=explanation
        )
    
    def _assess_complexity_llm(self, problem: ProblemDefinition) -> ComplexityScore:
        """Assess complexity using LLM analysis with multi-dimensional evaluation."""
        # Build comprehensive context
        constraints_desc = f"\nConstraints: {len(problem.constraints)} constraints including " + ", ".join([c.type for c in problem.constraints[:3]]) if problem.constraints else "\nConstraints: None specified"
        domain_knowledge = problem.domain_context.domain_knowledge.get("key_concepts", [])
        concepts_desc = f"\nKey Concepts: {', '.join(domain_knowledge[:5])}" if domain_knowledge else ""
        
        prompt = f"""You are an expert problem complexity analyst. Assess this problem's complexity across multiple dimensions with precision.

PROBLEM DETAILS:
Title: {problem.title}
Description: {problem.description}
Domain: {problem.domain_context.domain}
Subdomain: {problem.domain_context.subdomain or "N/A"}
Type: {problem.problem_type.value}{constraints_desc}{concepts_desc}

COMPLEXITY ASSESSMENT FRAMEWORK:

1. COGNITIVE COMPLEXITY (0-10): Mental effort, conceptual difficulty, abstraction level
   - Consider: Problem understanding, mental models needed, conceptual depth
   - 0-3: Simple, straightforward
   - 4-6: Moderate, requires focused thinking
   - 7-10: High, requires deep expertise and abstract reasoning

2. COMPUTATIONAL COMPLEXITY (0-10): Processing, calculation, algorithmic requirements
   - Consider: Data volume, algorithm complexity, performance requirements
   - 0-3: Minimal computation
   - 4-6: Moderate processing needs
   - 7-10: Intensive computation, optimization critical

3. DOMAIN COMPLEXITY (0-10): Specialized knowledge and expertise required
   - Consider: Domain depth, specialized techniques, field-specific knowledge
   - 0-3: General knowledge sufficient
   - 4-6: Domain familiarity needed
   - 7-10: Deep domain expertise essential

4. INTEGRATION COMPLEXITY (0-10): Coordination, dependencies, system integration
   - Consider: Component interactions, external dependencies, coordination needs
   - 0-3: Standalone, minimal integration
   - 4-6: Some integration required
   - 7-10: Complex integration, many dependencies

Provide your assessment in this EXACT format:
Cognitive: <score>
Computational: <score>
Domain: <score>
Integration: <score>
Explanation: <2-3 sentence explanation of key complexity drivers>

Be precise and justify your scores based on the problem characteristics."""
        
        try:
            result = self.openevolve_client.evolve(
                content=prompt,
                evolution_mode="standard",
                content_type="analysis",
                max_iterations=1,
                temperature=0.2,  # Very low temperature for consistent scoring
                max_tokens=400
            )
            
            if result.success and result.best_code:
                parsed = self._parse_complexity_response(result.best_code)
                # Validate scores are reasonable
                if 0 <= parsed.overall_complexity <= 10:
                    self.logger.info(f"LLM complexity assessment: {parsed.overall_complexity:.1f}")
                    return parsed
                else:
                    self.logger.warning("LLM returned invalid complexity scores")
        except Exception as e:
            self.logger.warning(f"LLM complexity assessment failed: {e}")
        
        return self._assess_complexity_heuristic(problem)
    
    def _parse_complexity_response(self, response: str) -> ComplexityScore:
        """Parse LLM response for complexity scores."""
        lines = response.strip().split('\n')
        cognitive = 5.0
        computational = 5.0
        domain = 5.0
        integration = 5.0
        explanation = "LLM assessment"
        
        for line in lines:
            if line.startswith("Cognitive:"):
                try:
                    cognitive = float(line.split(":", 1)[1].strip())
                except:
                    pass
            elif line.startswith("Computational:"):
                try:
                    computational = float(line.split(":", 1)[1].strip())
                except:
                    pass
            elif line.startswith("Domain:"):
                try:
                    domain = float(line.split(":", 1)[1].strip())
                except:
                    pass
            elif line.startswith("Integration:"):
                try:
                    integration = float(line.split(":", 1)[1].strip())
                except:
                    pass
            elif line.startswith("Explanation:"):
                explanation = line.split(":", 1)[1].strip()
        
        overall = (cognitive + computational + domain + integration) / 4.0
        
        return ComplexityScore(
            cognitive_complexity=cognitive,
            computational_complexity=computational,
            domain_complexity=domain,
            integration_complexity=integration,
            overall_complexity=overall,
            explanation=explanation
        )
    
    def identify_constraints(self, problem_text: str) -> List[Constraint]:
        """
        Extracts explicit and implicit constraints using LLM analysis.
        
        Args:
            problem_text: The problem description
            
        Returns:
            List of Constraint objects
        """
        if self.openevolve_client and OPENEVOLVE_AVAILABLE:
            return self._identify_constraints_llm(problem_text)
        else:
            return self._identify_constraints_heuristic(problem_text)
    
    def _identify_constraints_llm(self, problem_text: str) -> List[Constraint]:
        """Use LLM to identify constraints with semantic understanding."""
        prompt = f"""You are an expert at identifying constraints in problem statements. Analyze this problem and extract ALL constraints.

Problem:
{problem_text}

Identify constraints in these categories:
1. TIME: Deadlines, schedules, time windows
2. RESOURCE: Budget, personnel, equipment, infrastructure
3. QUALITY: Performance, accuracy, reliability, standards
4. TECHNICAL: Technology stack, compatibility, platform requirements
5. REGULATORY: Compliance, legal, policy requirements
6. SCOPE: Boundaries, limitations, exclusions

For each constraint found, provide:
- Type: (time/resource/quality/technical/regulatory/scope)
- Description: Clear description of the constraint
- Severity: (hard/soft) - hard = must satisfy, soft = should satisfy

Format each constraint as:
[TYPE] Description | SEVERITY

Example:
[time] Must be completed within 3 months | hard
[resource] Budget limited to $50,000 | hard
[quality] Must achieve 95% accuracy | soft

List ALL constraints you identify, including implicit ones:"""
        
        try:
            result = self.openevolve_client.evolve(
                content=prompt,
                evolution_mode="standard",
                content_type="analysis",
                max_iterations=1,
                temperature=0.3,
                max_tokens=600
            )
            
            if result.success and result.best_code:
                constraints = self._parse_constraints_response(result.best_code)
                if constraints:
                    self.logger.info(f"LLM identified {len(constraints)} constraints")
                    return constraints
                else:
                    self.logger.warning("LLM returned no constraints, using fallback")
        except Exception as e:
            self.logger.warning(f"LLM constraint identification failed: {e}")
        
        return self._identify_constraints_heuristic(problem_text)
    
    def _parse_constraints_response(self, response: str) -> List[Constraint]:
        """Parse LLM response for constraints."""
        constraints = []
        lines = response.strip().split('\n')
        
        for line in lines:
            line = line.strip()
            if not line or not line.startswith('['):
                continue
            
            try:
                # Parse format: [TYPE] Description | SEVERITY
                if ']' not in line:
                    continue
                    
                type_part = line[1:line.index(']')].strip().lower()
                rest = line[line.index(']')+1:].strip()
                
                if '|' in rest:
                    description, severity = rest.split('|', 1)
                    description = description.strip()
                    severity = severity.strip().lower()
                else:
                    description = rest
                    severity = "soft"
                
                # Validate type
                valid_types = ["time", "resource", "quality", "technical", "regulatory", "scope"]
                if type_part not in valid_types:
                    continue
                
                # Validate severity
                if severity not in ["hard", "soft"]:
                    severity = "soft"
                
                constraints.append(Constraint(
                    id=generate_id("constraint"),
                    description=description,
                    type=type_part,
                    severity=severity
                ))
            except Exception as e:
                self.logger.debug(f"Failed to parse constraint line: {line} - {e}")
                continue
        
        return constraints
    
    def _identify_constraints_heuristic(self, problem_text: str) -> List[Constraint]:
        """Fallback heuristic constraint identification."""
        constraints = []
        text_lower = problem_text.lower()
        
        # Time constraints
        time_keywords = ["deadline", "by", "within", "before", "days", "weeks", "months"]
        if any(keyword in text_lower for keyword in time_keywords):
            constraints.append(Constraint(
                id=generate_id("constraint"),
                description="Time constraint identified in problem description",
                type="time",
                severity="hard"
            ))
        
        # Resource constraints
        resource_keywords = ["budget", "cost", "resources", "limited", "available"]
        if any(keyword in text_lower for keyword in resource_keywords):
            constraints.append(Constraint(
                id=generate_id("constraint"),
                description="Resource constraint identified in problem description",
                type="resource",
                severity="hard"
            ))
        
        # Quality constraints
        quality_keywords = ["quality", "performance", "accuracy", "reliable", "robust"]
        if any(keyword in text_lower for keyword in quality_keywords):
            constraints.append(Constraint(
                id=generate_id("constraint"),
                description="Quality constraint identified in problem description",
                type="quality",
                severity="soft"
            ))
        
        # Technical constraints
        technical_keywords = ["compatible", "integrate", "platform", "technology", "framework"]
        if any(keyword in text_lower for keyword in technical_keywords):
            constraints.append(Constraint(
                id=generate_id("constraint"),
                description="Technical constraint identified in problem description",
                type="technical",
                severity="hard"
            ))
        
        return constraints
    
    def generate_success_criteria(self, problem: ProblemDefinition) -> List[SuccessCriterion]:
        """
        Creates measurable success criteria using LLM for intelligent generation.
        
        Args:
            problem: The problem definition
            
        Returns:
            List of SuccessCriterion objects
        """
        # Try LLM-based generation first
        if self.openevolve_client and OPENEVOLVE_AVAILABLE:
            try:
                llm_criteria = self._generate_criteria_with_llm(problem)
                if llm_criteria and len(llm_criteria) >= 2:
                    self.logger.info(f"LLM generated {len(llm_criteria)} success criteria")
                    return llm_criteria
            except Exception as e:
                self.logger.warning(f"LLM criteria generation failed: {e}")
        
        # Fallback to template-based generation
        return self._generate_criteria_template(problem)
    
    def _generate_criteria_with_llm(self, problem: ProblemDefinition) -> List[SuccessCriterion]:
        """Use LLM to generate intelligent, specific success criteria."""
        constraints_desc = "\n".join([f"- {c.description}" for c in problem.constraints[:5]]) if problem.constraints else "None"
        
        prompt = f"""You are an expert at defining measurable success criteria. Create specific, measurable success criteria for this problem.

PROBLEM:
Title: {problem.title}
Description: {problem.description}
Type: {problem.problem_type.value}
Domain: {problem.domain_context.domain}
Complexity: {problem.complexity_score.overall_complexity}/10
Constraints: 
{constraints_desc}

SUCCESS CRITERIA GENERATION:
Create 3-5 SMART (Specific, Measurable, Achievable, Relevant, Time-bound) success criteria.

For each criterion provide:
1. Description: Clear, specific description of what success looks like
2. Metric: How to measure it (quantitative if possible)
3. Threshold: Minimum acceptable value (0.0-1.0 scale or specific number)
4. Validation: How to validate achievement

Format EXACTLY as:
---
CRITERION 1
Description: <specific description>
Metric: <measurable metric>
Threshold: <numeric threshold>
Validation: <validation method>
---

Provide 3-5 criteria. Be specific and measurable."""
        
        result = self.openevolve_client.evolve(
            content=prompt,
            evolution_mode="standard",
            content_type="analysis",
            max_iterations=1,
            temperature=0.3,
            max_tokens=1000
        )
        
        if result.success and result.best_code:
            return self._parse_criteria_response(result.best_code)
        
        return []
    
    def _parse_criteria_response(self, response: str) -> List[SuccessCriterion]:
        """Parse LLM success criteria response."""
        criteria = []
        sections = response.split('---')
        
        for section in sections:
            section = section.strip()
            if not section or 'CRITERION' not in section:
                continue
            
            try:
                description = self._extract_criteria_field(section, 'Description:')
                metric = self._extract_criteria_field(section, 'Metric:')
                threshold_str = self._extract_criteria_field(section, 'Threshold:')
                validation = self._extract_criteria_field(section, 'Validation:')
                
                if not description or not metric:
                    continue
                
                # Parse threshold
                try:
                    threshold = float(threshold_str.split()[0])
                except:
                    threshold = 0.8
                
                criterion = SuccessCriterion(
                    id=generate_id("criterion"),
                    description=description,
                    metric=metric,
                    threshold=threshold,
                    validation_method=validation or "review"
                )
                criteria.append(criterion)
                
            except Exception as e:
                self.logger.debug(f"Failed to parse criterion section: {e}")
                continue
        
        return criteria
    
    def _extract_criteria_field(self, text: str, field_name: str) -> str:
        """Extract field value from criteria text."""
        lines = text.split('\n')
        for line in lines:
            if line.strip().startswith(field_name):
                return line.split(':', 1)[1].strip()
        return ""
    
    def _generate_criteria_template(self, problem: ProblemDefinition) -> List[SuccessCriterion]:
        """Fallback template-based criteria generation."""
        criteria = []
        
        # Generate criteria based on problem type
        if problem.problem_type == ProblemType.RESEARCH:
            criteria.append(SuccessCriterion(
                id=generate_id("criterion"),
                description="Research findings are documented and validated",
                metric="documentation_completeness",
                threshold=0.9,
                validation_method="peer_review"
            ))
        
        elif problem.problem_type == ProblemType.IMPLEMENTATION:
            criteria.append(SuccessCriterion(
                id=generate_id("criterion"),
                description="Implementation passes all functional tests",
                metric="test_pass_rate",
                threshold=0.95,
                validation_method="automated_testing"
            ))
        
        elif problem.problem_type == ProblemType.ANALYSIS:
            criteria.append(SuccessCriterion(
                id=generate_id("criterion"),
                description="Analysis provides actionable insights",
                metric="insight_quality",
                threshold=0.8,
                validation_method="expert_review"
            ))
        
        elif problem.problem_type == ProblemType.OPTIMIZATION:
            criteria.append(SuccessCriterion(
                id=generate_id("criterion"),
                description="Performance improvement meets target",
                metric="performance_gain",
                threshold=0.2,
                validation_method="benchmark_testing"
            ))
        
        elif problem.problem_type == ProblemType.DESIGN:
            criteria.append(SuccessCriterion(
                id=generate_id("criterion"),
                description="Design meets all requirements and constraints",
                metric="requirement_coverage",
                threshold=1.0,
                validation_method="design_review"
            ))
        
        # Add complexity-based criterion
        if problem.complexity_score.overall_complexity > 7.0:
            criteria.append(SuccessCriterion(
                id=generate_id("criterion"),
                description="Solution maintains manageable complexity",
                metric="complexity_score",
                threshold=7.0,
                validation_method="complexity_analysis"
            ))
        
        return criteria
    
    def validate_problem_definition(self, problem: ProblemDefinition) -> tuple[bool, List[str]]:
        """
        Ensures problem is well-formed.
        
        Args:
            problem: The problem definition to validate
            
        Returns:
            Tuple of (is_valid, list of validation errors)
        """
        errors = []
        
        # Check required fields
        if not problem.title or len(problem.title.strip()) == 0:
            errors.append("Problem title is required")
        
        if not problem.description or len(problem.description.strip()) < 10:
            errors.append("Problem description must be at least 10 characters")
        
        if not problem.domain_context.domain:
            errors.append("Problem domain must be identified")
        
        if problem.complexity_score.overall_complexity < 0 or problem.complexity_score.overall_complexity > 10:
            errors.append("Complexity score must be between 0 and 10")
        
        if len(problem.success_criteria) == 0:
            errors.append("At least one success criterion is required")
        
        return (len(errors) == 0, errors)
    
    def _extract_title(self, problem_text: str) -> str:
        """Extract a title from problem text if not provided."""
        # Take first sentence or first 50 characters
        sentences = re.split(r'[.!?]+', problem_text)
        if sentences:
            title = sentences[0].strip()
            if len(title) > 50:
                title = title[:47] + "..."
            return title
        return "Untitled Problem"
