"""
Sovereign-Grade Problem Decomposition System - Gauntlet Integration
Decomposition-specific gauntlets for verification and validation.
"""

import logging
from typing import List, Dict, Any, Optional
from abc import ABC, abstractmethod
from datetime import datetime

from sovereign_data_models import (
    DecompositionPlan, SubProblem, ValidationResult, Feedback, generate_id
)

logger = logging.getLogger(__name__)


class DecompositionGauntlet(ABC):
    """Base class for decomposition gauntlets."""
    
    def __init__(self, name: str):
        self.name = name
        self.logger = logging.getLogger(f"{__name__}.{name}")
    
    @abstractmethod
    def run(self, plan: DecompositionPlan) -> ValidationResult:
        """
        Run the gauntlet on a decomposition plan.
        
        Args:
            plan: The decomposition plan to validate
            
        Returns:
            ValidationResult with pass/fail, score, and feedback
        """
        pass
    
    def _create_validation_result(
        self, 
        passed: bool, 
        score: float, 
        feedback: str, 
        improvements: List[str]
    ) -> ValidationResult:
        """Helper to create validation result."""
        return ValidationResult(
            validator=self.name,
            passed=passed,
            score=score,
            feedback=feedback,
            improvements=improvements,
            timestamp=datetime.now()
        )


class CoherenceGauntlet(DecompositionGauntlet):
    """Verifies logical consistency of decomposition using LLM semantic analysis."""
    
    def __init__(self, openevolve_client=None):
        super().__init__("coherence_gauntlet")
        self.min_score = 0.7
        self.openevolve_client = openevolve_client
        if not self.openevolve_client:
            try:
                from openevolve_client import OpenEvolveClient
                self.openevolve_client = OpenEvolveClient()
            except:
                self.logger.warning("OpenEvolve client not available for coherence gauntlet")
    
    def run(self, plan: DecompositionPlan) -> ValidationResult:
        """
        Checks for logical consistency and coherence using LLM analysis.
        
        Validates:
        - Sub-problems align with parent problem
        - Sub-problems don't overlap excessively
        - Success criteria are consistent
        - Complexity distribution is reasonable
        """
        self.logger.info(f"Running coherence gauntlet on plan: {plan.id}")
        
        improvements = []
        score = 1.0
        
        # Check 1: Sub-problems exist
        if not plan.sub_problems:
            return self._create_validation_result(
                passed=False,
                score=0.0,
                feedback="No sub-problems defined in decomposition plan",
                improvements=["Create at least one sub-problem"]
            )
        
        # Try LLM-based coherence check for deep semantic analysis
        if self.openevolve_client and len(plan.sub_problems) <= 10:  # Limit for token efficiency
            try:
                llm_result = self._check_coherence_with_llm(plan)
                if llm_result:
                    self.logger.info(f"LLM coherence check: {llm_result['score']:.2f}")
                    return self._create_validation_result(
                        passed=llm_result['score'] >= self.min_score,
                        score=llm_result['score'],
                        feedback=llm_result['feedback'],
                        improvements=llm_result['improvements']
                    )
            except Exception as e:
                self.logger.warning(f"LLM coherence check failed: {e}, using heuristic")
        
        # Fallback to heuristic checks
        # Check 2: Sub-problem alignment with parent
        alignment_score = self._check_alignment(plan)
        score *= alignment_score
        if alignment_score < 0.8:
            improvements.append("Improve alignment between sub-problems and parent problem")
        
        # Check 3: Overlap detection
        overlap_score = self._check_overlap(plan)
        score *= overlap_score
        if overlap_score < 0.8:
            improvements.append("Reduce overlap between sub-problems")
        
        # Check 4: Success criteria consistency
        criteria_score = self._check_success_criteria(plan)
        score *= criteria_score
        if criteria_score < 0.8:
            improvements.append("Ensure all sub-problems have clear success criteria")
        
        # Check 5: Complexity distribution
        complexity_score = self._check_complexity_distribution(plan)
        score *= complexity_score
        if complexity_score < 0.8:
            improvements.append("Balance complexity across sub-problems")
        
        passed = score >= self.min_score
        feedback = f"Coherence score: {score:.2f}. "
        if passed:
            feedback += "Decomposition is logically coherent."
        else:
            feedback += f"Coherence below threshold ({self.min_score}). Improvements needed."
        
        return self._create_validation_result(passed, score, feedback, improvements)
    
    def _check_coherence_with_llm(self, plan: DecompositionPlan) -> Optional[Dict[str, Any]]:
        """Use LLM to perform deep semantic coherence analysis."""
        # Get parent problem from plan
        from sovereign_persistence import SovereignPersistence
        db = SovereignPersistence()
        problem = db.get_problem(plan.problem_id)
        if not problem:
            return None
        
        # Build sub-problems summary
        sp_summary = "\n".join([
            f"{i+1}. {sp.title}\n   Description: {sp.description}\n   Type: {sp.type.value}"
            for i, sp in enumerate(plan.sub_problems[:10])  # Limit to 10 for tokens
        ])
        
        prompt = f"""You are an expert at evaluating problem decomposition quality. Assess the COHERENCE of this decomposition.

PARENT PROBLEM:
Title: {problem.title}
Description: {problem.description}
Domain: {problem.domain_context.domain}

SUB-PROBLEMS:
{sp_summary}

COHERENCE EVALUATION:
Assess these aspects (each 0-10):

1. ALIGNMENT: Do sub-problems directly address the parent problem?
2. COVERAGE: Do sub-problems cover all aspects of the parent problem?
3. OVERLAP: Are sub-problems distinct without excessive overlap?
4. LOGICAL FLOW: Do sub-problems follow a logical progression?
5. GRANULARITY: Is the decomposition at an appropriate level of detail?

Provide your assessment in this EXACT format:
Alignment: <score>
Coverage: <score>
Overlap: <score>
LogicalFlow: <score>
Granularity: <score>
OverallScore: <average score>
Feedback: <2-3 sentence summary>
Improvements: <improvement1> | <improvement2> | <improvement3>

Be critical and precise."""
        
        result = self.openevolve_client.evolve(
            content=prompt,
            evolution_mode="standard",
            content_type="analysis",
            max_iterations=1,
            temperature=0.3,
            max_tokens=500
        )
        
        if result.success and result.best_code:
            return self._parse_coherence_response(result.best_code)
        
        return None
    
    def _parse_coherence_response(self, response: str) -> Dict[str, Any]:
        """Parse LLM coherence assessment."""
        lines = response.strip().split('\n')
        scores = {}
        feedback = ""
        improvements = []
        
        for line in lines:
            line = line.strip()
            if ':' not in line:
                continue
            
            key, value = line.split(':', 1)
            key = key.strip()
            value = value.strip()
            
            if key in ['Alignment', 'Coverage', 'Overlap', 'LogicalFlow', 'Granularity', 'OverallScore']:
                try:
                    scores[key] = float(value)
                except:
                    pass
            elif key == 'Feedback':
                feedback = value
            elif key == 'Improvements':
                improvements = [i.strip() for i in value.split('|') if i.strip()]
        
        # Calculate overall score (0-1 scale)
        overall = scores.get('OverallScore', 5.0) / 10.0
        
        return {
            'score': overall,
            'feedback': feedback or f"Coherence assessment: {overall:.2f}",
            'improvements': improvements or ["Review decomposition structure"]
        }
    
    def _check_alignment(self, plan: DecompositionPlan) -> float:
        """Check if sub-problems align with parent problem."""
        # Simple heuristic: check if sub-problem types match parent problem type
        score = 1.0
        
        # All sub-problems should have descriptions
        for sp in plan.sub_problems:
            if not sp.description or len(sp.description.strip()) < 10:
                score *= 0.9
        
        return max(0.0, score)
    
    def _check_overlap(self, plan: DecompositionPlan) -> float:
        """Check for excessive overlap between sub-problems."""
        if len(plan.sub_problems) < 2:
            return 1.0
        
        # Simple heuristic: check title similarity
        titles = [sp.title.lower() for sp in plan.sub_problems]
        overlap_count = 0
        
        for i in range(len(titles)):
            for j in range(i + 1, len(titles)):
                # Check if titles are too similar
                words_i = set(titles[i].split())
                words_j = set(titles[j].split())
                if words_i and words_j:
                    similarity = len(words_i.intersection(words_j)) / len(words_i.union(words_j))
                    if similarity > 0.7:
                        overlap_count += 1
        
        # Penalize excessive overlap
        max_overlaps = len(plan.sub_problems) // 3
        if overlap_count > max_overlaps:
            return 0.6
        return 1.0
    
    def _check_success_criteria(self, plan: DecompositionPlan) -> float:
        """Check if success criteria are well-defined."""
        if not plan.sub_problems:
            return 0.0
        
        criteria_count = sum(1 for sp in plan.sub_problems if sp.success_criteria)
        ratio = criteria_count / len(plan.sub_problems)
        return ratio
    
    def _check_complexity_distribution(self, plan: DecompositionPlan) -> float:
        """Check if complexity is reasonably distributed."""
        if not plan.sub_problems:
            return 0.0
        
        complexities = [sp.complexity_score.overall_complexity for sp in plan.sub_problems]
        avg_complexity = sum(complexities) / len(complexities)
        
        # Check variance - we want balanced complexity
        variance = sum((c - avg_complexity) ** 2 for c in complexities) / len(complexities)
        
        # Lower variance is better (more balanced)
        if variance < 4.0:
            return 1.0
        elif variance < 9.0:
            return 0.8
        else:
            return 0.6


class CompletenessGauntlet(DecompositionGauntlet):
    """Verifies all problem aspects are addressed using LLM analysis."""
    
    def __init__(self, openevolve_client=None):
        super().__init__("completeness_gauntlet")
        self.min_score = 0.75
        self.openevolve_client = openevolve_client
        if not self.openevolve_client:
            try:
                from openevolve_client import OpenEvolveClient
                self.openevolve_client = OpenEvolveClient()
            except:
                self.logger.warning("OpenEvolve client not available for completeness gauntlet")
    
    def run(self, plan: DecompositionPlan) -> ValidationResult:
        """
        Checks coverage of original problem using LLM semantic analysis.
        
        Validates:
        - All problem aspects are covered by sub-problems
        - No critical gaps in decomposition
        - Success criteria cover all requirements
        - All constraints are addressed
        """
        self.logger.info(f"Running completeness gauntlet on plan: {plan.id}")
        
        improvements = []
        score = 1.0
        
        # Try LLM-based completeness check
        if self.openevolve_client and len(plan.sub_problems) <= 10:
            try:
                llm_result = self._check_completeness_with_llm(plan)
                if llm_result:
                    self.logger.info(f"LLM completeness check: {llm_result['score']:.2f}")
                    return self._create_validation_result(
                        passed=llm_result['score'] >= self.min_score,
                        score=llm_result['score'],
                        feedback=llm_result['feedback'],
                        improvements=llm_result['improvements']
                    )
            except Exception as e:
                self.logger.warning(f"LLM completeness check failed: {e}, using heuristic")
        
        # Fallback to heuristic checks
        # Check 1: Minimum number of sub-problems
        if len(plan.sub_problems) < 2:
            improvements.append("Consider breaking down into more sub-problems")
            score *= 0.7
        
        # Check 2: Sub-problem types coverage
        type_coverage = self._check_type_coverage(plan)
        score *= type_coverage
        if type_coverage < 0.8:
            improvements.append("Ensure diverse sub-problem types (research, analysis, implementation, validation)")
        
        # Check 3: Success criteria coverage
        criteria_coverage = self._check_criteria_coverage(plan)
        score *= criteria_coverage
        if criteria_coverage < 0.8:
            improvements.append("Add success criteria to all sub-problems")
        
        # Check 4: Dependency coverage
        dependency_coverage = self._check_dependency_coverage(plan)
        score *= dependency_coverage
        if dependency_coverage < 0.8:
            improvements.append("Define dependencies between sub-problems")
        
        passed = score >= self.min_score
        feedback = f"Completeness score: {score:.2f}. "
        if passed:
            feedback += "Decomposition covers all problem aspects."
        else:
            feedback += f"Completeness below threshold ({self.min_score}). Coverage gaps detected."
        
        return self._create_validation_result(passed, score, feedback, improvements)
    
    def _check_completeness_with_llm(self, plan: DecompositionPlan) -> Optional[Dict[str, Any]]:
        """Use LLM to check if decomposition completely covers the problem."""
        from sovereign_persistence import SovereignPersistence
        db = SovereignPersistence()
        problem = db.get_problem(plan.problem_id)
        if not problem:
            return None
        
        # Build sub-problems summary
        sp_summary = "\n".join([
            f"{i+1}. {sp.title} ({sp.type.value})"
            for i, sp in enumerate(plan.sub_problems[:10])
        ])
        
        # Build constraints summary
        constraints_summary = "\n".join([
            f"- {c.description} ({c.type})"
            for c in problem.constraints[:5]
        ]) if problem.constraints else "None specified"
        
        prompt = f"""You are an expert at evaluating problem decomposition completeness. Identify any GAPS in this decomposition.

PARENT PROBLEM:
Title: {problem.title}
Description: {problem.description}
Constraints: 
{constraints_summary}

PROPOSED SUB-PROBLEMS:
{sp_summary}

COMPLETENESS EVALUATION:
Assess whether the sub-problems COMPLETELY cover the parent problem:

1. COVERAGE: Do sub-problems address all aspects of the problem? (0-10)
2. CONSTRAINTS: Are all constraints addressed? (0-10)
3. REQUIREMENTS: Are all implicit requirements covered? (0-10)
4. GAPS: Are there any missing pieces? (0-10, 10=no gaps)

Provide assessment in this EXACT format:
Coverage: <score>
Constraints: <score>
Requirements: <score>
Gaps: <score>
OverallScore: <average>
Feedback: <2-3 sentences>
MissingAspects: <aspect1> | <aspect2> | <aspect3>

Be thorough and identify any gaps."""
        
        result = self.openevolve_client.evolve(
            content=prompt,
            evolution_mode="standard",
            content_type="analysis",
            max_iterations=1,
            temperature=0.3,
            max_tokens=500
        )
        
        if result.success and result.best_code:
            return self._parse_completeness_response(result.best_code)
        
        return None
    
    def _parse_completeness_response(self, response: str) -> Dict[str, Any]:
        """Parse LLM completeness assessment."""
        lines = response.strip().split('\n')
        overall = 5.0
        feedback = ""
        improvements = []
        
        for line in lines:
            line = line.strip()
            if ':' not in line:
                continue
            
            key, value = line.split(':', 1)
            key = key.strip()
            value = value.strip()
            
            if key == 'OverallScore':
                try:
                    overall = float(value)
                except:
                    pass
            elif key == 'Feedback':
                feedback = value
            elif key == 'MissingAspects':
                improvements = [f"Address: {i.strip()}" for i in value.split('|') if i.strip()]
        
        return {
            'score': overall / 10.0,
            'feedback': feedback or f"Completeness assessment: {overall/10.0:.2f}",
            'improvements': improvements or ["Review problem coverage"]
        }
    
    def _check_type_coverage(self, plan: DecompositionPlan) -> float:
        """Check if different sub-problem types are represented."""
        if not plan.sub_problems:
            return 0.0
        
        types_present = set(sp.type for sp in plan.sub_problems)
        # Ideally we want at least 2-3 different types
        type_count = len(types_present)
        
        if type_count >= 3:
            return 1.0
        elif type_count == 2:
            return 0.85
        else:
            return 0.7
    
    def _check_criteria_coverage(self, plan: DecompositionPlan) -> float:
        """Check if success criteria are defined for all sub-problems."""
        if not plan.sub_problems:
            return 0.0
        
        with_criteria = sum(1 for sp in plan.sub_problems if sp.success_criteria)
        return with_criteria / len(plan.sub_problems)
    
    def _check_dependency_coverage(self, plan: DecompositionPlan) -> float:
        """Check if dependencies are properly defined."""
        if len(plan.sub_problems) < 2:
            return 1.0  # No dependencies needed for single sub-problem
        
        # At least some sub-problems should have dependencies
        with_deps = sum(1 for sp in plan.sub_problems if sp.dependencies)
        
        # We expect at least 30% of sub-problems to have dependencies
        expected_ratio = 0.3
        actual_ratio = with_deps / len(plan.sub_problems)
        
        if actual_ratio >= expected_ratio:
            return 1.0
        else:
            return actual_ratio / expected_ratio


class FeasibilityGauntlet(DecompositionGauntlet):
    """Verifies sub-problems are solvable."""
    
    def __init__(self, openevolve_client=None):
        super().__init__("feasibility_gauntlet")
        self.min_score = 0.7
        self.max_complexity = 8.0
        self.max_effort = 80  # person-hours
        self.openevolve_client = openevolve_client
        if not self.openevolve_client:
            try:
                from openevolve_client import OpenEvolveClient
                self.openevolve_client = OpenEvolveClient()
            except:
                self.logger.warning("OpenEvolve client not available for feasibility gauntlet")
    
    def run(self, plan: DecompositionPlan) -> ValidationResult:
        """
        Checks if sub-problems can be solved with available resources.
        
        Validates:
        - Sub-problem complexity is manageable
        - Effort estimates are reasonable
        - No impossible constraints
        - Resources are sufficient
        """
        self.logger.info(f"Running feasibility gauntlet on plan: {plan.id}")
        
        improvements = []
        
        # Try LLM-based feasibility check
        if self.openevolve_client and len(plan.sub_problems) <= 10:
            try:
                llm_result = self._check_feasibility_with_llm(plan)
                if llm_result:
                    self.logger.info(f"LLM feasibility check: {llm_result['score']:.2f}")
                    return self._create_validation_result(
                        passed=llm_result['score'] >= self.min_score,
                        score=llm_result['score'],
                        feedback=llm_result['feedback'],
                        improvements=llm_result['improvements']
                    )
            except Exception as e:
                self.logger.warning(f"LLM feasibility check failed: {e}, using heuristic")

        score = 1.0
        
        # Check 1: Complexity feasibility
        complexity_feasible = self._check_complexity_feasibility(plan)
        score *= complexity_feasible
        if complexity_feasible < 0.8:
            improvements.append(f"Some sub-problems exceed max complexity ({self.max_complexity})")
        
        # Check 2: Effort feasibility
        effort_feasible = self._check_effort_feasibility(plan)
        score *= effort_feasible
        if effort_feasible < 0.8:
            improvements.append(f"Total effort may exceed reasonable limits")
        
        # Check 3: Dependency feasibility
        dependency_feasible = self._check_dependency_feasibility(plan)
        score *= dependency_feasible
        if dependency_feasible < 0.8:
            improvements.append("Dependency structure may be too complex")
        
        # Check 4: Resource availability
        resource_feasible = self._check_resource_feasibility(plan)
        score *= resource_feasible
        if resource_feasible < 0.8:
            improvements.append("Consider resource constraints")
        
        passed = score >= self.min_score
        feedback = f"Feasibility score: {score:.2f}. "
        if passed:
            feedback += "All sub-problems appear solvable."
        else:
            feedback += f"Feasibility below threshold ({self.min_score}). Some sub-problems may be too complex."
        
        return self._create_validation_result(passed, score, feedback, improvements)

    def _check_feasibility_with_llm(self, plan: DecompositionPlan) -> Optional[Dict[str, Any]]:
        """Use LLM to perform deep semantic feasibility analysis."""
        from sovereign_persistence import SovereignPersistence
        db = SovereignPersistence()
        problem = db.get_problem(plan.problem_id)
        if not problem:
            return None

        sp_summary = "\n".join([
            f"{i+1}. {sp.title}\n   Description: {sp.description}\n   Complexity: {sp.complexity_score.overall_complexity}/10\n   Effort: {sp.estimated_effort}h"
            for i, sp in enumerate(plan.sub_problems[:10])
        ])

        prompt = f"""You are an expert project manager. Assess the FEASIBILITY of this decomposition.\n\nPARENT PROBLEM:\nTitle: {problem.title}\nDescription: {problem.description}\n\nSUB-PROBLEMS:\n{sp_summary}\n\nFEASIBILITY EVALUATION:\nAssess these aspects (each 0-10):\n\n1. COMPLEXITY: Is the complexity of each sub-problem manageable?\n2. EFFORT: Are the effort estimates realistic?\n3. RESOURCES: Are the (implicit) resources likely sufficient?\n4. SKILLS: Are the required skills reasonable to assume available?\n\nProvide your assessment in this EXACT format:\nComplexity: <score>\nEffort: <score>\nResources: <score>\nSkills: <score>\nOverallScore: <average score>\nFeedback: <2-3 sentence summary>\nImprovements: <improvement1> | <improvement2> | <improvement3>\n\nBe critical and realistic."""

        result = self.openevolve_client.evolve(
            content=prompt,
            evolution_mode="standard",
            content_type="analysis",
            max_iterations=1,
            temperature=0.3,
            max_tokens=500
        )

        if result.success and result.best_code:
            return self._parse_feasibility_response(result.best_code)

        return None

    def _parse_feasibility_response(self, response: str) -> Dict[str, Any]:
        """Parse LLM feasibility assessment."""
        lines = response.strip().split('\n')
        scores = {}
        feedback = ""
        improvements = []

        for line in lines:
            line = line.strip()
            if ':' not in line:
                continue
            
            key, value = line.split(':', 1)
            key = key.strip()
            value = value.strip()

            if key in ['Complexity', 'Effort', 'Resources', 'Skills', 'OverallScore']:
                try:
                    scores[key] = float(value)
                except:
                    pass
            elif key == 'Feedback':
                feedback = value
            elif key == 'Improvements':
                improvements = [i.strip() for i in value.split('|') if i.strip()]

        overall = scores.get('OverallScore', 5.0) / 10.0

        return {
            'score': overall,
            'feedback': feedback or f"Feasibility assessment: {overall:.2f}",
            'improvements': improvements or ["Review feasibility of sub-problems"]
        }
    
    def _check_complexity_feasibility(self, plan: DecompositionPlan) -> float:
        """Check if complexity is manageable."""
        if not plan.sub_problems:
            return 0.0
        
        over_limit = sum(1 for sp in plan.sub_problems 
                        if sp.complexity_score.overall_complexity > self.max_complexity)
        
        if over_limit == 0:
            return 1.0
        
        # Penalize based on how many are over limit
        penalty = over_limit / len(plan.sub_problems)
        return max(0.5, 1.0 - penalty)
    
    def _check_effort_feasibility(self, plan: DecompositionPlan) -> float:
        """Check if effort estimates are reasonable."""
        if not plan.sub_problems:
            return 0.0
        
        total_effort = sum(sp.estimated_effort for sp in plan.sub_problems)
        
        if total_effort <= self.max_effort:
            return 1.0
        elif total_effort <= self.max_effort * 1.5:
            return 0.8
        else:
            return 0.6
    
    def _check_dependency_feasibility(self, plan: DecompositionPlan) -> float:
        """Check if dependency structure is feasible."""
        if len(plan.sub_problems) < 2:
            return 1.0
        
        # Check for circular dependencies (simple check)
        visited = set()
        
        def has_cycle(sp_id: str, path: set) -> bool:
            if sp_id in path:
                return True
            if sp_id in visited:
                return False
            
            visited.add(sp_id)
            path.add(sp_id)
            
            sp = next((s for s in plan.sub_problems if s.id == sp_id), None)
            if sp:
                for dep in sp.dependencies:
                    if has_cycle(dep, path.copy()):
                        return True
            
            return False
        
        # Check each sub-problem for cycles
        for sp in plan.sub_problems:
            if has_cycle(sp.id, set()):
                return 0.5  # Circular dependency detected
        
        return 1.0
    
    def _check_resource_feasibility(self, plan: DecompositionPlan) -> float:
        """Check if resources are sufficient."""
        # Simple check: ensure sub-problems have reasonable priorities
        if not plan.sub_problems:
            return 0.0
        
        # Check if priorities are set
        with_priority = sum(1 for sp in plan.sub_problems if sp.priority > 0)
        return with_priority / len(plan.sub_problems)


class DependencyGauntlet(DecompositionGauntlet):
    """Validates dependency graph structure."""
    
    def __init__(self, openevolve_client=None):
        super().__init__("dependency_gauntlet")
        self.min_score = 0.8
        self.openevolve_client = openevolve_client
        if not self.openevolve_client:
            try:
                from openevolve_client import OpenEvolveClient
                self.openevolve_client = OpenEvolveClient()
            except:
                self.logger.warning("OpenEvolve client not available for dependency gauntlet")
    
    def run(self, plan: DecompositionPlan) -> ValidationResult:
        """
        Validates dependency graph structure.
        
        Validates:
        - No circular dependencies
        - Dependencies reference valid sub-problems
        - Dependency graph is acyclic
        - Critical path is reasonable
        """
        self.logger.info(f"Running dependency gauntlet on plan: {plan.id}")

        # Try LLM-based dependency check
        if self.openevolve_client and len(plan.sub_problems) <= 10:
            try:
                llm_result = self._check_dependency_with_llm(plan)
                if llm_result:
                    self.logger.info(f"LLM dependency check: {llm_result['score']:.2f}")
                    return self._create_validation_result(
                        passed=llm_result['score'] >= self.min_score,
                        score=llm_result['score'],
                        feedback=llm_result['feedback'],
                        improvements=llm_result['improvements']
                    )
            except Exception as e:
                self.logger.warning(f"LLM dependency check failed: {e}, using heuristic")
        
        improvements = []
        score = 1.0
        
        # Check 1: Valid dependency references
        valid_refs = self._check_valid_references(plan)
        score *= valid_refs
        if valid_refs < 1.0:
            improvements.append("Some dependencies reference non-existent sub-problems")
        
        # Check 2: No circular dependencies
        no_cycles = self._check_no_cycles(plan)
        score *= no_cycles
        if no_cycles < 1.0:
            improvements.append("Circular dependencies detected - must be resolved")
        
        # Check 3: Dependency graph structure
        structure_score = self._check_graph_structure(plan)
        score *= structure_score
        if structure_score < 0.8:
            improvements.append("Dependency graph structure could be improved")
        
        # Check 4: Execution order feasibility
        execution_feasible = self._check_execution_order(plan)
        score *= execution_feasible
        if execution_feasible < 0.8:
            improvements.append("Execution order may be suboptimal")
        
        passed = score >= self.min_score
        feedback = f"Dependency score: {score:.2f}. "
        if passed:
            feedback += "Dependency graph is valid and well-structured."
        else:
            feedback += f"Dependency issues detected. Score below threshold ({self.min_score})."
        
        return self._create_validation_result(passed, score, feedback, improvements)

    def _check_dependency_with_llm(self, plan: DecompositionPlan) -> Optional[Dict[str, Any]]:
        """Use LLM to perform deep semantic dependency analysis."""
        sp_summary = "\n".join([
            f"{i+1}. ID: {sp.id}, Title: {sp.title}, Dependencies: {sp.dependencies}"
            for i, sp in enumerate(plan.sub_problems[:10])
        ])

        prompt = f"""You are an expert in dependency analysis. Assess the DEPENDENCY STRUCTURE of this decomposition.

SUB-PROBLEMS:
{sp_summary}

DEPENDENCY EVALUATION:
Assess these aspects (each 0-10):

1. CORRECTNESS: Are the dependencies logically correct?
2. COMPLETENESS: Are there any missing dependencies?
3. CYCLES: Are there any circular dependencies?
4. GRANULARITY: Are the dependencies at the right level of detail?

Provide your assessment in this EXACT format:
Correctness: <score>
Completeness: <score>
Cycles: <score>
Granularity: <score>
OverallScore: <average score>
Feedback: <2-3 sentence summary>
Improvements: <improvement1> | <improvement2> | <improvement3>

Be critical and precise."""

        result = self.openevolve_client.evolve(
            content=prompt,
            evolution_mode="standard",
            content_type="analysis",
            max_iterations=1,
            temperature=0.3,
            max_tokens=500
        )

        if result.success and result.best_code:
            return self._parse_dependency_response(result.best_code)

        return None

    def _parse_dependency_response(self, response: str) -> Dict[str, Any]:
        """Parse LLM dependency assessment."""
        lines = response.strip().split('\n')
        scores = {}
        feedback = ""
        improvements = []

        for line in lines:
            line = line.strip()
            if ':' not in line:
                continue
            
            key, value = line.split(':', 1)
            key = key.strip()
            value = value.strip()

            if key in ['Correctness', 'Completeness', 'Cycles', 'Granularity', 'OverallScore']:
                try:
                    scores[key] = float(value)
                except:
                    pass
            elif key == 'Feedback':
                feedback = value
            elif key == 'Improvements':
                improvements = [i.strip() for i in value.split('|') if i.strip()]

        overall = scores.get('OverallScore', 5.0) / 10.0

        return {
            'score': overall,
            'feedback': feedback or f"Dependency assessment: {overall:.2f}",
            'improvements': improvements or ["Review dependency structure"]
        }

    
    def _check_valid_references(self, plan: DecompositionPlan) -> float:
        """Check if all dependency references are valid."""
        if not plan.sub_problems:
            return 1.0
        
        valid_ids = {sp.id for sp in plan.sub_problems}
        invalid_count = 0
        total_deps = 0
        
        for sp in plan.sub_problems:
            for dep in sp.dependencies:
                total_deps += 1
                if dep not in valid_ids:
                    invalid_count += 1
        
        if total_deps == 0:
            return 1.0
        
        return 1.0 - (invalid_count / total_deps)
    
    def _check_no_cycles(self, plan: DecompositionPlan) -> float:
        """Check for circular dependencies."""
        if len(plan.sub_problems) < 2:
            return 1.0
        
        def has_cycle(sp_id: str, visited: set, rec_stack: set) -> bool:
            visited.add(sp_id)
            rec_stack.add(sp_id)
            
            sp = next((s for s in plan.sub_problems if s.id == sp_id), None)
            if sp:
                for dep in sp.dependencies:
                    if dep not in visited:
                        if has_cycle(dep, visited, rec_stack):
                            return True
                    elif dep in rec_stack:
                        return True
            
            rec_stack.remove(sp_id)
            return False
        
        visited = set()
        for sp in plan.sub_problems:
            if sp.id not in visited:
                if has_cycle(sp.id, visited, set()):
                    return 0.0  # Cycle detected - critical failure
        
        return 1.0
    
    def _check_graph_structure(self, plan: DecompositionPlan) -> float:
        """Check if graph structure is reasonable."""
        if len(plan.sub_problems) < 2:
            return 1.0
        
        # Check for isolated nodes (no dependencies in or out)
        has_deps_in = set()
        has_deps_out = set()
        
        for sp in plan.sub_problems:
            if sp.dependencies:
                has_deps_out.add(sp.id)
                for dep in sp.dependencies:
                    has_deps_in.add(dep)
        
        # Some nodes should have dependencies
        connected = len(has_deps_in.union(has_deps_out))
        ratio = connected / len(plan.sub_problems)
        
        return ratio
    
    def _check_execution_order(self, plan: DecompositionPlan) -> float:
        """Check if execution order is feasible."""
        if not plan.dependency_graph or not plan.dependency_graph.execution_order:
            return 0.8  # No execution order defined, but not critical
        
        # Check if execution order covers all sub-problems
        order_ids = set(plan.dependency_graph.execution_order)
        all_ids = {sp.id for sp in plan.sub_problems}
        
        coverage = len(order_ids.intersection(all_ids)) / len(all_ids)
        return coverage


class GauntletSystem:
    """Orchestrates decomposition gauntlets."""
    
    def __init__(self, openevolve_client=None):
        self.openevolve_client = openevolve_client
        if not self.openevolve_client:
            try:
                from openevolve_client import OpenEvolveClient
                self.openevolve_client = OpenEvolveClient()
            except:
                self.logger.warning("OpenEvolve client not available for GauntletSystem")

        self.gauntlets = {
            'coherence': CoherenceGauntlet(self.openevolve_client),
            'completeness': CompletenessGauntlet(self.openevolve_client),
            'feasibility': FeasibilityGauntlet(self.openevolve_client),
            'dependency': DependencyGauntlet(self.openevolve_client)
        }
        self.logger = logging.getLogger(__name__)
    
    def run_decomposition_gauntlets(
        self, 
        plan: DecompositionPlan,
        gauntlets: Optional[List[str]] = None
    ) -> Dict[str, ValidationResult]:
        """
        Runs all or specified decomposition gauntlets.
        
        Args:
            plan: The decomposition plan to validate
            gauntlets: Optional list of gauntlet names to run (runs all if None)
            
        Returns:
            Dictionary mapping gauntlet names to ValidationResult objects
        """
        self.logger.info(f"Running gauntlets on plan: {plan.id}")
        
        gauntlets_to_run = gauntlets or list(self.gauntlets.keys())
        results = {}
        
        for gauntlet_name in gauntlets_to_run:
            gauntlet = self.gauntlets.get(gauntlet_name)
            if gauntlet:
                try:
                    result = gauntlet.run(plan)
                    results[gauntlet_name] = result
                    self.logger.info(f"{gauntlet_name}: {'PASS' if result.passed else 'FAIL'} ({result.score:.2f})")
                except Exception as e:
                    self.logger.error(f"Error running {gauntlet_name}: {e}")
                    results[gauntlet_name] = ValidationResult(
                        validator=gauntlet_name,
                        passed=False,
                        score=0.0,
                        feedback=f"Error: {str(e)}",
                        improvements=["Fix gauntlet execution error"],
                        timestamp=datetime.now()
                    )
        
        return results
    
    def process_gauntlet_feedback(
        self, 
        results: Dict[str, ValidationResult]
    ) -> List[Feedback]:
        """
        Converts gauntlet results into actionable feedback.
        
        Args:
            results: Dictionary of gauntlet results
            
        Returns:
            List of Feedback objects
        """
        feedback_list = []
        
        for gauntlet_name, result in results.items():
            # Determine severity based on score
            if result.score >= 0.8:
                severity = "info"
            elif result.score >= 0.6:
                severity = "minor"
            elif result.score >= 0.4:
                severity = "major"
            else:
                severity = "critical"
            
            # Create feedback
            feedback = Feedback(
                id=generate_id("feedback"),
                source=gauntlet_name,
                feedback_type="critique" if not result.passed else "approval",
                content=result.feedback,
                severity=severity,
                actionable=len(result.improvements) > 0,
                timestamp=result.timestamp,
                metadata={
                    'score': result.score,
                    'improvements': result.improvements
                }
            )
            feedback_list.append(feedback)
        
        return feedback_list
    
    def get_overall_quality(self, results: Dict[str, ValidationResult]) -> float:
        """Calculate overall quality score from gauntlet results."""
        if not results:
            return 0.0
        
        scores = [r.score for r in results.values()]
        return sum(scores) / len(scores)
    
    def all_passed(self, results: Dict[str, ValidationResult]) -> bool:
        """Check if all gauntlets passed."""
        return all(r.passed for r in results.values())
