"""
Sovereign-Grade Problem Decomposition System - Integration Orchestrator
Task 15: Complete system integration and end-to-end workflow orchestration.
"""

import logging
from typing import Dict, List, Any, Optional
from datetime import datetime
from dataclasses import dataclass

from problem_analyzer import ProblemAnalyzer
from decomposition_engine import DecompositionEngine
from sovereign_gauntlets import GauntletSystem
from sovereign_team_coordination import TeamCoordinator
from sovereign_quality_assessment import QualityAssessor
from sovereign_solution_orchestration import SolutionOrchestrator
from sovereign_refinement import RefinementCoordinator
from sovereign_knowledge_manager import KnowledgeManager
from sovereign_data_models import (
    ProblemDefinition, DecompositionPlan, SubProblem, 
    SolutionAttempt, generate_id
)

logger = logging.getLogger(__name__)


@dataclass
class IntegrationResult:
    """Result of complete integration workflow."""
    problem_id: str
    plan_id: str
    success: bool
    final_plan: DecompositionPlan
    quality_score: float
    refinement_cycles: int
    solutions: List[SolutionAttempt]
    knowledge_extracted: bool
    execution_time: float
    metadata: Dict[str, Any]


class SovereignIntegrationOrchestrator:
    """
    Orchestrates complete end-to-end workflow integrating all components.
    
    This is the main entry point for the sovereign decomposition system,
    coordinating problem analysis, decomposition, validation, refinement,
    solution tracking, and knowledge extraction.
    """
    
    def __init__(self, orchestrator=None):
        """Initialize all system components with team integration."""
        self.logger = logging.getLogger(__name__)
        self.orchestrator = orchestrator
        
        # Initialize core components
        self.analyzer = ProblemAnalyzer()
        self.engine = DecompositionEngine(self.analyzer)
        self.gauntlet_system = GauntletSystem()
        self.team_coordinator = TeamCoordinator(self.gauntlet_system)
        self.quality_assessor = QualityAssessor()
        self.solution_orchestrator = SolutionOrchestrator()
        self.refinement_coordinator = RefinementCoordinator(
            self.gauntlet_system,
            self.quality_assessor,
            self.team_coordinator
        )
        self.knowledge_manager = KnowledgeManager()
        
        # Import and initialize dependency manager
        from dependency_manager import DependencyManager
        self.dependency_manager = DependencyManager()
        
        # Initialize team systems if available
        self.red_team = None
        self.blue_team = None
        self.evaluator_team = None
        
        try:
            from red_team import RedTeam
            from blue_team import BlueTeam
            from evaluator_team import EvaluatorTeam
            
            self.red_team = RedTeam(orchestrator=orchestrator)
            self.blue_team = BlueTeam(orchestrator=orchestrator)
            self.evaluator_team = EvaluatorTeam(orchestrator=orchestrator)
            self.logger.info("Team systems initialized successfully")
        except ImportError as e:
            self.logger.warning(f"Team systems not available: {e}")
        
        self.logger.info("Sovereign Integration Orchestrator initialized")
    
    def run_complete_workflow(
        self,
        problem_text: str,
        title: str = "",
        strategy: str = 'hybrid',
        max_refinement_cycles: int = 3,
        enable_knowledge_extraction: bool = True
    ) -> IntegrationResult:
        """
        Execute complete end-to-end workflow.
        
        Args:
            problem_text: Problem description
            title: Problem title
            strategy: Decomposition strategy to use
            max_refinement_cycles: Maximum refinement iterations
            enable_knowledge_extraction: Whether to extract knowledge patterns
            
        Returns:
            IntegrationResult with complete workflow results
        """
        start_time = datetime.now()
        self.logger.info(f"Starting complete workflow for: {title or 'Untitled'}")
        
        try:
            # Phase 1: Problem Analysis
            self.logger.info("Phase 1: Analyzing problem...")
            problem = self.analyzer.analyze_problem(problem_text, title)
            
            # Phase 2: Decomposition
            self.logger.info(f"Phase 2: Decomposing with {strategy} strategy...")
            plan = self.engine.decompose(problem, strategy=strategy)
            
            # Phase 2.5: Build Dependency Graph
            self.logger.info("Phase 2.5: Building dependency graph...")
            if plan.sub_problems:
                dependency_graph = self.dependency_manager.build_graph(plan.sub_problems)
                plan.dependency_graph = dependency_graph
                
                # Validate dependencies
                dep_validation = self.dependency_manager.validate_dependencies(dependency_graph)
                if not dep_validation.passed:
                    self.logger.warning(f"Dependency validation issues: {dep_validation.feedback}")
            
            # Phase 3: Validation
            self.logger.info("Phase 3: Running validation gauntlets...")
            gauntlet_results = self.gauntlet_system.run_decomposition_gauntlets(plan)
            
            # Phase 4: Quality Assessment
            self.logger.info("Phase 4: Assessing quality...")
            quality_report = self.quality_assessor.generate_quality_report(plan)
            
            # Phase 5: Refinement (if needed)
            refinement_cycles = 0
            if not quality_report.meets_thresholds and max_refinement_cycles > 0:
                self.logger.info("Phase 5: Refining decomposition...")
                plan, refinement_cycles = self._refine_decomposition(
                    plan, 
                    gauntlet_results,
                    max_refinement_cycles
                )
                # Re-assess quality after refinement
                quality_report = self.quality_assessor.generate_quality_report(plan)
            
            # Phase 6: Team Coordination with Red/Blue/Evaluator Teams
            self.logger.info("Phase 6: Coordinating team review...")
            team_feedback = self._run_team_review(plan)
            
            # Apply team feedback if significant issues found
            if team_feedback and any(f.severity in ['critical', 'major'] for f in team_feedback):
                self.logger.info("Applying team feedback...")
                plan = self._apply_team_feedback(plan, team_feedback)
            
            # Phase 7: Solution Tracking Setup
            self.logger.info("Phase 7: Setting up solution tracking...")
            solutions = self._initialize_solution_tracking(plan)
            
            # Phase 8: Knowledge Extraction
            knowledge_extracted = False
            if enable_knowledge_extraction and quality_report.meets_thresholds:
                self.logger.info("Phase 8: Extracting knowledge patterns...")
                self.knowledge_manager.extract_patterns(
                    plan,
                    success=True,
                    quality_score=quality_report.metrics.overall_score
                )
                knowledge_extracted = True
            
            # Calculate execution time
            execution_time = (datetime.now() - start_time).total_seconds()
            
            # Create result
            result = IntegrationResult(
                problem_id=problem.id,
                plan_id=plan.id,
                success=quality_report.meets_thresholds,
                final_plan=plan,
                quality_score=quality_report.metrics.overall_score,
                refinement_cycles=refinement_cycles,
                solutions=solutions,
                knowledge_extracted=knowledge_extracted,
                execution_time=execution_time,
                metadata={
                    'problem_type': problem.problem_type.value,
                    'strategy': strategy,
                    'sub_problem_count': len(plan.sub_problems),
                    'gauntlet_results': {k: v.passed for k, v in gauntlet_results.items()},
                    'quality_metrics': {
                        'coherence': quality_report.metrics.coherence_score,
                        'completeness': quality_report.metrics.completeness_score,
                        'feasibility': quality_report.metrics.feasibility_score,
                        'integration': quality_report.metrics.integration_score
                    },
                    'team_feedback_count': len(team_feedback) if team_feedback else 0
                }
            )
            
            self.logger.info(
                f"Workflow complete: {result.success}, "
                f"quality={result.quality_score:.2f}, "
                f"time={result.execution_time:.2f}s"
            )
            
            return result
            
        except Exception as e:
            self.logger.error(f"Workflow failed: {e}", exc_info=True)
            execution_time = (datetime.now() - start_time).total_seconds()
            
            # Return failure result
            return IntegrationResult(
                problem_id="",
                plan_id="",
                success=False,
                final_plan=None,
                quality_score=0.0,
                refinement_cycles=0,
                solutions=[],
                knowledge_extracted=False,
                execution_time=execution_time,
                metadata={'error': str(e)}
            )
    
    def _refine_decomposition(
        self,
        plan: DecompositionPlan,
        gauntlet_results: Dict,
        max_cycles: int
    ) -> tuple[DecompositionPlan, int]:
        """
        Refine decomposition based on feedback.
        
        Args:
            plan: Current decomposition plan
            gauntlet_results: Results from gauntlets
            max_cycles: Maximum refinement cycles
            
        Returns:
            Tuple of (refined_plan, cycles_used)
        """
        feedback = self.gauntlet_system.process_gauntlet_feedback(gauntlet_results)
        
        if not feedback:
            self.logger.info("No feedback to process")
            return plan, 0
        
        current_plan = plan
        previous_quality = self.quality_assessor.generate_quality_report(plan).metrics.overall_score
        
        for cycle in range(max_cycles):
            self.logger.info(f"Refinement cycle {cycle + 1}/{max_cycles}")
            
            # Generate refinement plan
            refinement_plan = self.refinement_coordinator.generate_refinement_plan(
                current_plan,
                feedback
            )
            
            if not refinement_plan or not refinement_plan.improvements:
                self.logger.info("No improvements identified")
                return current_plan, cycle
            
            # Execute refinement
            refined_plan, metrics = self.refinement_coordinator.execute_refinement(
                current_plan,
                refinement_plan
            )
            
            # Rebuild dependency graph if structure changed
            if refined_plan.sub_problems:
                dependency_graph = self.dependency_manager.build_graph(refined_plan.sub_problems)
                refined_plan.dependency_graph = dependency_graph
            
            # Re-validate
            new_gauntlet_results = self.gauntlet_system.run_decomposition_gauntlets(refined_plan)
            new_quality = self.quality_assessor.generate_quality_report(refined_plan)
            current_quality = new_quality.metrics.overall_score
            
            # Check if improved
            if new_quality.meets_thresholds:
                self.logger.info(f"Quality thresholds met after {cycle + 1} cycles")
                return refined_plan, cycle + 1
            
            # Check for convergence (minimal improvement)
            improvement = current_quality - previous_quality
            if improvement < 0.01:
                self.logger.info(f"Converged after {cycle + 1} cycles (improvement: {improvement:.3f})")
                return refined_plan, cycle + 1
            
            # Update for next cycle
            current_plan = refined_plan
            previous_quality = current_quality
            feedback = self.gauntlet_system.process_gauntlet_feedback(new_gauntlet_results)
        
        self.logger.warning(f"Max refinement cycles ({max_cycles}) reached")
        return current_plan, max_cycles
    
    def _initialize_solution_tracking(
        self,
        plan: DecompositionPlan
    ) -> List[SolutionAttempt]:
        """
        Initialize solution tracking for all sub-problems.
        
        Args:
            plan: Decomposition plan
            
        Returns:
            List of initialized SolutionAttempt objects
        """
        solutions = []
        
        for sub_problem in plan.sub_problems:
            solution = SolutionAttempt(
                id=generate_id("solution"),
                sub_problem_id=sub_problem.id,
                approach="pending",
                implementation="",
                validation_results=[],
                success=False,
                confidence=0.0,
                timestamp=datetime.now()
            )
            solutions.append(solution)
            self.solution_orchestrator.track_solution_attempt(solution, sub_problem)
        
        return solutions
    
    def solve_sub_problem(
        self,
        plan: DecompositionPlan,
        sub_problem_id: str,
        approach: str,
        implementation: str
    ) -> SolutionAttempt:
        """
        Record and validate a solution attempt for a sub-problem.
        
        Args:
            plan: Decomposition plan
            sub_problem_id: ID of sub-problem being solved
            approach: Solution approach description
            implementation: Implementation details
            
        Returns:
            SolutionAttempt with validation results
        """
        self.logger.info(f"Recording solution for sub-problem: {sub_problem_id}")
        
        # Find sub-problem
        sub_problem = next((sp for sp in plan.sub_problems if sp.id == sub_problem_id), None)
        if not sub_problem:
            raise ValueError(f"Sub-problem not found: {sub_problem_id}")
        
        # Create solution attempt
        solution = SolutionAttempt(
            id=generate_id("solution"),
            sub_problem_id=sub_problem_id,
            approach=approach,
            implementation=implementation,
            validation_results=[],
            success=False,
            confidence=0.0,
            timestamp=datetime.now()
        )
        
        # Track and validate
        self.solution_orchestrator.track_solution_attempt(solution, sub_problem)
        validated_solution = self.solution_orchestrator.validate_solution(solution, sub_problem)
        
        self.logger.info(
            f"Solution validated: success={validated_solution.success}, "
            f"confidence={validated_solution.confidence:.2f}"
        )
        
        return validated_solution
    
    def integrate_all_solutions(
        self,
        plan: DecompositionPlan,
        solutions: List[SolutionAttempt]
    ) -> Dict[str, Any]:
        """
        Integrate all sub-problem solutions into final solution.
        
        Args:
            plan: Decomposition plan
            solutions: List of solution attempts
            
        Returns:
            Integration result with final solution and conflicts
        """
        self.logger.info("Integrating all solutions...")
        
        result = self.solution_orchestrator.integrate_solutions(plan, solutions)
        
        self.logger.info(
            f"Integration complete: success={result['success']}, "
            f"conflicts={len(result.get('conflicts', []))}"
        )
        
        return result
    
    def get_workflow_status(self, plan_id: str) -> Dict[str, Any]:
        """
        Get current status of a workflow.
        
        Args:
            plan_id: ID of decomposition plan
            
        Returns:
            Status dictionary with progress information
        """
        # This would query persistence layer in production
        return {
            'plan_id': plan_id,
            'status': 'in_progress',
            'timestamp': datetime.now().isoformat()
        }
    
    def apply_learned_patterns(
        self,
        problem: ProblemDefinition
    ) -> Optional[Dict[str, Any]]:
        """
        Apply previously learned patterns to a new problem.
        
        Args:
            problem: Problem to decompose
            
        Returns:
            Pattern guidance dictionary, or None if no patterns match
        """
        self.logger.info(f"Searching for applicable patterns for: {problem.title}")
        
        # Retrieve similar patterns
        patterns = self.knowledge_manager.retrieve_patterns(
            problem_type=problem.problem_type,
            domain=problem.domain_context.domain,
            min_success_rate=0.7
        )
        
        if not patterns:
            self.logger.info("No applicable patterns found")
            return None
        
        # Apply best pattern
        best_pattern = patterns[0]
        self.logger.info(f"Applying pattern: {best_pattern.id}")
        
        guidance = self.knowledge_manager.apply_pattern(best_pattern, problem.description)
        
        return guidance


# Convenience function for quick workflow execution
def decompose_problem(
    problem_text: str,
    title: str = "",
    strategy: str = 'hybrid',
    max_refinement_cycles: int = 3
) -> IntegrationResult:
    """
    Convenience function to decompose a problem using the complete workflow.
    
    Args:
        problem_text: Problem description
        title: Problem title
        strategy: Decomposition strategy ('semantic', 'dependency', 'complexity', 'hybrid')
        max_refinement_cycles: Maximum refinement iterations
        
    Returns:
        IntegrationResult with complete workflow results
    """
    orchestrator = SovereignIntegrationOrchestrator()
    return orchestrator.run_complete_workflow(
        problem_text,
        title,
        strategy,
        max_refinement_cycles
    )


    def execute_complete_solution_workflow(
        self,
        problem_text: str,
        title: str = "",
        strategy: str = 'hybrid',
        auto_solve: bool = False
    ) -> Dict[str, Any]:
        """
        Execute complete workflow including solution execution.
        
        This is the full end-to-end workflow that:
        1. Analyzes and decomposes the problem
        2. Validates and refines the decomposition
        3. Executes solutions for each sub-problem
        4. Integrates all solutions into final result
        5. Extracts knowledge for future use
        
        Args:
            problem_text: Problem description
            title: Problem title
            strategy: Decomposition strategy
            auto_solve: Whether to automatically solve sub-problems (placeholder)
            
        Returns:
            Dictionary with complete workflow results
        """
        self.logger.info("="*60)
        self.logger.info(f"EXECUTING COMPLETE SOLUTION WORKFLOW: {title}")
        self.logger.info("="*60)
        
        # Step 1: Run decomposition workflow
        decomposition_result = self.run_complete_workflow(
            problem_text,
            title,
            strategy,
            max_refinement_cycles=3,
            enable_knowledge_extraction=True
        )
        
        if not decomposition_result.success:
            self.logger.error("Decomposition workflow failed")
            return {
                'success': False,
                'error': 'Decomposition failed',
                'decomposition_result': decomposition_result
            }
        
        plan = decomposition_result.final_plan
        
        # Step 2: Execute solutions for each sub-problem
        self.logger.info(f"\nExecuting solutions for {len(plan.sub_problems)} sub-problems...")
        solution_results = []
        
        for i, sub_problem in enumerate(plan.sub_problems, 1):
            self.logger.info(f"\n[{i}/{len(plan.sub_problems)}] Solving: {sub_problem.title}")
            
            if auto_solve:
                # In a real implementation, this would call actual solvers
                # For now, create placeholder solutions
                solution = self.solve_sub_problem(
                    plan,
                    sub_problem.id,
                    approach=f"Automated approach for {sub_problem.type.value}",
                    implementation=f"Implementation for: {sub_problem.description[:100]}"
                )
            else:
                # Create pending solution
                solution = SolutionAttempt(
                    id=generate_id("solution"),
                    sub_problem_id=sub_problem.id,
                    approach="pending",
                    implementation="",
                    validation_results=[],
                    success=False,
                    confidence=0.0,
                    timestamp=datetime.now()
                )
            
            solution_results.append(solution)
        
        # Step 3: Integrate solutions
        self.logger.info("\nIntegrating all solutions...")
        integration_result = self.integrate_all_solutions(plan, solution_results)
        
        # Step 4: Final validation
        self.logger.info("\nPerforming final validation...")
        final_quality = self.quality_assessor.generate_quality_report(plan)
        
        # Step 5: Track strategy performance
        self.knowledge_manager.track_strategy_performance(
            plan.strategy,
            final_quality.metrics.overall_score
        )
        
        # Compile complete results
        complete_result = {
            'success': integration_result.get('success', False),
            'problem_id': decomposition_result.problem_id,
            'plan_id': decomposition_result.plan_id,
            'decomposition': {
                'strategy': strategy,
                'sub_problem_count': len(plan.sub_problems),
                'quality_score': decomposition_result.quality_score,
                'refinement_cycles': decomposition_result.refinement_cycles,
                'execution_time': decomposition_result.execution_time
            },
            'solutions': {
                'total': len(solution_results),
                'successful': sum(1 for s in solution_results if s.success),
                'pending': sum(1 for s in solution_results if s.approach == "pending"),
                'results': solution_results
            },
            'integration': integration_result,
            'final_quality': {
                'overall_score': final_quality.metrics.overall_score,
                'coherence': final_quality.metrics.coherence_score,
                'completeness': final_quality.metrics.completeness_score,
                'feasibility': final_quality.metrics.feasibility_score,
                'meets_thresholds': final_quality.meets_thresholds
            },
            'knowledge_extracted': decomposition_result.knowledge_extracted,
            'metadata': decomposition_result.metadata
        }
        
        self.logger.info("\n" + "="*60)
        self.logger.info(f"WORKFLOW COMPLETE: Success={complete_result['success']}")
        self.logger.info(f"Quality: {complete_result['final_quality']['overall_score']:.2f}")
        self.logger.info(f"Solutions: {complete_result['solutions']['successful']}/{complete_result['solutions']['total']} successful")
        self.logger.info("="*60)
        
        return complete_result
    
    def get_strategy_recommendation(
        self,
        problem: ProblemDefinition
    ) -> Dict[str, Any]:
        """
        Get strategy recommendation based on problem characteristics and history.
        
        Args:
            problem: Problem to analyze
            
        Returns:
            Dictionary with strategy recommendation and reasoning
        """
        # Check for learned patterns
        best_strategy = self.knowledge_manager.get_best_strategy(
            problem.problem_type,
            problem.domain_context.domain
        )
        
        if best_strategy:
            performance = self.knowledge_manager.get_strategy_performance(best_strategy)
            return {
                'recommended_strategy': best_strategy.value,
                'confidence': 'high',
                'reasoning': f"Based on {performance['usage_count']} historical uses with avg quality {performance['avg_score']:.2f}",
                'performance': performance
            }
        
        # Fallback to heuristic recommendation
        if problem.complexity_score.overall_complexity > 7.0:
            return {
                'recommended_strategy': 'hybrid',
                'confidence': 'medium',
                'reasoning': 'High complexity problem benefits from hybrid approach',
                'performance': None
            }
        elif problem.problem_type.value == 'research':
            return {
                'recommended_strategy': 'semantic',
                'confidence': 'medium',
                'reasoning': 'Research problems benefit from semantic decomposition',
                'performance': None
            }
        else:
            return {
                'recommended_strategy': 'dependency',
                'confidence': 'medium',
                'reasoning': 'Default recommendation for structured problems',
                'performance': None
            }


# Convenience functions for common workflows

def quick_decompose(problem_text: str, title: str = "") -> IntegrationResult:
    """
    Quick decomposition with default settings.
    
    Args:
        problem_text: Problem description
        title: Problem title
        
    Returns:
        IntegrationResult
    """
    orchestrator = SovereignIntegrationOrchestrator()
    return orchestrator.run_complete_workflow(problem_text, title)


def decompose_with_strategy(
    problem_text: str,
    strategy: str,
    title: str = ""
) -> IntegrationResult:
    """
    Decompose with specific strategy.
    
    Args:
        problem_text: Problem description
        strategy: Strategy to use ('semantic', 'dependency', 'complexity', 'hybrid')
        title: Problem title
        
    Returns:
        IntegrationResult
    """
    orchestrator = SovereignIntegrationOrchestrator()
    return orchestrator.run_complete_workflow(problem_text, title, strategy)


def full_solution_workflow(
    problem_text: str,
    title: str = "",
    strategy: str = 'hybrid'
) -> Dict[str, Any]:
    """
    Execute complete solution workflow.
    
    Args:
        problem_text: Problem description
        title: Problem title
        strategy: Decomposition strategy
        
    Returns:
        Complete workflow results
    """
    orchestrator = SovereignIntegrationOrchestrator()
    return orchestrator.execute_complete_solution_workflow(
        problem_text,
        title,
        strategy,
        auto_solve=False
    )

    def _run_team_review(self, plan: DecompositionPlan) -> List:
        """Run Red/Blue/Evaluator team review on decomposition plan."""
        from sovereign_data_models import Feedback
        
        all_feedback = []
        
        # Convert plan to content for team analysis
        plan_content = self._plan_to_content(plan)
        
        # Red Team Critique
        if self.red_team:
            try:
                self.logger.info("Running Red Team critique...")
                red_assessment = self.red_team.assess_content(plan_content, "protocol")
                for finding in red_assessment.findings:
                    all_feedback.append(Feedback(
                        id=generate_id("feedback"),
                        source="red_team",
                        feedback_type="critique",
                        content=f"{finding.title}: {finding.description}",
                        severity=self._map_severity(finding.severity),
                        actionable=True,
                        timestamp=datetime.now()
                    ))
                self.logger.info(f"Red Team found {len(red_assessment.findings)} issues")
            except Exception as e:
                self.logger.warning(f"Red Team analysis failed: {e}")
        
        # Blue Team Suggestions
        if self.blue_team and self.red_team:
            try:
                self.logger.info("Running Blue Team refinement...")
                red_assessment = self.red_team.assess_content(plan_content, "protocol")
                fix_suggestions = self.blue_team.suggest_fixes(
                    plan_content,
                    red_assessment.findings,
                    "protocol"
                )
                for suggestion in fix_suggestions:
                    all_feedback.append(Feedback(
                        id=generate_id("feedback"),
                        source="blue_team",
                        feedback_type="suggestion",
                        content=suggestion.fix_description,
                        severity="minor",
                        actionable=True,
                        timestamp=datetime.now()
                    ))
                self.logger.info(f"Blue Team provided {len(fix_suggestions)} suggestions")
            except Exception as e:
                self.logger.warning(f"Blue Team analysis failed: {e}")
        
        # Evaluator Team Assessment
        if self.evaluator_team:
            try:
                self.logger.info("Running Evaluator Team assessment...")
                evaluation = self.evaluator_team.evaluate_content(plan_content, "protocol")
                all_feedback.append(Feedback(
                    id=generate_id("feedback"),
                    source="evaluator_team",
                    feedback_type="approval" if evaluation.final_verdict == "APPROVED" else "critique",
                    content=f"Verdict: {evaluation.final_verdict}. Score: {evaluation.consensus_score:.1f}/100",
                    severity="info" if evaluation.final_verdict == "APPROVED" else "major",
                    actionable=evaluation.final_verdict != "APPROVED",
                    timestamp=datetime.now()
                ))
                self.logger.info(f"Evaluator Team verdict: {evaluation.final_verdict}")
            except Exception as e:
                self.logger.warning(f"Evaluator Team analysis failed: {e}")
        
        return all_feedback
    
    def _plan_to_content(self, plan: DecompositionPlan) -> str:
        """Convert decomposition plan to text content for team analysis."""
        content = f"DECOMPOSITION PLAN\n"
        content += f"Strategy: {plan.strategy.value}\n"
        content += f"Sub-problems: {len(plan.sub_problems)}\n\n"
        
        for i, sp in enumerate(plan.sub_problems, 1):
            content += f"{i}. {sp.title} ({sp.type.value})\n"
            content += f"   Description: {sp.description}\n"
            content += f"   Priority: {sp.priority}, Effort: {sp.estimated_effort}h\n"
            if sp.dependencies:
                content += f"   Dependencies: {len(sp.dependencies)}\n"
            content += "\n"
        
        return content
    
    def _map_severity(self, severity) -> str:
        """Map team severity levels to feedback severity."""
        severity_map = {
            "CRITICAL": "critical",
            "HIGH": "major",
            "MEDIUM": "minor",
            "LOW": "info"
        }
        severity_str = str(severity).upper() if hasattr(severity, 'value') else str(severity).upper()
        return severity_map.get(severity_str, "minor")
    
    def _apply_team_feedback(self, plan: DecompositionPlan, feedback: List) -> DecompositionPlan:
        """Apply team feedback to improve decomposition plan."""
        self.logger.info(f"Received {len(feedback)} feedback items from teams")
        for f in feedback:
            if f.severity in ['critical', 'major']:
                self.logger.warning(f"[{f.source}] {f.content}")
        return plan
