"""
Sovereign-Grade Problem Decomposition System - Knowledge Management
Extracts, stores, and applies learned decomposition patterns.
"""

import logging
from typing import List, Dict, Any, Optional
from datetime import datetime
from collections import defaultdict

from sovereign_data_models import (
    DecompositionPlan, Pattern, ProblemType, DecompositionStrategy, generate_id
)
from sovereign_persistence import SovereignDatabase

logger = logging.getLogger(__name__)


class KnowledgeManager:
    """Manages knowledge extraction and application for decomposition with LLM-powered learning."""
    
    def __init__(self, database: Optional[SovereignDatabase] = None, openevolve_client=None):
        """
        Initialize knowledge manager.
        
        Args:
            database: Optional database instance
            openevolve_client: Optional OpenEvolve client for LLM
        """
        self.database = database or SovereignDatabase()
        self.openevolve_client = openevolve_client
        self.logger = logging.getLogger(__name__)
        
        if not self.openevolve_client:
            try:
                from openevolve_client import OpenEvolveClient
                self.openevolve_client = OpenEvolveClient()
            except:
                self.logger.warning("OpenEvolve client not available for knowledge management")
        
        # Track strategy performance
        self.strategy_performance: Dict[str, List[float]] = defaultdict(list)
        
        # Pattern embeddings cache (for similarity)
        self.pattern_embeddings: Dict[str, List[float]] = {}
    
    def extract_patterns(
        self,
        plan: DecompositionPlan,
        success: bool,
        quality_score: float
    ) -> List[Pattern]:
        """
        Extracts patterns from successful/failed decompositions using LLM analysis.
        
        Args:
            plan: The decomposition plan
            success: Whether the decomposition was successful
            quality_score: Quality score achieved
            
        Returns:
            List of extracted Pattern objects
        """
        self.logger.info(f"Extracting patterns from plan {plan.id} (success={success})")
        
        patterns = []
        
        if not success or quality_score < 0.6:
            # Don't extract patterns from poor decompositions
            return patterns
        
        # Try LLM-based deep pattern extraction
        if self.openevolve_client:
            try:
                llm_patterns = self._extract_patterns_with_llm(plan, quality_score)
                if llm_patterns:
                    patterns.extend(llm_patterns)
                    self.logger.info(f"LLM extracted {len(llm_patterns)} patterns")
            except Exception as e:
                self.logger.warning(f"LLM pattern extraction failed: {e}")
        
        # Fallback to heuristic extraction if LLM didn't work
        if not patterns:
            # Extract strategy pattern
            strategy_pattern = self._extract_strategy_pattern(plan, quality_score)
            if strategy_pattern:
                patterns.append(strategy_pattern)
            
            # Extract structural patterns
            structural_patterns = self._extract_structural_patterns(plan, quality_score)
            patterns.extend(structural_patterns)
        
        # Store patterns
        for pattern in patterns:
            self.store_pattern(pattern)
        
        return patterns
    
    def _extract_patterns_with_llm(self, plan: DecompositionPlan, quality_score: float) -> List[Pattern]:
        """Use LLM to extract deep patterns from successful decomposition."""
        # Get problem from database
        problem = self.database.get_problem(plan.problem_id)
        if not problem:
            return []
        
        # Build decomposition summary
        sp_summary = "\n".join([
            f"{i+1}. {sp.title} ({sp.type.value}) - Priority: {sp.priority}, Effort: {sp.estimated_effort}h"
            for i, sp in enumerate(plan.sub_problems[:8])
        ])
        
        prompt = f"""You are an expert at extracting reusable patterns from successful problem decompositions. Analyze this decomposition and identify transferable patterns.

PROBLEM:
Type: {problem.problem_type.value}
Domain: {problem.domain_context.domain}
Complexity: {problem.complexity_score.overall_complexity}/10
Description: {problem.description[:200]}...

SUCCESSFUL DECOMPOSITION:
Strategy: {plan.strategy.value}
Quality Score: {quality_score:.2f}
Sub-problems:
{sp_summary}

PATTERN EXTRACTION:
Identify 2-4 reusable patterns that made this decomposition successful:

For each pattern provide:
1. Pattern Name: Clear, descriptive name
2. Pattern Type: (strategy/structural/workflow/domain-specific)
3. Key Characteristics: What makes this pattern effective
4. Applicability: When to use this pattern
5. Success Indicators: What suggests this pattern will work

Format EXACTLY as:
---
PATTERN 1
Name: <name>
Type: <type>
Characteristics: <char1> | <char2> | <char3>
Applicability: <when to use>
SuccessIndicators: <indicator1> | <indicator2>
---

Provide 2-4 patterns. Be specific and actionable."""
        
        result = self.openevolve_client.evolve(
            content=prompt,
            evolution_mode="standard",
            content_type="analysis",
            max_iterations=1,
            temperature=0.4,
            max_tokens=1200
        )
        
        if result.success and result.best_code:
            return self._parse_pattern_response(result.best_code, problem, plan, quality_score)
        
        return []
    
    def _parse_pattern_response(self, response: str, problem, plan: DecompositionPlan, quality_score: float) -> List[Pattern]:
        """Parse LLM pattern extraction response."""
        patterns = []
        sections = response.split('---')
        
        for section in sections:
            section = section.strip()
            if not section or 'PATTERN' not in section:
                continue
            
            try:
                # Parse fields
                name = self._extract_pattern_field(section, 'Name:')
                pattern_type = self._extract_pattern_field(section, 'Type:')
                characteristics = self._extract_pattern_field(section, 'Characteristics:')
                applicability = self._extract_pattern_field(section, 'Applicability:')
                success_indicators = self._extract_pattern_field(section, 'SuccessIndicators:')
                
                if not name:
                    continue
                
                # Create pattern
                pattern = Pattern(
                    id=generate_id("pattern"),
                    name=name,
                    problem_type=problem.problem_type,
                    strategy=plan.strategy,
                    pattern_data={
                        'type': pattern_type,
                        'characteristics': [c.strip() for c in characteristics.split('|') if c.strip()],
                        'applicability': applicability,
                        'success_indicators': [s.strip() for s in success_indicators.split('|') if s.strip()],
                        'sub_problem_count': len(plan.sub_problems),
                        'avg_complexity': sum(sp.complexity_score.overall_complexity for sp in plan.sub_problems) / len(plan.sub_problems),
                        'extraction_method': 'llm'
                    },
                    success_rate=1.0,  # Initial
                    usage_count=1,
                    avg_quality_score=quality_score,
                    applicable_domains=[problem.domain_context.domain],
                    discovered_at=datetime.now(),
                    last_used=datetime.now()
                )
                patterns.append(pattern)
                
            except Exception as e:
                self.logger.debug(f"Failed to parse pattern section: {e}")
                continue
        
        return patterns
    
    def _extract_pattern_field(self, text: str, field_name: str) -> str:
        """Extract field value from pattern text."""
        lines = text.split('\n')
        for line in lines:
            if line.strip().startswith(field_name):
                return line.split(':', 1)[1].strip()
        return ""
    
    def store_pattern(self, pattern: Pattern) -> bool:
        """
        Stores pattern in knowledge base.
        
        Args:
            pattern: The pattern to store
            
        Returns:
            True if successful
        """
        self.logger.info(f"Storing pattern {pattern.id}")
        
        # Check if similar pattern exists
        existing = self.database.get_patterns_by_type(pattern.problem_type.value)
        
        for existing_pattern in existing:
            if self._patterns_similar(pattern, existing_pattern):
                # Update existing pattern
                existing_pattern.usage_count += 1
                existing_pattern.avg_quality_score = (
                    (existing_pattern.avg_quality_score * (existing_pattern.usage_count - 1) +
                     pattern.avg_quality_score) / existing_pattern.usage_count
                )
                existing_pattern.last_used = datetime.now()
                self.database.update_pattern(existing_pattern)
                return True
        
        # Store new pattern
        return self.database.create_pattern(pattern)
    
    def retrieve_patterns(
        self,
        problem_type: ProblemType,
        domain: Optional[str] = None,
        min_success_rate: float = 0.7
    ) -> List[Pattern]:
        """
        Retrieves relevant patterns for problem.
        
        Args:
            problem_type: Type of problem
            domain: Optional domain filter
            min_success_rate: Minimum success rate threshold
            
        Returns:
            List of relevant Pattern objects
        """
        self.logger.info(f"Retrieving patterns for {problem_type.value}")
        
        # Get patterns by type
        patterns = self.database.get_patterns_by_type(problem_type.value)
        
        # Filter by success rate
        patterns = [p for p in patterns if p.success_rate >= min_success_rate]
        
        # Filter by domain if specified
        if domain:
            patterns = [p for p in patterns 
                       if domain in p.applicable_domains or not p.applicable_domains]
        
        # Sort by effectiveness
        patterns.sort(key=lambda p: (p.success_rate, p.avg_quality_score), reverse=True)
        
        return patterns
    
    def apply_pattern(
        self,
        pattern: Pattern,
        problem_description: str
    ) -> Dict[str, Any]:
        """
        Applies learned pattern to new problem.
        
        Args:
            pattern: The pattern to apply
            problem_description: Description of the new problem
            
        Returns:
            Dictionary with application guidance
        """
        self.logger.info(f"Applying pattern {pattern.id}")
        
        # Update pattern usage
        pattern.usage_count += 1
        pattern.last_used = datetime.now()
        self.database.update_pattern(pattern)
        
        # Generate application guidance
        guidance = {
            'pattern_id': pattern.id,
            'strategy': pattern.strategy.value,
            'description': pattern.pattern_description,
            'success_rate': pattern.success_rate,
            'avg_quality': pattern.avg_quality_score,
            'recommendations': self._generate_recommendations(pattern),
            'applicable': True
        }
        
        return guidance
    
    def track_strategy_performance(
        self,
        strategy: DecompositionStrategy,
        quality_score: float
    ) -> None:
        """
        Tracks strategy effectiveness over time.
        
        Args:
            strategy: The decomposition strategy used
            quality_score: Quality score achieved
        """
        self.logger.info(f"Tracking performance for {strategy.value}: {quality_score:.2f}")
        
        self.strategy_performance[strategy.value].append(quality_score)
    
    def get_strategy_performance(
        self,
        strategy: DecompositionStrategy
    ) -> Dict[str, float]:
        """
        Gets performance metrics for a strategy.
        
        Args:
            strategy: The decomposition strategy
            
        Returns:
            Dictionary with performance metrics
        """
        scores = self.strategy_performance.get(strategy.value, [])
        
        if not scores:
            return {
                'avg_score': 0.0,
                'min_score': 0.0,
                'max_score': 0.0,
                'usage_count': 0
            }
        
        return {
            'avg_score': sum(scores) / len(scores),
            'min_score': min(scores),
            'max_score': max(scores),
            'usage_count': len(scores)
        }
    
    def adapt_strategies(self) -> Dict[str, Any]:
        """
        Adapts strategies based on performance data.
        
        Returns:
            Dictionary with adaptation recommendations
        """
        self.logger.info("Adapting strategies based on performance")
        
        recommendations = {}
        
        for strategy_name, scores in self.strategy_performance.items():
            if len(scores) < 3:
                continue  # Need more data
            
            avg_score = sum(scores) / len(scores)
            recent_avg = sum(scores[-5:]) / min(5, len(scores))
            
            # Check if strategy is improving or declining
            if recent_avg > avg_score + 0.1:
                recommendations[strategy_name] = {
                    'trend': 'improving',
                    'action': 'increase_usage',
                    'confidence': 'high'
                }
            elif recent_avg < avg_score - 0.1:
                recommendations[strategy_name] = {
                    'trend': 'declining',
                    'action': 'review_and_adjust',
                    'confidence': 'medium'
                }
            else:
                recommendations[strategy_name] = {
                    'trend': 'stable',
                    'action': 'maintain',
                    'confidence': 'high'
                }
        
        return recommendations
    
    def get_best_strategy(
        self,
        problem_type: ProblemType,
        domain: Optional[str] = None
    ) -> Optional[DecompositionStrategy]:
        """
        Recommends best strategy based on historical performance.
        
        Args:
            problem_type: Type of problem
            domain: Optional domain
            
        Returns:
            Recommended DecompositionStrategy or None
        """
        self.logger.info(f"Finding best strategy for {problem_type.value}")
        
        # Get patterns for this problem type
        patterns = self.retrieve_patterns(problem_type, domain)
        
        if not patterns:
            return None
        
        # Count strategy usage and effectiveness
        strategy_scores = defaultdict(list)
        for pattern in patterns:
            strategy_scores[pattern.strategy].append(
                pattern.success_rate * pattern.avg_quality_score
            )
        
        # Find best strategy
        best_strategy = None
        best_score = 0.0
        
        for strategy, scores in strategy_scores.items():
            avg_score = sum(scores) / len(scores)
            if avg_score > best_score:
                best_score = avg_score
                best_strategy = strategy
        
        return best_strategy
    
    # Helper methods
    
    def _extract_strategy_pattern(
        self,
        plan: DecompositionPlan,
        quality_score: float
    ) -> Optional[Pattern]:
        """Extract pattern from strategy usage."""
        
        # Get problem type from plan metadata or infer
        problem_type = ProblemType.ANALYSIS  # Default
        
        pattern = Pattern(
            id=generate_id("pattern"),
            problem_type=problem_type,
            strategy=plan.strategy,
            pattern_description=f"Use {plan.strategy.value} strategy for {problem_type.value} problems",
            success_rate=1.0 if quality_score >= 0.8 else 0.5,
            usage_count=1,
            avg_quality_score=quality_score,
            applicable_domains=[],
            created_at=datetime.now(),
            last_used=datetime.now(),
            metadata={
                'sub_problem_count': len(plan.sub_problems),
                'confidence': plan.confidence_level
            }
        )
        
        return pattern
    
    def _extract_structural_patterns(
        self,
        plan: DecompositionPlan,
        quality_score: float
    ) -> List[Pattern]:
        """Extract structural patterns from decomposition."""
        patterns = []
        
        # Pattern: Optimal sub-problem count
        if 3 <= len(plan.sub_problems) <= 7 and quality_score >= 0.8:
            pattern = Pattern(
                id=generate_id("pattern"),
                problem_type=ProblemType.ANALYSIS,
                strategy=plan.strategy,
                pattern_description=f"Decompose into {len(plan.sub_problems)} sub-problems",
                success_rate=1.0,
                usage_count=1,
                avg_quality_score=quality_score,
                applicable_domains=[],
                created_at=datetime.now(),
                last_used=datetime.now(),
                metadata={'pattern_type': 'structural'}
            )
            patterns.append(pattern)
        
        return patterns
    
    def _patterns_similar(self, p1: Pattern, p2: Pattern) -> bool:
        """Check if two patterns are similar using semantic analysis."""
        # Basic checks first
        if p1.problem_type != p2.problem_type:
            return False
        
        if p1.strategy != p2.strategy:
            return False
        
        # Try semantic similarity if LLM available
        if self.openevolve_client:
            try:
                similarity = self._calculate_pattern_similarity(p1, p2)
                return similarity > 0.75
            except Exception as e:
                self.logger.debug(f"Semantic similarity failed: {e}")
        
        # Fallback to heuristic
        return abs(p1.avg_quality_score - p2.avg_quality_score) < 0.2
    
    def _calculate_pattern_similarity(self, p1: Pattern, p2: Pattern) -> float:
        """Calculate semantic similarity between patterns."""
        # Get embeddings
        emb1 = self._get_pattern_embedding(p1)
        emb2 = self._get_pattern_embedding(p2)
        
        if not emb1 or not emb2:
            return 0.0
        
        # Cosine similarity
        import math
        dot = sum(a * b for a, b in zip(emb1, emb2))
        mag1 = math.sqrt(sum(a * a for a in emb1))
        mag2 = math.sqrt(sum(b * b for b in emb2))
        
        if mag1 == 0 or mag2 == 0:
            return 0.0
        
        return dot / (mag1 * mag2)
    
    def _get_pattern_embedding(self, pattern: Pattern) -> Optional[List[float]]:
        """Get or generate embedding for pattern."""
        if pattern.id in self.pattern_embeddings:
            return self.pattern_embeddings[pattern.id]
        
        # Generate simple embedding (in production would use actual embedding model)
        pattern_text = f"{pattern.name} {pattern.pattern_data.get('applicability', '')}"
        embedding = [float(hash(pattern_text[i:i+10]) % 100) / 100.0 
                    for i in range(0, min(len(pattern_text), 100), 10)]
        
        while len(embedding) < 128:
            embedding.append(0.0)
        embedding = embedding[:128]
        
        self.pattern_embeddings[pattern.id] = embedding
        return embedding
    
    def _generate_recommendations(self, pattern: Pattern) -> List[str]:
        """Generate recommendations based on pattern."""
        recommendations = []
        
        recommendations.append(f"Use {pattern.strategy.value} decomposition strategy")
        
        if pattern.success_rate >= 0.9:
            recommendations.append("This pattern has high success rate")
        
        if pattern.usage_count > 10:
            recommendations.append("This pattern is well-tested")
        
        if 'sub_problem_count' in pattern.metadata:
            count = pattern.metadata['sub_problem_count']
            recommendations.append(f"Consider decomposing into ~{count} sub-problems")
        
        return recommendations
