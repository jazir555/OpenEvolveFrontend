"""
Sovereign-Grade Problem Decomposition System - Performance Optimization

Implements caching, parallel processing, and performance monitoring.
"""

import logging
import asyncio
import time
from typing import List, Dict, Any, Optional, Callable
from functools import wraps
from datetime import datetime, timedelta
from collections import OrderedDict
import hashlib
import json

from sovereign_data_models import (
    ProblemDefinition, DecompositionPlan, Pattern, 
    SubProblem, ValidationResult, generate_id
)


logger = logging.getLogger(__name__)


class LRUCache:
    """Least Recently Used cache with TTL support."""
    
    def __init__(self, max_size: int = 1000, ttl_seconds: int = 3600):
        self.cache = OrderedDict()
        self.max_size = max_size
        self.ttl_seconds = ttl_seconds
        self.hits = 0
        self.misses = 0
    
    def _make_key(self, *args, **kwargs) -> str:
        """Create cache key from arguments."""
        key_data = {
            'args': str(args),
            'kwargs': str(sorted(kwargs.items()))
        }
        key_str = json.dumps(key_data, sort_keys=True)
        return hashlib.md5(key_str.encode()).hexdigest()
    
    def get(self, key: str) -> Optional[Any]:
        """Get value from cache."""
        if key in self.cache:
            value, timestamp = self.cache[key]
            # Check TTL
            if datetime.now() - timestamp < timedelta(seconds=self.ttl_seconds):
                # Move to end (most recently used)
                self.cache.move_to_end(key)
                self.hits += 1
                return value
            else:
                # Expired
                del self.cache[key]
        
        self.misses += 1
        return None
    
    def put(self, key: str, value: Any):
        """Put value in cache."""
        if key in self.cache:
            # Update existing
            self.cache.move_to_end(key)
        elif len(self.cache) >= self.max_size:
            # Remove oldest
            self.cache.popitem(last=False)
        
        self.cache[key] = (value, datetime.now())
    
    def clear(self):
        """Clear all cache entries."""
        self.cache.clear()
        self.hits = 0
        self.misses = 0
    
    def get_stats(self) -> Dict[str, Any]:
        """Get cache statistics."""
        total = self.hits + self.misses
        hit_rate = self.hits / total if total > 0 else 0
        return {
            'size': len(self.cache),
            'max_size': self.max_size,
            'hits': self.hits,
            'misses': self.misses,
            'hit_rate': hit_rate,
            'ttl_seconds': self.ttl_seconds
        }


class DecompositionCache:
    """Caching layer for decomposition system."""
    
    def __init__(self):
        self.problem_analysis_cache = LRUCache(max_size=500, ttl_seconds=3600)
        self.strategy_selection_cache = LRUCache(max_size=500, ttl_seconds=1800)
        self.pattern_match_cache = LRUCache(max_size=1000, ttl_seconds=7200)
        self.decomposition_cache = LRUCache(max_size=200, ttl_seconds=1800)
        self.logger = logging.getLogger(__name__)
    
    def cache_problem_analysis(self, problem_text: str, analysis: Dict[str, Any]):
        """Cache problem analysis result."""
        key = hashlib.md5(problem_text.encode()).hexdigest()
        self.problem_analysis_cache.put(key, analysis)
        self.logger.debug(f"Cached problem analysis: {key}")
    
    def get_problem_analysis(self, problem_text: str) -> Optional[Dict[str, Any]]:
        """Get cached problem analysis."""
        key = hashlib.md5(problem_text.encode()).hexdigest()
        result = self.problem_analysis_cache.get(key)
        if result:
            self.logger.debug(f"Cache hit for problem analysis: {key}")
        return result
    
    def cache_strategy_selection(self, problem_id: str, strategy: str):
        """Cache strategy selection."""
        self.strategy_selection_cache.put(problem_id, strategy)
        self.logger.debug(f"Cached strategy selection: {problem_id} -> {strategy}")
    
    def get_strategy_selection(self, problem_id: str) -> Optional[str]:
        """Get cached strategy selection."""
        result = self.strategy_selection_cache.get(problem_id)
        if result:
            self.logger.debug(f"Cache hit for strategy: {problem_id}")
        return result
    
    def cache_pattern_matches(self, problem_id: str, patterns: List[Pattern]):
        """Cache pattern matching results."""
        self.pattern_match_cache.put(problem_id, patterns)
        self.logger.debug(f"Cached {len(patterns)} pattern matches for: {problem_id}")
    
    def get_pattern_matches(self, problem_id: str) -> Optional[List[Pattern]]:
        """Get cached pattern matches."""
        result = self.pattern_match_cache.get(problem_id)
        if result:
            self.logger.debug(f"Cache hit for patterns: {problem_id}")
        return result
    
    def cache_decomposition(self, problem_id: str, plan: DecompositionPlan):
        """Cache decomposition plan."""
        self.decomposition_cache.put(problem_id, plan)
        self.logger.debug(f"Cached decomposition plan: {problem_id}")
    
    def get_decomposition(self, problem_id: str) -> Optional[DecompositionPlan]:
        """Get cached decomposition plan."""
        result = self.decomposition_cache.get(problem_id)
        if result:
            self.logger.debug(f"Cache hit for decomposition: {problem_id}")
        return result
    
    def invalidate_problem(self, problem_id: str):
        """Invalidate all caches for a problem."""
        self.strategy_selection_cache.cache.pop(problem_id, None)
        self.pattern_match_cache.cache.pop(problem_id, None)
        self.decomposition_cache.cache.pop(problem_id, None)
        self.logger.info(f"Invalidated caches for problem: {problem_id}")
    
    def clear_all(self):
        """Clear all caches."""
        self.problem_analysis_cache.clear()
        self.strategy_selection_cache.clear()
        self.pattern_match_cache.clear()
        self.decomposition_cache.clear()
        self.logger.info("Cleared all caches")
    
    def get_stats(self) -> Dict[str, Any]:
        """Get cache statistics."""
        return {
            'problem_analysis': self.problem_analysis_cache.get_stats(),
            'strategy_selection': self.strategy_selection_cache.get_stats(),
            'pattern_matching': self.pattern_match_cache.get_stats(),
            'decomposition': self.decomposition_cache.get_stats()
        }


class ParallelProcessor:
    """Parallel processing for decomposition tasks."""
    
    def __init__(self, max_workers: int = 4):
        self.max_workers = max_workers
        self.logger = logging.getLogger(__name__)
    
    async def process_sub_problems_parallel(
        self,
        sub_problems: List[SubProblem],
        processor: Callable
    ) -> List[Any]:
        """Process sub-problems in parallel."""
        self.logger.info(f"Processing {len(sub_problems)} sub-problems in parallel")
        
        tasks = [processor(sp) for sp in sub_problems]
        results = await asyncio.gather(*tasks, return_exceptions=True)
        
        # Filter out exceptions
        successful = [r for r in results if not isinstance(r, Exception)]
        failed = [r for r in results if isinstance(r, Exception)]
        
        if failed:
            self.logger.warning(f"{len(failed)} sub-problems failed processing")
        
        return successful
    
    async def run_gauntlets_parallel(
        self,
        gauntlets: List[Any],
        plan: DecompositionPlan
    ) -> List[ValidationResult]:
        """Run gauntlets in parallel."""
        self.logger.info(f"Running {len(gauntlets)} gauntlets in parallel")
        
        async def run_gauntlet(gauntlet):
            return gauntlet.run(plan)
        
        tasks = [run_gauntlet(g) for g in gauntlets]
        results = await asyncio.gather(*tasks, return_exceptions=True)
        
        # Filter successful results
        successful = [r for r in results if not isinstance(r, Exception)]
        return successful
    
    async def assign_teams_parallel(
        self,
        assignments: List[Dict[str, Any]],
        assigner: Callable
    ) -> List[Any]:
        """Assign tasks to teams in parallel."""
        self.logger.info(f"Processing {len(assignments)} team assignments in parallel")
        
        tasks = [assigner(a) for a in assignments]
        results = await asyncio.gather(*tasks, return_exceptions=True)
        
        successful = [r for r in results if not isinstance(r, Exception)]
        return successful


class PerformanceMonitor:
    """Monitor and track performance metrics."""
    
    def __init__(self):
        self.metrics = {
            'decomposition_times': [],
            'analysis_times': [],
            'validation_times': [],
            'integration_times': []
        }
        self.logger = logging.getLogger(__name__)
    
    def record_decomposition_time(self, duration: float):
        """Record decomposition execution time."""
        self.metrics['decomposition_times'].append(duration)
        self.logger.debug(f"Decomposition took {duration:.2f}s")
    
    def record_analysis_time(self, duration: float):
        """Record analysis execution time."""
        self.metrics['analysis_times'].append(duration)
        self.logger.debug(f"Analysis took {duration:.2f}s")
    
    def record_validation_time(self, duration: float):
        """Record validation execution time."""
        self.metrics['validation_times'].append(duration)
        self.logger.debug(f"Validation took {duration:.2f}s")
    
    def record_integration_time(self, duration: float):
        """Record integration execution time."""
        self.metrics['integration_times'].append(duration)
        self.logger.debug(f"Integration took {duration:.2f}s")
    
    def get_statistics(self) -> Dict[str, Any]:
        """Get performance statistics."""
        stats = {}
        
        for metric_name, times in self.metrics.items():
            if times:
                stats[metric_name] = {
                    'count': len(times),
                    'avg': sum(times) / len(times),
                    'min': min(times),
                    'max': max(times),
                    'total': sum(times)
                }
            else:
                stats[metric_name] = {
                    'count': 0,
                    'avg': 0,
                    'min': 0,
                    'max': 0,
                    'total': 0
                }
        
        return stats
    
    def check_performance_thresholds(self) -> Dict[str, bool]:
        """Check if performance meets requirements."""
        stats = self.get_statistics()
        
        # Requirements: < 30 seconds for 100 sub-problems
        decomp_avg = stats['decomposition_times']['avg']
        
        return {
            'decomposition_under_30s': decomp_avg < 30.0,
            'analysis_under_5s': stats['analysis_times']['avg'] < 5.0,
            'validation_under_10s': stats['validation_times']['avg'] < 10.0,
            'integration_under_5s': stats['integration_times']['avg'] < 5.0
        }
    
    def reset(self):
        """Reset all metrics."""
        for key in self.metrics:
            self.metrics[key] = []
        self.logger.info("Performance metrics reset")


def timed(metric_name: str):
    """Decorator to time function execution."""
    def decorator(func):
        @wraps(func)
        def wrapper(*args, **kwargs):
            start = time.time()
            result = func(*args, **kwargs)
            duration = time.time() - start
            
            # Try to find monitor in args/kwargs
            monitor = None
            for arg in args:
                if isinstance(arg, PerformanceMonitor):
                    monitor = arg
                    break
            
            if monitor:
                if metric_name == 'decomposition':
                    monitor.record_decomposition_time(duration)
                elif metric_name == 'analysis':
                    monitor.record_analysis_time(duration)
                elif metric_name == 'validation':
                    monitor.record_validation_time(duration)
                elif metric_name == 'integration':
                    monitor.record_integration_time(duration)
            
            return result
        return wrapper
    return decorator


class DatabaseOptimizer:
    """Optimize database operations."""
    
    def __init__(self, db_path: str):
        self.db_path = db_path
        self.logger = logging.getLogger(__name__)
    
    def create_indexes(self):
        """Create performance indexes."""
        import sqlite3
        
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        try:
            # Index on problem_id for fast lookups
            cursor.execute("""
                CREATE INDEX IF NOT EXISTS idx_plans_problem_id 
                ON decomposition_plans(problem_id)
            """)
            
            # Index on strategy for performance tracking
            cursor.execute("""
                CREATE INDEX IF NOT EXISTS idx_plans_strategy 
                ON decomposition_plans(strategy)
            """)
            
            # Index on pattern problem_type
            cursor.execute("""
                CREATE INDEX IF NOT EXISTS idx_patterns_type 
                ON patterns(problem_type)
            """)
            
            # Index on pattern success_rate
            cursor.execute("""
                CREATE INDEX IF NOT EXISTS idx_patterns_success 
                ON patterns(success_rate DESC)
            """)
            
            conn.commit()
            self.logger.info("Database indexes created successfully")
        except Exception as e:
            self.logger.error(f"Error creating indexes: {e}")
        finally:
            conn.close()
    
    def optimize_queries(self):
        """Run database optimization."""
        import sqlite3
        
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        try:
            # Analyze tables for query optimization
            cursor.execute("ANALYZE")
            
            # Vacuum to reclaim space and optimize
            cursor.execute("VACUUM")
            
            conn.commit()
            self.logger.info("Database optimized successfully")
        except Exception as e:
            self.logger.error(f"Error optimizing database: {e}")
        finally:
            conn.close()


# Global instances
_cache = None
_monitor = None


def get_cache() -> DecompositionCache:
    """Get global cache instance."""
    global _cache
    if _cache is None:
        _cache = DecompositionCache()
    return _cache


def get_monitor() -> PerformanceMonitor:
    """Get global performance monitor."""
    global _monitor
    if _monitor is None:
        _monitor = PerformanceMonitor()
    return _monitor
