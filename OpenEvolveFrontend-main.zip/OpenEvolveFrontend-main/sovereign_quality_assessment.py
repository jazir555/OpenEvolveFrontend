"""
Sovereign-Grade Problem Decomposition System - Quality Assessment
Implements decomposition-specific quality metrics and reporting.
"""

import logging
from typing import Dict, List, Any, Optional
from datetime import datetime
from dataclasses import dataclass

from sovereign_data_models import (
    DecompositionPlan, SubProblem, QualityScores, generate_id
)

logger = logging.getLogger(__name__)


@dataclass
class QualityMetrics:
    """Detailed quality metrics for decomposition."""
    coherence_score: float
    completeness_score: float
    feasibility_score: float
    integration_score: float
    balance_score: float
    clarity_score: float
    overall_score: float
    details: Dict[str, Any]


@dataclass
class QualityReport:
    """Comprehensive quality report."""
    plan_id: str
    metrics: QualityMetrics
    strengths: List[str]
    weaknesses: List[str]
    recommendations: List[str]
    meets_thresholds: bool
    generated_at: datetime


class QualityAssessor:
    """Assesses decomposition and solution quality with LLM-powered evaluation."""
    
    def __init__(self, openevolve_client=None):
        self.logger = logging.getLogger(__name__)
        self.openevolve_client = openevolve_client
        
        if not self.openevolve_client:
            try:
                from openevolve_client import OpenEvolveClient
                self.openevolve_client = OpenEvolveClient()
            except:
                self.logger.warning("OpenEvolve client not available for quality assessment")
        
        # Quality thresholds
        self.thresholds = {
            'coherence': 0.75,
            'completeness': 0.80,
            'feasibility': 0.70,
            'integration': 0.75,
            'balance': 0.70,
            'clarity': 0.75,
            'overall': 0.75
        }
    
    def assess_with_llm(self, plan: DecompositionPlan) -> Optional[QualityMetrics]:
        """
        Comprehensive LLM-based quality assessment.
        
        Uses LLM to evaluate all quality dimensions with detailed reasoning.
        """
        if not self.openevolve_client:
            return None
        
        try:
            # Build plan summary
            sp_summary = "\n".join([
                f"{i+1}. {sp.title} ({sp.type.value})\n   {sp.description[:100]}..."
                for i, sp in enumerate(plan.sub_problems[:8])
            ])
            
            prompt = f"""You are an expert quality assessor for problem decomposition plans. Evaluate this decomposition across multiple quality dimensions.

DECOMPOSITION PLAN:
Strategy: {plan.strategy.value}
Sub-problems: {len(plan.sub_problems)}

{sp_summary}

QUALITY ASSESSMENT:
Rate each dimension 0-100:

1. COHERENCE: Logical consistency, alignment, no contradictions
2. COMPLETENESS: Full coverage, no gaps, all aspects addressed
3. FEASIBILITY: Realistic, achievable, properly scoped
4. INTEGRATION: Sub-problems integrate well, clear interfaces
5. BALANCE: Even distribution of complexity and effort
6. CLARITY: Clear, understandable, well-defined

Provide assessment in EXACT format:
Coherence: <score>
Completeness: <score>
Feasibility: <score>
Integration: <score>
Balance: <score>
Clarity: <score>
Strengths: <strength1> | <strength2> | <strength3>
Weaknesses: <weakness1> | <weakness2>
Recommendations: <rec1> | <rec2> | <rec3>

Be thorough and specific."""
            
            result = self.openevolve_client.evolve(
                content=prompt,
                evolution_mode="standard",
                content_type="analysis",
                max_iterations=1,
                temperature=0.3,
                max_tokens=800
            )
            
            if result.success and result.best_code:
                return self._parse_quality_response(result.best_code)
        
        except Exception as e:
            self.logger.warning(f"LLM quality assessment failed: {e}")
        
        return None
    
    def _parse_quality_response(self, response: str) -> QualityMetrics:
        """Parse LLM quality assessment response."""
        lines = response.strip().split('\n')
        
        scores = {
            'coherence': 75.0,
            'completeness': 75.0,
            'feasibility': 75.0,
            'integration': 75.0,
            'balance': 75.0,
            'clarity': 75.0
        }
        
        strengths = []
        weaknesses = []
        recommendations = []
        
        for line in lines:
            line = line.strip()
            if ':' not in line:
                continue
            
            key, value = line.split(':', 1)
            key = key.strip().lower()
            value = value.strip()
            
            if key in scores:
                try:
                    scores[key] = float(value)
                except:
                    pass
            elif key == 'strengths':
                strengths = [s.strip() for s in value.split('|') if s.strip()]
            elif key == 'weaknesses':
                weaknesses = [w.strip() for w in value.split('|') if w.strip()]
            elif key == 'recommendations':
                recommendations = [r.strip() for r in value.split('|') if r.strip()]
        
        overall = sum(scores.values()) / len(scores)
        
        return QualityMetrics(
            coherence_score=scores['coherence'] / 100.0,
            completeness_score=scores['completeness'] / 100.0,
            feasibility_score=scores['feasibility'] / 100.0,
            integration_score=scores['integration'] / 100.0,
            balance_score=scores['balance'] / 100.0,
            clarity_score=scores['clarity'] / 100.0,
            overall_score=overall / 100.0,
            details={
                'strengths': strengths,
                'weaknesses': weaknesses,
                'recommendations': recommendations,
                'method': 'llm'
            }
        )
    
    def calculate_coherence_score(self, plan: DecompositionPlan) -> float:
        """
        Measures logical consistency.
        
        Evaluates:
        - Sub-problem alignment with parent
        - Consistency of success criteria
        - Logical flow between sub-problems
        - Absence of contradictions
        """
        self.logger.info(f"Calculating coherence score for plan {plan.id}")
        
        if not plan.sub_problems:
            return 0.0
        
        score = 1.0
        
        # Check 1: All sub-problems have descriptions
        with_descriptions = sum(1 for sp in plan.sub_problems 
                               if sp.description and len(sp.description.strip()) >= 20)
        description_ratio = with_descriptions / len(plan.sub_problems)
        score *= description_ratio
        
        # Check 2: Success criteria consistency
        with_criteria = sum(1 for sp in plan.sub_problems if sp.success_criteria)
        criteria_ratio = with_criteria / len(plan.sub_problems)
        score *= (0.7 + 0.3 * criteria_ratio)  # Minimum 0.7, up to 1.0
        
        # Check 3: Type consistency (diverse but coherent)
        types = [sp.type for sp in plan.sub_problems]
        unique_types = len(set(types))
        if 2 <= unique_types <= 4:
            score *= 1.0  # Good diversity
        elif unique_types == 1:
            score *= 0.8  # Too uniform
        else:
            score *= 0.9  # Too diverse
        
        # Check 4: Complexity distribution
        complexities = [sp.complexity_score.overall_complexity for sp in plan.sub_problems]
        avg_complexity = sum(complexities) / len(complexities)
        variance = sum((c - avg_complexity) ** 2 for c in complexities) / len(complexities)
        
        # Lower variance is better (more balanced)
        if variance < 4.0:
            score *= 1.0
        elif variance < 9.0:
            score *= 0.9
        else:
            score *= 0.8
        
        return min(1.0, score)
    
    def calculate_completeness_score(self, plan: DecompositionPlan) -> float:
        """
        Measures problem coverage.
        
        Evaluates:
        - All problem aspects addressed
        - No critical gaps
        - Sufficient sub-problem count
        - Coverage of different problem types
        """
        self.logger.info(f"Calculating completeness score for plan {plan.id}")
        
        if not plan.sub_problems:
            return 0.0
        
        score = 1.0
        
        # Check 1: Minimum sub-problem count
        if len(plan.sub_problems) < 2:
            score *= 0.5
        elif len(plan.sub_problems) < 3:
            score *= 0.7
        elif len(plan.sub_problems) > 10:
            score *= 0.9  # Too many might indicate over-decomposition
        
        # Check 2: Type diversity
        types = set(sp.type for sp in plan.sub_problems)
        type_diversity = len(types) / 5.0  # 5 possible types
        score *= (0.6 + 0.4 * type_diversity)
        
        # Check 3: Success criteria coverage
        with_criteria = sum(1 for sp in plan.sub_problems if sp.success_criteria)
        criteria_coverage = with_criteria / len(plan.sub_problems)
        score *= (0.5 + 0.5 * criteria_coverage)
        
        # Check 4: Dependency coverage (some sub-problems should have dependencies)
        with_deps = sum(1 for sp in plan.sub_problems if sp.dependencies)
        if len(plan.sub_problems) > 1:
            dep_ratio = with_deps / len(plan.sub_problems)
            # We expect 30-70% to have dependencies
            if 0.3 <= dep_ratio <= 0.7:
                score *= 1.0
            elif dep_ratio < 0.3:
                score *= (0.7 + dep_ratio)
            else:
                score *= 0.9
        
        return min(1.0, score)
    
    def calculate_feasibility_score(self, plan: DecompositionPlan) -> float:
        """
        Measures solvability likelihood.
        
        Evaluates:
        - Complexity is manageable
        - Effort estimates are reasonable
        - Resources are sufficient
        - No impossible constraints
        """
        self.logger.info(f"Calculating feasibility score for plan {plan.id}")
        
        if not plan.sub_problems:
            return 0.0
        
        score = 1.0
        
        # Check 1: Complexity feasibility
        max_complexity = 8.0
        over_limit = sum(1 for sp in plan.sub_problems 
                        if sp.complexity_score.overall_complexity > max_complexity)
        if over_limit > 0:
            penalty = over_limit / len(plan.sub_problems)
            score *= (1.0 - penalty * 0.5)
        
        # Check 2: Effort feasibility
        total_effort = sum(sp.estimated_effort for sp in plan.sub_problems)
        max_effort = 80  # person-hours
        if total_effort > max_effort:
            score *= max_effort / total_effort
        
        # Check 3: Priority distribution
        priorities = [sp.priority for sp in plan.sub_problems]
        if priorities:
            # Should have some variation in priorities
            unique_priorities = len(set(priorities))
            if unique_priorities >= 2:
                score *= 1.0
            else:
                score *= 0.9
        
        # Check 4: Validation gauntlets assigned
        with_gauntlets = sum(1 for sp in plan.sub_problems if sp.validation_gauntlet)
        gauntlet_ratio = with_gauntlets / len(plan.sub_problems)
        score *= (0.8 + 0.2 * gauntlet_ratio)
        
        return min(1.0, score)
    
    def calculate_integration_score(self, plan: DecompositionPlan) -> float:
        """
        Measures how well sub-solutions will integrate.
        
        Evaluates:
        - Dependency structure
        - Interface compatibility
        - Integration complexity
        - Conflict potential
        """
        self.logger.info(f"Calculating integration score for plan {plan.id}")
        
        if not plan.sub_problems or len(plan.sub_problems) < 2:
            return 1.0  # Single sub-problem integrates trivially
        
        score = 1.0
        
        # Check 1: Dependency graph exists
        if plan.dependency_graph:
            score *= 1.0
            
            # Check execution order
            if plan.dependency_graph.execution_order:
                order_coverage = len(plan.dependency_graph.execution_order) / len(plan.sub_problems)
                score *= (0.8 + 0.2 * order_coverage)
        else:
            score *= 0.7  # No dependency graph is a problem
        
        # Check 2: No circular dependencies (checked via dependency graph)
        # This would be caught by DependencyGauntlet, so we assume it's OK here
        
        # Check 3: Integration complexity
        avg_complexity = sum(sp.complexity_score.integration_complexity 
                           for sp in plan.sub_problems) / len(plan.sub_problems)
        if avg_complexity < 5.0:
            score *= 1.0
        elif avg_complexity < 7.0:
            score *= 0.9
        else:
            score *= 0.8
        
        # Check 4: Type compatibility
        # Different types should integrate well
        types = [sp.type for sp in plan.sub_problems]
        unique_types = len(set(types))
        if unique_types >= 2:
            score *= 1.0
        else:
            score *= 0.9
        
        return min(1.0, score)
    
    def calculate_balance_score(self, plan: DecompositionPlan) -> float:
        """
        Measures balance across sub-problems.
        
        Evaluates:
        - Complexity distribution
        - Effort distribution
        - Priority distribution
        - Size distribution
        """
        self.logger.info(f"Calculating balance score for plan {plan.id}")
        
        if not plan.sub_problems:
            return 0.0
        
        score = 1.0
        
        # Check 1: Complexity balance
        complexities = [sp.complexity_score.overall_complexity for sp in plan.sub_problems]
        avg_complexity = sum(complexities) / len(complexities)
        variance = sum((c - avg_complexity) ** 2 for c in complexities) / len(complexities)
        
        if variance < 4.0:
            score *= 1.0
        elif variance < 9.0:
            score *= 0.85
        else:
            score *= 0.7
        
        # Check 2: Effort balance
        efforts = [sp.estimated_effort for sp in plan.sub_problems]
        avg_effort = sum(efforts) / len(efforts)
        effort_variance = sum((e - avg_effort) ** 2 for e in efforts) / len(efforts)
        
        if effort_variance < 100:
            score *= 1.0
        elif effort_variance < 400:
            score *= 0.9
        else:
            score *= 0.8
        
        # Check 3: Size balance (description length)
        sizes = [len(sp.description) for sp in plan.sub_problems]
        avg_size = sum(sizes) / len(sizes)
        size_variance = sum((s - avg_size) ** 2 for s in sizes) / len(sizes)
        
        if size_variance < 10000:
            score *= 1.0
        elif size_variance < 40000:
            score *= 0.9
        else:
            score *= 0.85
        
        return min(1.0, score)
    
    def calculate_clarity_score(self, plan: DecompositionPlan) -> float:
        """
        Measures clarity and understandability.
        
        Evaluates:
        - Description quality
        - Title clarity
        - Success criteria clarity
        - Documentation completeness
        """
        self.logger.info(f"Calculating clarity score for plan {plan.id}")
        
        if not plan.sub_problems:
            return 0.0
        
        score = 1.0
        
        # Check 1: Description quality
        good_descriptions = sum(1 for sp in plan.sub_problems 
                               if sp.description and len(sp.description.strip()) >= 30)
        description_ratio = good_descriptions / len(plan.sub_problems)
        score *= (0.5 + 0.5 * description_ratio)
        
        # Check 2: Title clarity (not too short, not too long)
        good_titles = sum(1 for sp in plan.sub_problems 
                         if sp.title and 10 <= len(sp.title) <= 80)
        title_ratio = good_titles / len(plan.sub_problems)
        score *= (0.7 + 0.3 * title_ratio)
        
        # Check 3: Success criteria clarity
        with_clear_criteria = sum(1 for sp in plan.sub_problems 
                                 if sp.success_criteria and 
                                 all(len(c.description) >= 10 for c in sp.success_criteria))
        criteria_ratio = with_clear_criteria / len(plan.sub_problems)
        score *= (0.6 + 0.4 * criteria_ratio)
        
        # Check 4: Metadata completeness
        with_metadata = sum(1 for sp in plan.sub_problems if sp.metadata)
        metadata_ratio = with_metadata / len(plan.sub_problems)
        score *= (0.8 + 0.2 * metadata_ratio)
        
        return min(1.0, score)
    
    def generate_quality_report(self, plan: DecompositionPlan) -> QualityReport:
        """
        Generates comprehensive quality report using LLM when available.
        
        Args:
            plan: The decomposition plan to assess
            
        Returns:
            QualityReport with detailed metrics and recommendations
        """
        self.logger.info(f"Generating quality report for plan {plan.id}")
        
        # Try LLM-based assessment first
        llm_metrics = self.assess_with_llm(plan)
        
        if llm_metrics:
            self.logger.info("Using LLM-based quality assessment")
            metrics = llm_metrics
            strengths = llm_metrics.details.get('strengths', [])
            weaknesses = llm_metrics.details.get('weaknesses', [])
            recommendations = llm_metrics.details.get('recommendations', [])
        else:
            # Fallback to heuristic assessment
            self.logger.info("Using heuristic quality assessment")
            coherence = self.calculate_coherence_score(plan)
            completeness = self.calculate_completeness_score(plan)
            feasibility = self.calculate_feasibility_score(plan)
            integration = self.calculate_integration_score(plan)
            balance = self.calculate_balance_score(plan)
            clarity = self.calculate_clarity_score(plan)
            
            # Calculate overall score (weighted average)
            weights = {
                'coherence': 0.20,
                'completeness': 0.20,
                'feasibility': 0.20,
                'integration': 0.15,
                'balance': 0.15,
                'clarity': 0.10
            }
            
            overall = (
                coherence * weights['coherence'] +
                completeness * weights['completeness'] +
                feasibility * weights['feasibility'] +
                integration * weights['integration'] +
                balance * weights['balance'] +
                clarity * weights['clarity']
            )
            
            # Create metrics object
            metrics = QualityMetrics(
                coherence_score=coherence,
                completeness_score=completeness,
            feasibility_score=feasibility,
            integration_score=integration,
            balance_score=balance,
            clarity_score=clarity,
            overall_score=overall,
            details={
                'sub_problem_count': len(plan.sub_problems),
                'avg_complexity': sum(sp.complexity_score.overall_complexity 
                                    for sp in plan.sub_problems) / len(plan.sub_problems) if plan.sub_problems else 0,
                'total_effort': sum(sp.estimated_effort for sp in plan.sub_problems),
                'strategy': plan.strategy.value
            }
        )
        
        # Identify strengths
        strengths = []
        if coherence >= 0.85:
            strengths.append("Excellent logical coherence")
        if completeness >= 0.85:
            strengths.append("Comprehensive problem coverage")
        if feasibility >= 0.85:
            strengths.append("Highly feasible sub-problems")
        if integration >= 0.85:
            strengths.append("Strong integration potential")
        if balance >= 0.85:
            strengths.append("Well-balanced decomposition")
        if clarity >= 0.85:
            strengths.append("Clear and understandable")
        
        # Identify weaknesses
        weaknesses = []
        if coherence < self.thresholds['coherence']:
            weaknesses.append(f"Coherence below threshold ({coherence:.2f} < {self.thresholds['coherence']})")
        if completeness < self.thresholds['completeness']:
            weaknesses.append(f"Completeness below threshold ({completeness:.2f} < {self.thresholds['completeness']})")
        if feasibility < self.thresholds['feasibility']:
            weaknesses.append(f"Feasibility concerns ({feasibility:.2f} < {self.thresholds['feasibility']})")
        if integration < self.thresholds['integration']:
            weaknesses.append(f"Integration challenges ({integration:.2f} < {self.thresholds['integration']})")
        if balance < self.thresholds['balance']:
            weaknesses.append(f"Imbalanced distribution ({balance:.2f} < {self.thresholds['balance']})")
        if clarity < self.thresholds['clarity']:
            weaknesses.append(f"Clarity issues ({clarity:.2f} < {self.thresholds['clarity']})")
        
        # Generate recommendations
        recommendations = []
        if coherence < 0.8:
            recommendations.append("Improve alignment between sub-problems and parent problem")
        if completeness < 0.8:
            recommendations.append("Consider adding more sub-problems to cover all aspects")
        if feasibility < 0.8:
            recommendations.append("Reduce complexity or split complex sub-problems")
        if integration < 0.8:
            recommendations.append("Clarify dependencies and integration points")
        if balance < 0.8:
            recommendations.append("Rebalance complexity and effort across sub-problems")
        if clarity < 0.8:
            recommendations.append("Improve descriptions and success criteria clarity")
        
        # Check if meets thresholds
        meets_thresholds = all([
            coherence >= self.thresholds['coherence'],
            completeness >= self.thresholds['completeness'],
            feasibility >= self.thresholds['feasibility'],
            integration >= self.thresholds['integration'],
            balance >= self.thresholds['balance'],
            clarity >= self.thresholds['clarity'],
            overall >= self.thresholds['overall']
        ])
        
        return QualityReport(
            plan_id=plan.id,
            metrics=metrics,
            strengths=strengths,
            weaknesses=weaknesses,
            recommendations=recommendations,
            meets_thresholds=meets_thresholds,
            generated_at=datetime.now()
        )
    
    def check_quality_thresholds(self, metrics: QualityMetrics) -> bool:
        """
        Validates scores meet minimum thresholds.
        
        Args:
            metrics: QualityMetrics to check
            
        Returns:
            True if all thresholds are met
        """
        return all([
            metrics.coherence_score >= self.thresholds['coherence'],
            metrics.completeness_score >= self.thresholds['completeness'],
            metrics.feasibility_score >= self.thresholds['feasibility'],
            metrics.integration_score >= self.thresholds['integration'],
            metrics.balance_score >= self.thresholds['balance'],
            metrics.clarity_score >= self.thresholds['clarity'],
            metrics.overall_score >= self.thresholds['overall']
        ])
    
    def update_plan_quality_scores(self, plan: DecompositionPlan) -> QualityScores:
        """
        Updates plan with quality scores.
        
        Args:
            plan: The decomposition plan to update
            
        Returns:
            QualityScores object
        """
        report = self.generate_quality_report(plan)
        
        quality_scores = QualityScores(
            coherence_score=report.metrics.coherence_score,
            completeness_score=report.metrics.completeness_score,
            feasibility_score=report.metrics.feasibility_score,
            integration_score=report.metrics.integration_score,
            overall_score=report.metrics.overall_score,
            meets_thresholds=report.meets_thresholds,
            details={
                'balance_score': report.metrics.balance_score,
                'clarity_score': report.metrics.clarity_score,
                'strengths': report.strengths,
                'weaknesses': report.weaknesses,
                'recommendations': report.recommendations
            },
            timestamp=report.generated_at
        )
        
        # Update plan
        plan.quality_scores = quality_scores
        
        return quality_scores
