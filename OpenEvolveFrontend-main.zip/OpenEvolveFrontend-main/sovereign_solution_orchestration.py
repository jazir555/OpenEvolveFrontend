"""
Sovereign-Grade Problem Decomposition System - Solution Orchestration
Tracks solution attempts, validates, and integrates sub-solutions.
"""

import logging
from typing import List, Dict, Any, Optional
from datetime import datetime
from dataclasses import dataclass

from sovereign_data_models import (
    DecompositionPlan, SubProblem, SolutionAttempt, ValidationResult,
    Feedback, generate_id
)

logger = logging.getLogger(__name__)


@dataclass
class IntegratedSolution:
    """Represents an integrated solution from multiple sub-solutions."""
    id: str
    plan_id: str
    sub_solutions: List[SolutionAttempt]
    integration_method: str
    final_content: str
    confidence_score: float
    validation_results: List[ValidationResult]
    conflicts_resolved: List[str]
    created_at: datetime
    metadata: Dict[str, Any]


@dataclass
class Conflict:
    """Represents a conflict between sub-solutions."""
    id: str
    solution_ids: List[str]
    conflict_type: str
    description: str
    severity: str  # low, medium, high, critical
    suggested_resolution: Optional[str] = None


class SolutionOrchestrator:
    """Orchestrates solution attempts and integration with LLM-powered conflict detection."""
    
    def __init__(self, openevolve_client=None):
        self.solution_attempts: Dict[str, List[SolutionAttempt]] = {}
        self.integrated_solutions: Dict[str, IntegratedSolution] = {}
        self.openevolve_client = openevolve_client
        self.logger = logging.getLogger(__name__)
        
        if not self.openevolve_client:
            try:
                from openevolve_client import OpenEvolveClient
                self.openevolve_client = OpenEvolveClient()
            except:
                self.logger.warning("OpenEvolve client not available for solution orchestration")
    
    def track_solution_attempt(
        self,
        sub_problem_id: str,
        approach: str,
        solution_content: str,
        team_id: str,
        confidence_score: float = 0.8
    ) -> SolutionAttempt:
        """
        Records solution attempt with metadata.
        
        Args:
            sub_problem_id: ID of the sub-problem being solved
            approach: Description of the approach taken
            solution_content: The actual solution content
            team_id: ID of the team that created the solution
            confidence_score: Confidence in the solution (0-1)
            
        Returns:
            SolutionAttempt object
        """
        self.logger.info(f"Tracking solution attempt for sub-problem {sub_problem_id}")
        
        attempt = SolutionAttempt(
            id=generate_id("solution"),
            sub_problem_id=sub_problem_id,
            approach=approach,
            solution_content=solution_content,
            team_id=team_id,
            confidence_score=confidence_score,
            validation_results=[],
            feedback=[],
            status="pending",
            created_at=datetime.now(),
            metadata={
                'content_length': len(solution_content),
                'approach_type': self._classify_approach(approach)
            }
        )
        
        # Store attempt
        if sub_problem_id not in self.solution_attempts:
            self.solution_attempts[sub_problem_id] = []
        self.solution_attempts[sub_problem_id].append(attempt)
        
        return attempt
    
    def validate_solution(
        self,
        attempt: SolutionAttempt,
        sub_problem: SubProblem
    ) -> ValidationResult:
        """
        Validates solution against success criteria.
        
        Args:
            attempt: The solution attempt to validate
            sub_problem: The sub-problem with success criteria
            
        Returns:
            ValidationResult with pass/fail and feedback
        """
        self.logger.info(f"Validating solution {attempt.id}")
        
        if not sub_problem.success_criteria:
            # No criteria defined, assume valid
            result = ValidationResult(
                validator="solution_orchestrator",
                passed=True,
                score=0.8,
                feedback="No success criteria defined, solution accepted",
                improvements=[],
                timestamp=datetime.now()
            )
        else:
            # Validate against each criterion
            passed_criteria = 0
            total_criteria = len(sub_problem.success_criteria)
            feedback_items = []
            
            for criterion in sub_problem.success_criteria:
                # Simple validation: check if solution mentions the criterion
                if self._check_criterion(attempt.solution_content, criterion):
                    passed_criteria += 1
                else:
                    feedback_items.append(f"Does not satisfy: {criterion.description}")
            
            score = passed_criteria / total_criteria if total_criteria > 0 else 0.0
            passed = score >= 0.7  # 70% threshold
            
            result = ValidationResult(
                validator="solution_orchestrator",
                passed=passed,
                score=score,
                feedback=f"Satisfied {passed_criteria}/{total_criteria} success criteria",
                improvements=feedback_items,
                timestamp=datetime.now()
            )
        
        # Store validation result
        attempt.validation_results.append(result)
        
        # Update attempt status
        if result.passed:
            attempt.status = "validated"
        else:
            attempt.status = "rejected"
        
        return result
    
    def integrate_solutions(
        self,
        plan: DecompositionPlan,
        attempts: Optional[List[SolutionAttempt]] = None
    ) -> IntegratedSolution:
        """
        Combines sub-solutions into final solution.
        
        Args:
            plan: The decomposition plan
            attempts: Optional list of solution attempts (uses stored if None)
            
        Returns:
            IntegratedSolution with combined content
        """
        self.logger.info(f"Integrating solutions for plan {plan.id}")
        
        # Get solution attempts for each sub-problem
        if attempts is None:
            attempts = []
            for sp in plan.sub_problems:
                sp_attempts = self.solution_attempts.get(sp.id, [])
                # Use the best validated attempt
                validated = [a for a in sp_attempts if a.status == "validated"]
                if validated:
                    best = max(validated, key=lambda a: a.confidence_score)
                    attempts.append(best)
        
        if not attempts:
            raise ValueError("No solution attempts available for integration")
        
        # Check for conflicts
        conflicts = self.detect_conflicts(attempts)
        
        # Resolve conflicts if any
        if conflicts:
            self.logger.warning(f"Found {len(conflicts)} conflicts, attempting resolution")
            attempts = self._resolve_conflicts(attempts, conflicts)
        
        # Integrate solutions based on dependency order
        if plan.dependency_graph and plan.dependency_graph.execution_order:
            # Sort attempts by execution order
            order_map = {sp_id: i for i, sp_id in enumerate(plan.dependency_graph.execution_order)}
            attempts = sorted(attempts, key=lambda a: order_map.get(a.sub_problem_id, 999))
        
        # Combine solutions
        integration_method = "sequential_merge"
        combined_content = self._merge_solutions(attempts, integration_method)
        
        # Calculate overall confidence
        overall_confidence = self.calculate_confidence(attempts)
        
        # Create integrated solution
        integrated = IntegratedSolution(
            id=generate_id("integrated"),
            plan_id=plan.id,
            sub_solutions=attempts,
            integration_method=integration_method,
            final_content=combined_content,
            confidence_score=overall_confidence,
            validation_results=[],
            conflicts_resolved=[c.id for c in conflicts],
            created_at=datetime.now(),
            metadata={
                'sub_solution_count': len(attempts),
                'total_length': len(combined_content),
                'conflicts_found': len(conflicts)
            }
        )
        
        # Store integrated solution
        self.integrated_solutions[plan.id] = integrated
        
        return integrated
    
    def detect_conflicts(self, solutions: List[SolutionAttempt]) -> List[Conflict]:
        """
        Identifies conflicting sub-solutions using LLM analysis.
        
        Args:
            solutions: List of solution attempts
            
        Returns:
            List of detected conflicts
        """
        self.logger.info(f"Detecting conflicts among {len(solutions)} solutions")
        
        conflicts = []
        
        # Try LLM-based conflict detection for deep analysis
        if self.openevolve_client and len(solutions) >= 2:
            try:
                llm_conflicts = self._detect_conflicts_with_llm(solutions)
                if llm_conflicts:
                    conflicts.extend(llm_conflicts)
                    self.logger.info(f"LLM detected {len(llm_conflicts)} conflicts")
                    return conflicts
            except Exception as e:
                self.logger.warning(f"LLM conflict detection failed: {e}")
        
        # Fallback to heuristic detection
        # Check for contradictions in approach
        approaches = {}
        for solution in solutions:
            approach_type = solution.metadata.get('approach_type', 'unknown')
            if approach_type not in approaches:
                approaches[approach_type] = []
            approaches[approach_type].append(solution)
        
        # If too many different approaches, might be a conflict
        if len(approaches) > len(solutions) * 0.7:
            conflict = Conflict(
                id=generate_id("conflict"),
                solution_ids=[s.id for s in solutions],
                conflict_type="approach_inconsistency",
                description="Solutions use inconsistent approaches",
                severity="medium",
                suggested_resolution="Align approaches or choose dominant strategy"
            )
            conflicts.append(conflict)
        
        # Check for confidence conflicts (some very low confidence)
        low_confidence = [s for s in solutions if s.confidence_score < 0.5]
        if low_confidence:
            conflict = Conflict(
                id=generate_id("conflict"),
                solution_ids=[s.id for s in low_confidence],
                conflict_type="low_confidence",
                description=f"{len(low_confidence)} solutions have low confidence",
                severity="high" if len(low_confidence) > len(solutions) * 0.3 else "medium",
                suggested_resolution="Review and improve low-confidence solutions"
            )
            conflicts.append(conflict)
        
        # Check for validation failures
        failed = [s for s in solutions if s.status == "rejected"]
        if failed:
            conflict = Conflict(
                id=generate_id("conflict"),
                solution_ids=[s.id for s in failed],
                conflict_type="validation_failure",
                description=f"{len(failed)} solutions failed validation",
                severity="critical",
                suggested_resolution="Fix or replace failed solutions"
            )
            conflicts.append(conflict)
        
        return conflicts
    
    def calculate_confidence(self, solutions: List[SolutionAttempt]) -> float:
        """
        Calculates overall solution confidence.
        
        Args:
            solutions: List of solution attempts
            
        Returns:
            Overall confidence score (0-1)
        """
        if not solutions:
            return 0.0
        
        # Base confidence is average of individual confidences
        avg_confidence = sum(s.confidence_score for s in solutions) / len(solutions)
        
        # Adjust based on validation results
        validated = sum(1 for s in solutions if s.status == "validated")
        validation_ratio = validated / len(solutions)
        
        # Adjust based on conflicts
        # (This would be called after conflict detection in practice)
        
        # Weighted combination
        overall = (avg_confidence * 0.6 + validation_ratio * 0.4)
        
        return min(1.0, overall)
    
    def get_solution_status(self, plan_id: str) -> Dict[str, Any]:
        """
        Gets status of solution attempts for a plan.
        
        Args:
            plan_id: ID of the decomposition plan
            
        Returns:
            Dictionary with solution status information
        """
        integrated = self.integrated_solutions.get(plan_id)
        
        if integrated:
            return {
                'plan_id': plan_id,
                'status': 'integrated',
                'confidence': integrated.confidence_score,
                'sub_solution_count': len(integrated.sub_solutions),
                'conflicts_resolved': len(integrated.conflicts_resolved),
                'created_at': integrated.created_at.isoformat()
            }
        else:
            # Count attempts
            total_attempts = sum(len(attempts) for attempts in self.solution_attempts.values())
            validated = sum(1 for attempts in self.solution_attempts.values() 
                          for a in attempts if a.status == "validated")
            
            return {
                'plan_id': plan_id,
                'status': 'in_progress',
                'total_attempts': total_attempts,
                'validated_attempts': validated,
                'integration_ready': False
            }
    
    # Helper methods
    
    def _classify_approach(self, approach: str) -> str:
        """Classify the approach type."""
        approach_lower = approach.lower()
        
        if any(word in approach_lower for word in ['algorithm', 'compute', 'calculate']):
            return 'algorithmic'
        elif any(word in approach_lower for word in ['design', 'architecture', 'structure']):
            return 'architectural'
        elif any(word in approach_lower for word in ['implement', 'code', 'develop']):
            return 'implementation'
        elif any(word in approach_lower for word in ['analyze', 'study', 'research']):
            return 'analytical'
        else:
            return 'general'
    
    def _check_criterion(self, solution_content: str, criterion) -> bool:
        """Check if solution satisfies a criterion."""
        # Simple heuristic: check if criterion keywords appear in solution
        content_lower = solution_content.lower()
        criterion_lower = criterion.description.lower()
        
        # Extract key words from criterion
        words = [w for w in criterion_lower.split() if len(w) > 4]
        
        # Check if at least 30% of key words appear
        if not words:
            return True
        
        matches = sum(1 for word in words if word in content_lower)
        return matches >= len(words) * 0.3
    
    def _resolve_conflicts(
        self,
        attempts: List[SolutionAttempt],
        conflicts: List[Conflict]
    ) -> List[SolutionAttempt]:
        """Attempt to resolve conflicts."""
        # Simple resolution: filter out rejected and low-confidence solutions
        resolved = []
        
        for attempt in attempts:
            # Skip rejected solutions
            if attempt.status == "rejected":
                continue
            
            # Skip very low confidence
            if attempt.confidence_score < 0.3:
                continue
            
            resolved.append(attempt)
        
        # If we filtered out too many, keep the best ones
        if len(resolved) < len(attempts) * 0.5:
            # Keep top 50% by confidence
            sorted_attempts = sorted(attempts, key=lambda a: a.confidence_score, reverse=True)
            resolved = sorted_attempts[:max(1, len(attempts) // 2)]
        
        return resolved
    
    def _merge_solutions(
        self,
        attempts: List[SolutionAttempt],
        method: str
    ) -> str:
        """Merge solutions using specified method."""
        if method == "sequential_merge":
            # Simple concatenation with separators
            parts = []
            for i, attempt in enumerate(attempts):
                parts.append(f"## Sub-Solution {i+1}\n")
                parts.append(f"**Approach**: {attempt.approach}\n\n")
                parts.append(attempt.solution_content)
                parts.append("\n\n")
            
            return "".join(parts)
        
        elif method == "hierarchical_merge":
            # Organize by sub-problem hierarchy
            # (Would need dependency information)
            return self._merge_solutions(attempts, "sequential_merge")
        
        else:
            # Default to sequential
            return self._merge_solutions(attempts, "sequential_merge")
    
    def clear_attempts(self, plan_id: Optional[str] = None):
        """Clear solution attempts (for testing or reset)."""
        if plan_id:
            # Clear attempts for specific plan
            to_remove = [sp_id for sp_id, attempts in self.solution_attempts.items()
                        if any(a.metadata.get('plan_id') == plan_id for a in attempts)]
            for sp_id in to_remove:
                del self.solution_attempts[sp_id]
            
            if plan_id in self.integrated_solutions:
                del self.integrated_solutions[plan_id]
        else:
            # Clear all
            self.solution_attempts.clear()
            self.integrated_solutions.clear()

    def _detect_conflicts_with_llm(self, solutions: List[SolutionAttempt]) -> List[Conflict]:
        """Use LLM to detect sophisticated conflicts between solutions."""
        # Build solutions summary
        sol_summary = "\n\n".join([
            f"SOLUTION {i+1} (ID: {s.id[:8]}):\nApproach: {s.approach}\nConfidence: {s.confidence_score:.2f}\nContent: {s.solution_content[:200]}..."
            for i, s in enumerate(solutions[:5])  # Limit to 5 for tokens
        ])
        
        prompt = f"""You are an expert at detecting conflicts and inconsistencies between solution attempts. Analyze these solutions for conflicts.

SOLUTIONS TO ANALYZE:
{sol_summary}

CONFLICT DETECTION:
Identify conflicts in these categories:

1. LOGICAL CONFLICTS: Contradictory logic or approaches
2. ASSUMPTION CONFLICTS: Incompatible assumptions
3. INTERFACE CONFLICTS: Incompatible interfaces or data formats
4. DEPENDENCY CONFLICTS: Conflicting dependencies or requirements
5. QUALITY CONFLICTS: Significant quality differences

For each conflict found, provide:
- Type: (logical/assumption/interface/dependency/quality)
- Description: Clear description of the conflict
- Severity: (critical/high/medium/low)
- Resolution: Suggested way to resolve

Format EXACTLY as:
---
CONFLICT 1
Type: <type>
Description: <description>
Severity: <severity>
Resolution: <resolution>
---

List all conflicts found (or "NO CONFLICTS" if none):"""
        
        result = self.openevolve_client.evolve(
            content=prompt,
            evolution_mode="standard",
            content_type="analysis",
            max_iterations=1,
            temperature=0.3,
            max_tokens=800
        )
        
        if result.success and result.best_code:
            if "NO CONFLICTS" in result.best_code.upper():
                return []
            return self._parse_conflict_response(result.best_code, solutions)
        
        return []
    
    def _parse_conflict_response(self, response: str, solutions: List[SolutionAttempt]) -> List[Conflict]:
        """Parse LLM conflict detection response."""
        conflicts = []
        sections = response.split('---')
        
        for section in sections:
            section = section.strip()
            if not section or 'CONFLICT' not in section:
                continue
            
            try:
                conflict_type = self._extract_conflict_field(section, 'Type:')
                description = self._extract_conflict_field(section, 'Description:')
                severity = self._extract_conflict_field(section, 'Severity:').lower()
                resolution = self._extract_conflict_field(section, 'Resolution:')
                
                if not description:
                    continue
                
                conflict = Conflict(
                    id=generate_id("conflict"),
                    solution_ids=[s.id for s in solutions],
                    conflict_type=conflict_type or "unknown",
                    description=description,
                    severity=severity if severity in ['critical', 'high', 'medium', 'low'] else 'medium',
                    suggested_resolution=resolution
                )
                conflicts.append(conflict)
                
            except Exception as e:
                self.logger.debug(f"Failed to parse conflict section: {e}")
                continue
        
        return conflicts
    
    def _extract_conflict_field(self, text: str, field_name: str) -> str:
        """Extract field value from conflict text."""
        lines = text.split('\n')
        for line in lines:
            if line.strip().startswith(field_name):
                return line.split(':', 1)[1].strip()
        return ""
    
    def merge_solutions_intelligently(self, solutions: List[SolutionAttempt], conflicts: List[Conflict]) -> str:
        """
        Intelligently merge solutions using LLM, resolving conflicts.
        
        Args:
            solutions: Solutions to merge
            conflicts: Detected conflicts
            
        Returns:
            Merged solution content
        """
        if not self.openevolve_client:
            return self._fallback_merge(solutions)
        
        try:
            # Build context
            sol_summary = "\n\n".join([
                f"SOLUTION {i+1}:\n{s.solution_content[:300]}..."
                for i, s in enumerate(solutions[:5])
            ])
            
            conflict_summary = "\n".join([
                f"- {c.description} (Severity: {c.severity})"
                for c in conflicts[:5]
            ])
            
            prompt = f"""You are an expert at merging multiple solution attempts into a cohesive final solution. Merge these solutions while resolving conflicts.

SOLUTIONS TO MERGE:
{sol_summary}

CONFLICTS TO RESOLVE:
{conflict_summary if conflicts else "No conflicts detected"}

MERGING TASK:
Create a unified solution that:
1. Incorporates the best aspects of each solution
2. Resolves all conflicts intelligently
3. Maintains consistency and coherence
4. Preserves critical functionality from all solutions

Provide the merged solution:"""
            
            result = self.openevolve_client.evolve(
                content=prompt,
                evolution_mode="standard",
                content_type="code",
                max_iterations=1,
                temperature=0.4,
                max_tokens=1500
            )
            
            if result.success and result.best_code:
                self.logger.info("LLM successfully merged solutions")
                return result.best_code
        
        except Exception as e:
            self.logger.warning(f"LLM merging failed: {e}")
        
        return self._fallback_merge(solutions)
    
    def _fallback_merge(self, solutions: List[SolutionAttempt]) -> str:
        """Fallback heuristic merging."""
        # Simple concatenation with highest confidence first
        sorted_solutions = sorted(solutions, key=lambda s: s.confidence_score, reverse=True)
        merged = "\n\n=== MERGED SOLUTION ===\n\n"
        
        for i, sol in enumerate(sorted_solutions, 1):
            merged += f"--- Component {i} (Confidence: {sol.confidence_score:.2f}) ---\n"
            merged += sol.solution_content
            merged += "\n\n"
        
        return merged
