"""
Sovereign-Grade Problem Decomposition System - UI Components
Streamlit UI components for decomposition visualization and interaction.
"""

import streamlit as st
import plotly.graph_objects as go
import plotly.express as px
from typing import List, Dict, Any, Optional
from datetime import datetime
import pandas as pd

from sovereign_data_models import (
    DecompositionPlan, SubProblem, ProblemDefinition, QualityScores
)
from sovereign_quality_assessment import QualityReport, QualityMetrics
from sovereign_refinement import RefinementCycle


def render_problem_input_form() -> Optional[Dict[str, Any]]:
    """
    Render problem input form for sovereign decomposition.
    
    Returns:
        Dictionary with problem details or None if not submitted
    """
    st.subheader("📝 Problem Definition")
    
    with st.form("sovereign_problem_form"):
        title = st.text_input(
            "Problem Title",
            placeholder="e.g., Build Recommendation System"
        )
        
        description = st.text_area(
            "Problem Description",
            placeholder="Describe the problem in detail...",
            height=150
        )
        
        col1, col2 = st.columns(2)
        
        with col1:
            problem_type = st.selectbox(
                "Problem Type",
                ["research", "implementation", "analysis", "optimization", "design"]
            )
        
        with col2:
            domain = st.text_input(
                "Domain",
                placeholder="e.g., machine_learning"
            )
        
        submitted = st.form_submit_button("🚀 Analyze Problem", use_container_width=True)
        
        if submitted and title and description:
            return {
                'title': title,
                'description': description,
                'problem_type': problem_type,
                'domain': domain
            }
    
    return None


def render_strategy_selection(
    available_strategies: List[str],
    recommended_strategy: Optional[str] = None
) -> str:
    """
    Render strategy selection interface.
    
    Args:
        available_strategies: List of available strategy names
        recommended_strategy: Optional recommended strategy
        
    Returns:
        Selected strategy name
    """
    st.subheader("🎯 Decomposition Strategy")
    
    if recommended_strategy:
        st.info(f"💡 Recommended strategy: **{recommended_strategy}** (based on historical performance)")
    
    col1, col2 = st.columns([3, 1])
    
    with col1:
        strategy = st.selectbox(
            "Select Strategy",
            available_strategies,
            index=available_strategies.index(recommended_strategy) if recommended_strategy in available_strategies else 0
        )
    
    with col2:
        st.metric("Available", len(available_strategies))
    
    # Strategy descriptions
    descriptions = {
        'semantic': "Decomposes based on semantic concept relationships",
        'dependency': "Decomposes based on causal and prerequisite relationships",
        'complexity': "Balances cognitive load and resource requirements",
        'hybrid': "Combines multiple strategies adaptively",
        'research': "Hypothesis-driven decomposition for research problems"
    }
    
    if strategy in descriptions:
        st.caption(descriptions[strategy])
    
    return strategy


def render_decomposition_plan(plan: DecompositionPlan) -> None:
    """
    Render complete decomposition plan with sub-problems.
    
    Args:
        plan: The decomposition plan to display
    """
    st.subheader("📋 Decomposition Plan")
    
    # Plan overview
    col1, col2, col3, col4 = st.columns(4)
    
    with col1:
        st.metric("Sub-Problems", len(plan.sub_problems))
    
    with col2:
        st.metric("Strategy", plan.strategy.value.title())
    
    with col3:
        st.metric("Confidence", f"{plan.confidence_level:.1%}")
    
    with col4:
        total_effort = sum(sp.estimated_effort for sp in plan.sub_problems)
        st.metric("Total Effort", f"{total_effort}h")
    
    # Sub-problems list
    st.markdown("---")
    st.markdown("### Sub-Problems")
    
    for i, sp in enumerate(plan.sub_problems, 1):
        with st.expander(f"**{i}. {sp.title}**", expanded=i <= 3):
            render_sub_problem_detail(sp)


def render_sub_problem_detail(sub_problem: SubProblem) -> None:
    """
    Render detailed view of a single sub-problem.
    
    Args:
        sub_problem: The sub-problem to display
    """
    st.markdown(f"**Description:** {sub_problem.description}")
    
    col1, col2, col3 = st.columns(3)
    
    with col1:
        st.metric("Type", sub_problem.type.value.title())
    
    with col2:
        st.metric("Priority", f"{sub_problem.priority}/10")
    
    with col3:
        st.metric("Effort", f"{sub_problem.estimated_effort}h")
    
    # Complexity breakdown
    if sub_problem.complexity_score:
        st.markdown("**Complexity:**")
        complexity_data = {
            'Cognitive': sub_problem.complexity_score.cognitive_complexity,
            'Computational': sub_problem.complexity_score.computational_complexity,
            'Domain': sub_problem.complexity_score.domain_complexity,
            'Integration': sub_problem.complexity_score.integration_complexity
        }
        
        fig = go.Figure(data=[
            go.Bar(
                x=list(complexity_data.keys()),
                y=list(complexity_data.values()),
                marker_color=['#FF6B6B', '#4ECDC4', '#45B7D1', '#FFA07A']
            )
        ])
        fig.update_layout(
            height=200,
            margin=dict(l=0, r=0, t=0, b=0),
            yaxis_range=[0, 10]
        )
        st.plotly_chart(fig, use_container_width=True)
    
    # Dependencies
    if sub_problem.dependencies:
        st.markdown(f"**Dependencies:** {len(sub_problem.dependencies)} prerequisite(s)")
    
    # Success criteria
    if sub_problem.success_criteria:
        st.markdown("**Success Criteria:**")
        for criterion in sub_problem.success_criteria:
            st.markdown(f"- {criterion.description}")


def render_dependency_graph_visualization(plan: DecompositionPlan) -> None:
    """
    Render interactive dependency graph visualization.
    
    Args:
        plan: The decomposition plan with dependency graph
    """
    st.subheader("🕸️ Dependency Graph")
    
    if not plan.sub_problems:
        st.info("No sub-problems to visualize")
        return
    
    # Build graph data
    nodes = []
    edges = []
    
    for sp in plan.sub_problems:
        nodes.append({
            'id': sp.id,
            'label': sp.title[:30] + '...' if len(sp.title) > 30 else sp.title,
            'complexity': sp.complexity_score.overall_complexity if sp.complexity_score else 5,
            'priority': sp.priority
        })
        
        for dep in sp.dependencies:
            edges.append({'source': dep, 'target': sp.id})
    
    # Create network graph using plotly
    if nodes:
        # Simple layout - arrange in levels
        levels = _calculate_node_levels(nodes, edges)
        
        # Position nodes
        for i, node in enumerate(nodes):
            level = levels.get(node['id'], 0)
            node['x'] = level * 200
            node['y'] = i * 100
        
        # Create edge traces
        edge_trace = go.Scatter(
            x=[],
            y=[],
            line=dict(width=2, color='#888'),
            hoverinfo='none',
            mode='lines'
        )
        
        for edge in edges:
            source_node = next((n for n in nodes if n['id'] == edge['source']), None)
            target_node = next((n for n in nodes if n['id'] == edge['target']), None)
            
            if source_node and target_node:
                edge_trace['x'] += (source_node['x'], target_node['x'], None)
                edge_trace['y'] += (source_node['y'], target_node['y'], None)
        
        # Create node trace
        node_trace = go.Scatter(
            x=[n['x'] for n in nodes],
            y=[n['y'] for n in nodes],
            mode='markers+text',
            hoverinfo='text',
            text=[n['label'] for n in nodes],
            textposition="top center",
            marker=dict(
                size=[n['complexity'] * 5 for n in nodes],
                color=[n['priority'] for n in nodes],
                colorscale='Viridis',
                showscale=True,
                colorbar=dict(title="Priority"),
                line=dict(width=2, color='white')
            )
        )
        
        # Create figure
        fig = go.Figure(data=[edge_trace, node_trace])
        fig.update_layout(
            showlegend=False,
            hovermode='closest',
            margin=dict(b=0, l=0, r=0, t=0),
            xaxis=dict(showgrid=False, zeroline=False, showticklabels=False),
            yaxis=dict(showgrid=False, zeroline=False, showticklabels=False),
            height=400
        )
        
        st.plotly_chart(fig, use_container_width=True)
    
    # Show critical path
    if plan.dependency_graph and plan.dependency_graph.critical_path:
        st.markdown("**Critical Path:**")
        critical_titles = []
        for sp_id in plan.dependency_graph.critical_path:
            sp = next((s for s in plan.sub_problems if s.id == sp_id), None)
            if sp:
                critical_titles.append(sp.title)
        
        st.markdown(" → ".join(critical_titles))


def render_quality_dashboard(report: QualityReport) -> None:
    """
    Render quality metrics dashboard.
    
    Args:
        report: Quality assessment report
    """
    st.subheader("📊 Quality Metrics")
    
    metrics = report.metrics
    
    # Overall score
    col1, col2, col3 = st.columns([2, 1, 1])
    
    with col1:
        st.metric(
            "Overall Quality",
            f"{metrics.overall_score:.1%}",
            delta=f"{'✅ Meets' if report.meets_thresholds else '❌ Below'} Thresholds"
        )
    
    with col2:
        st.metric("Coherence", f"{metrics.coherence_score:.1%}")
    
    with col3:
        st.metric("Completeness", f"{metrics.completeness_score:.1%}")
    
    # Detailed metrics
    col1, col2, col3, col4 = st.columns(4)
    
    with col1:
        st.metric("Feasibility", f"{metrics.feasibility_score:.1%}")
    
    with col2:
        st.metric("Integration", f"{metrics.integration_score:.1%}")
    
    with col3:
        st.metric("Balance", f"{metrics.balance_score:.1%}")
    
    with col4:
        st.metric("Clarity", f"{metrics.clarity_score:.1%}")
    
    # Radar chart
    categories = ['Coherence', 'Completeness', 'Feasibility', 'Integration', 'Balance', 'Clarity']
    values = [
        metrics.coherence_score,
        metrics.completeness_score,
        metrics.feasibility_score,
        metrics.integration_score,
        metrics.balance_score,
        metrics.clarity_score
    ]
    
    fig = go.Figure(data=go.Scatterpolar(
        r=values,
        theta=categories,
        fill='toself',
        line_color='#4ECDC4'
    ))
    
    fig.update_layout(
        polar=dict(
            radialaxis=dict(visible=True, range=[0, 1])
        ),
        showlegend=False,
        height=300
    )
    
    st.plotly_chart(fig, use_container_width=True)
    
    # Strengths and weaknesses
    col1, col2 = st.columns(2)
    
    with col1:
        st.markdown("**✅ Strengths:**")
        for strength in report.strengths:
            st.markdown(f"- {strength}")
    
    with col2:
        st.markdown("**⚠️ Areas for Improvement:**")
        for weakness in report.weaknesses:
            st.markdown(f"- {weakness}")
    
    # Recommendations
    if report.recommendations:
        st.markdown("**💡 Recommendations:**")
        for rec in report.recommendations:
            st.info(rec)


def render_refinement_controls(plan: DecompositionPlan) -> Dict[str, Any]:
    """
    Render refinement controls and options.
    
    Args:
        plan: The decomposition plan
        
    Returns:
        Dictionary with refinement settings
    """
    st.subheader("🔄 Refinement Controls")
    
    col1, col2 = st.columns(2)
    
    with col1:
        max_cycles = st.slider(
            "Maximum Refinement Cycles",
            min_value=1,
            max_value=10,
            value=3,
            help="Maximum number of refinement iterations"
        )
    
    with col2:
        convergence_threshold = st.slider(
            "Convergence Threshold",
            min_value=0.001,
            max_value=0.1,
            value=0.01,
            step=0.001,
            format="%.3f",
            help="Quality improvement threshold for convergence"
        )
    
    auto_refine = st.checkbox(
        "Auto-refine on validation failure",
        value=True,
        help="Automatically refine when gauntlets fail"
    )
    
    if st.button("🚀 Start Refinement", use_container_width=True):
        return {
            'start': True,
            'max_cycles': max_cycles,
            'convergence_threshold': convergence_threshold,
            'auto_refine': auto_refine
        }
    
    return {'start': False}


def render_refinement_history(cycles: List[RefinementCycle]) -> None:
    """
    Render refinement history and progress.
    
    Args:
        cycles: List of refinement cycles
    """
    st.subheader("📈 Refinement History")
    
    if not cycles:
        st.info("No refinement cycles yet")
        return
    
    # Quality progression chart
    cycle_numbers = [c.cycle_number for c in cycles]
    quality_before = [c.quality_before for c in cycles]
    quality_after = [c.quality_after for c in cycles]
    
    fig = go.Figure()
    
    fig.add_trace(go.Scatter(
        x=cycle_numbers,
        y=quality_before,
        mode='lines+markers',
        name='Before',
        line=dict(color='#FF6B6B', dash='dash')
    ))
    
    fig.add_trace(go.Scatter(
        x=cycle_numbers,
        y=quality_after,
        mode='lines+markers',
        name='After',
        line=dict(color='#4ECDC4')
    ))
    
    fig.update_layout(
        title="Quality Progression",
        xaxis_title="Cycle",
        yaxis_title="Quality Score",
        yaxis_range=[0, 1],
        height=300
    )
    
    st.plotly_chart(fig, use_container_width=True)
    
    # Cycle details
    st.markdown("### Cycle Details")
    
    for cycle in cycles:
        with st.expander(f"Cycle {cycle.cycle_number} - Quality: {cycle.quality_after:.1%}"):
            col1, col2, col3 = st.columns(3)
            
            with col1:
                st.metric("Quality Before", f"{cycle.quality_before:.1%}")
            
            with col2:
                st.metric("Quality After", f"{cycle.quality_after:.1%}")
            
            with col3:
                improvement = cycle.quality_after - cycle.quality_before
                st.metric("Improvement", f"{improvement:+.1%}")
            
            if cycle.improvements_applied:
                st.markdown("**Improvements Applied:**")
                for imp in cycle.improvements_applied:
                    st.markdown(f"- {imp}")
            
            if cycle.converged:
                st.success("✅ Converged")


def render_solution_viewer(plan: DecompositionPlan) -> None:
    """
    Render solution viewing interface.
    
    Args:
        plan: The decomposition plan with solutions
    """
    st.subheader("💡 Solutions")
    
    solved_count = sum(1 for sp in plan.sub_problems if sp.status.value == 'solved')
    total_count = len(plan.sub_problems)
    
    progress = solved_count / total_count if total_count > 0 else 0
    
    st.progress(progress, text=f"Progress: {solved_count}/{total_count} sub-problems solved")
    
    # Group by status
    by_status = {}
    for sp in plan.sub_problems:
        status = sp.status.value
        if status not in by_status:
            by_status[status] = []
        by_status[status].append(sp)
    
    # Show tabs for each status
    tabs = st.tabs([f"{status.title()} ({len(sps)})" for status, sps in by_status.items()])
    
    for tab, (status, sps) in zip(tabs, by_status.items()):
        with tab:
            for sp in sps:
                with st.expander(sp.title):
                    st.markdown(sp.description)
                    
                    if sp.solution_attempts:
                        st.markdown(f"**Solution Attempts:** {len(sp.solution_attempts)}")


# Helper functions

def _calculate_node_levels(nodes: List[Dict], edges: List[Dict]) -> Dict[str, int]:
    """Calculate hierarchical levels for nodes based on dependencies."""
    levels = {}
    
    # Find nodes with no dependencies (level 0)
    node_ids = {n['id'] for n in nodes}
    has_incoming = {e['target'] for e in edges}
    
    for node in nodes:
        if node['id'] not in has_incoming:
            levels[node['id']] = 0
    
    # Assign levels based on dependencies
    changed = True
    while changed:
        changed = False
        for edge in edges:
            source_level = levels.get(edge['source'], 0)
            target_level = levels.get(edge['target'], 0)
            
            if target_level <= source_level:
                levels[edge['target']] = source_level + 1
                changed = True
    
    return levels
