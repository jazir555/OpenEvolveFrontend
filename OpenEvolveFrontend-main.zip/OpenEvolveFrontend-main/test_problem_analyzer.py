"""
Unit tests for Sovereign-Grade Problem Decomposition System - Problem Analyzer

Tests semantic analysis, domain extraction, complexity assessment, and constraint identification.
"""

import pytest
from problem_analyzer import ProblemAnalyzer
from sovereign_data_models import (
    ProblemType, DomainContext, ComplexityScore,
    Constraint, SuccessCriterion
)


@pytest.fixture
def analyzer():
    """Create a problem analyzer instance."""
    return ProblemAnalyzer()


# ============================================================================
# PROBLEM ANALYSIS TESTS
# ============================================================================

class TestProblemAnalysis:
    """Test complete problem analysis workflow."""
    
    def test_analyze_simple_problem(self, analyzer):
        """Test analyzing a simple problem."""
        problem_text = """
        We need to build a web application that allows users to track their daily tasks.
        The application should have a clean interface and work on mobile devices.
        """
        
        problem = analyzer.analyze_problem(problem_text, title="Task Tracker App")
        
        assert problem is not None
        assert problem.title == "Task Tracker App"
        assert problem.description == problem_text
        assert problem.problem_type in ProblemType
        assert problem.domain_context is not None
        assert problem.complexity_score is not None
        assert len(problem.success_criteria) > 0
    
    def test_analyze_complex_problem(self, analyzer):
        """Test analyzing a complex problem."""
        problem_text = """
        Design and implement a distributed machine learning system that can train
        models on large datasets across multiple nodes. The system must handle
        node failures gracefully, optimize resource utilization, and provide
        real-time monitoring. Performance should scale linearly with the number
        of nodes, and the system must integrate with existing data pipelines.
        """
        
        problem = analyzer.analyze_problem(problem_text)
        
        assert problem is not None
        assert problem.complexity_score.overall_complexity > 6.0
        assert len(problem.constraints) > 0
        assert len(problem.success_criteria) > 0
    
    def test_analyze_research_problem(self, analyzer):
        """Test analyzing a research-oriented problem."""
        problem_text = """
        Investigate the effectiveness of different neural network architectures
        for natural language understanding tasks. Study the trade-offs between
        model size, training time, and accuracy. Explore novel attention
        mechanisms and their impact on performance.
        """
        
        problem = analyzer.analyze_problem(problem_text)
        
        assert problem.problem_type == ProblemType.RESEARCH
        assert any("research" in c.description.lower() or "documented" in c.description.lower() 
                  for c in problem.success_criteria)


# ============================================================================
# DOMAIN EXTRACTION TESTS
# ============================================================================

class TestDomainExtraction:
    """Test domain context extraction."""
    
    def test_extract_software_domain(self, analyzer):
        """Test extracting software engineering domain."""
        problem_text = """
        Build a REST API for a microservices architecture. The API should handle
        authentication, rate limiting, and provide comprehensive documentation.
        """
        
        domain_context = analyzer.extract_domain_context(problem_text)
        
        assert domain_context is not None
        assert domain_context.domain == "software_engineering"
    
    def test_extract_ml_domain(self, analyzer):
        """Test extracting machine learning domain."""
        problem_text = """
        Train a neural network model to predict customer churn. Use historical
        data to identify patterns and optimize the model for accuracy.
        """
        
        domain_context = analyzer.extract_domain_context(problem_text)
        
        assert domain_context is not None
        assert domain_context.domain == "machine_learning"
    
    def test_extract_data_science_domain(self, analyzer):
        """Test extracting data science domain."""
        problem_text = """
        Analyze sales data to identify trends and create visualizations.
        Provide statistical insights and recommendations for business strategy.
        """
        
        domain_context = analyzer.extract_domain_context(problem_text)
        
        assert domain_context is not None
        assert domain_context.domain in ["data_science", "business_strategy"]
    
    def test_extract_general_domain(self, analyzer):
        """Test extracting general domain for ambiguous problems."""
        problem_text = "Solve this problem efficiently."
        
        domain_context = analyzer.extract_domain_context(problem_text)
        
        assert domain_context is not None
        assert domain_context.domain == "general"


# ============================================================================
# PROBLEM TYPE CLASSIFICATION TESTS
# ============================================================================

class TestProblemTypeClassification:
    """Test problem type classification."""
    
    def test_classify_research_problem(self, analyzer):
        """Test classifying research problems."""
        problem_text = "Research and investigate the best approaches for solving this challenge."
        
        problem_type = analyzer.classify_problem_type(problem_text)
        
        assert problem_type == ProblemType.RESEARCH
    
    def test_classify_implementation_problem(self, analyzer):
        """Test classifying implementation problems."""
        problem_text = "Implement a new feature that allows users to export data in multiple formats."
        
        problem_type = analyzer.classify_problem_type(problem_text)
        
        assert problem_type == ProblemType.IMPLEMENTATION
    
    def test_classify_analysis_problem(self, analyzer):
        """Test classifying analysis problems."""
        problem_text = "Analyze the current system performance and evaluate bottlenecks."
        
        problem_type = analyzer.classify_problem_type(problem_text)
        
        assert problem_type == ProblemType.ANALYSIS
    
    def test_classify_optimization_problem(self, analyzer):
        """Test classifying optimization problems."""
        problem_text = "Optimize the database queries to improve response time and minimize resource usage."
        
        problem_type = analyzer.classify_problem_type(problem_text)
        
        assert problem_type == ProblemType.OPTIMIZATION
    
    def test_classify_design_problem(self, analyzer):
        """Test classifying design problems."""
        problem_text = "Design a scalable architecture for the new microservices platform."
        
        problem_type = analyzer.classify_problem_type(problem_text)
        
        assert problem_type == ProblemType.DESIGN


# ============================================================================
# COMPLEXITY ASSESSMENT TESTS
# ============================================================================

class TestComplexityAssessment:
    """Test complexity assessment."""
    
    def test_assess_simple_problem_complexity(self, analyzer):
        """Test assessing complexity of a simple problem."""
        from sovereign_data_models import ProblemDefinition, generate_id
        
        problem = ProblemDefinition(
            id=generate_id("problem"),
            title="Simple Task",
            description="Create a simple todo list.",
            problem_type=ProblemType.IMPLEMENTATION,
            domain_context=DomainContext(domain="software_engineering"),
            complexity_score=ComplexityScore(
                cognitive_complexity=5.0,
                computational_complexity=5.0,
                domain_complexity=5.0,
                integration_complexity=5.0,
                overall_complexity=5.0,
                explanation="Initial"
            ),
            constraints=[],
            success_criteria=[],
            stakeholders=[],
            resources_available={}
        )
        
        complexity = analyzer.assess_complexity(problem)
        
        assert complexity is not None
        assert 0 <= complexity.cognitive_complexity <= 10
        assert 0 <= complexity.computational_complexity <= 10
        assert 0 <= complexity.domain_complexity <= 10
        assert 0 <= complexity.integration_complexity <= 10
        assert 0 <= complexity.overall_complexity <= 10
        assert complexity.explanation is not None
    
    def test_assess_complex_problem_complexity(self, analyzer):
        """Test assessing complexity of a complex problem."""
        from sovereign_data_models import ProblemDefinition, generate_id
        
        long_description = """
        Design and implement a highly scalable, fault-tolerant distributed system
        that processes real-time data streams from multiple sources. The system
        must handle millions of events per second, provide exactly-once processing
        guarantees, support complex event processing patterns, integrate with
        existing infrastructure, and provide comprehensive monitoring and alerting.
        The solution must be cost-effective, maintainable, and extensible.
        """
        
        problem = ProblemDefinition(
            id=generate_id("problem"),
            title="Distributed Stream Processing System",
            description=long_description,
            problem_type=ProblemType.DESIGN,
            domain_context=DomainContext(
                domain="software_engineering",
                subdomain="distributed_systems",
                related_domains=["data_engineering", "cloud_computing"]
            ),
            complexity_score=ComplexityScore(
                cognitive_complexity=5.0,
                computational_complexity=5.0,
                domain_complexity=5.0,
                integration_complexity=5.0,
                overall_complexity=5.0,
                explanation="Initial"
            ),
            constraints=[
                Constraint(id="c1", description="Performance", type="quality", severity="hard"),
                Constraint(id="c2", description="Cost", type="resource", severity="hard"),
            ],
            success_criteria=[],
            stakeholders=["engineering", "operations", "business"],
            resources_available={}
        )
        
        complexity = analyzer.assess_complexity(problem)
        
        assert complexity.overall_complexity > 6.0
        assert complexity.integration_complexity > 5.0


# ============================================================================
# CONSTRAINT IDENTIFICATION TESTS
# ============================================================================

class TestConstraintIdentification:
    """Test constraint identification."""
    
    def test_identify_time_constraints(self, analyzer):
        """Test identifying time constraints."""
        problem_text = "Complete the project within 3 months before the deadline."
        
        constraints = analyzer.identify_constraints(problem_text)
        
        assert len(constraints) > 0
        assert any(c.type == "time" for c in constraints)
    
    def test_identify_resource_constraints(self, analyzer):
        """Test identifying resource constraints."""
        problem_text = "Build the system with a limited budget of $50,000."
        
        constraints = analyzer.identify_constraints(problem_text)
        
        assert len(constraints) > 0
        assert any(c.type == "resource" for c in constraints)
    
    def test_identify_quality_constraints(self, analyzer):
        """Test identifying quality constraints."""
        problem_text = "The system must be highly reliable and maintain 99.9% accuracy."
        
        constraints = analyzer.identify_constraints(problem_text)
        
        assert len(constraints) > 0
        assert any(c.type == "quality" for c in constraints)
    
    def test_identify_technical_constraints(self, analyzer):
        """Test identifying technical constraints."""
        problem_text = "The solution must integrate with our existing platform and be compatible with legacy systems."
        
        constraints = analyzer.identify_constraints(problem_text)
        
        assert len(constraints) > 0
        assert any(c.type == "technical" for c in constraints)
    
    def test_identify_multiple_constraints(self, analyzer):
        """Test identifying multiple constraint types."""
        problem_text = """
        Build a high-performance system within 6 months with a budget of $100,000.
        It must integrate with existing infrastructure and maintain 99.9% uptime.
        """
        
        constraints = analyzer.identify_constraints(problem_text)
        
        assert len(constraints) >= 3
        constraint_types = {c.type for c in constraints}
        assert "time" in constraint_types
        assert "resource" in constraint_types


# ============================================================================
# SUCCESS CRITERIA GENERATION TESTS
# ============================================================================

class TestSuccessCriteriaGeneration:
    """Test success criteria generation."""
    
    def test_generate_research_criteria(self, analyzer):
        """Test generating criteria for research problems."""
        from sovereign_data_models import ProblemDefinition, generate_id
        
        problem = ProblemDefinition(
            id=generate_id("problem"),
            title="Research Problem",
            description="Investigate new approaches",
            problem_type=ProblemType.RESEARCH,
            domain_context=DomainContext(domain="research"),
            complexity_score=ComplexityScore(
                cognitive_complexity=6.0,
                computational_complexity=5.0,
                domain_complexity=7.0,
                integration_complexity=5.0,
                overall_complexity=5.75,
                explanation="Research complexity"
            ),
            constraints=[],
            success_criteria=[],
            stakeholders=[],
            resources_available={}
        )
        
        criteria = analyzer.generate_success_criteria(problem)
        
        assert len(criteria) > 0
        assert any("research" in c.description.lower() or "documented" in c.description.lower() 
                  for c in criteria)
    
    def test_generate_implementation_criteria(self, analyzer):
        """Test generating criteria for implementation problems."""
        from sovereign_data_models import ProblemDefinition, generate_id
        
        problem = ProblemDefinition(
            id=generate_id("problem"),
            title="Implementation Problem",
            description="Build a new feature",
            problem_type=ProblemType.IMPLEMENTATION,
            domain_context=DomainContext(domain="software_engineering"),
            complexity_score=ComplexityScore(
                cognitive_complexity=5.0,
                computational_complexity=6.0,
                domain_complexity=5.0,
                integration_complexity=6.0,
                overall_complexity=5.5,
                explanation="Implementation complexity"
            ),
            constraints=[],
            success_criteria=[],
            stakeholders=[],
            resources_available={}
        )
        
        criteria = analyzer.generate_success_criteria(problem)
        
        assert len(criteria) > 0
        assert any("test" in c.description.lower() or "implementation" in c.description.lower() 
                  for c in criteria)
    
    def test_generate_complexity_based_criteria(self, analyzer):
        """Test generating criteria based on complexity."""
        from sovereign_data_models import ProblemDefinition, generate_id
        
        problem = ProblemDefinition(
            id=generate_id("problem"),
            title="Complex Problem",
            description="Solve a complex challenge",
            problem_type=ProblemType.DESIGN,
            domain_context=DomainContext(domain="general"),
            complexity_score=ComplexityScore(
                cognitive_complexity=8.0,
                computational_complexity=8.0,
                domain_complexity=8.0,
                integration_complexity=8.0,
                overall_complexity=8.0,
                explanation="High complexity"
            ),
            constraints=[],
            success_criteria=[],
            stakeholders=[],
            resources_available={}
        )
        
        criteria = analyzer.generate_success_criteria(problem)
        
        assert len(criteria) >= 2  # Should have type-based + complexity-based
        assert any("complexity" in c.description.lower() for c in criteria)


# ============================================================================
# VALIDATION TESTS
# ============================================================================

class TestProblemValidation:
    """Test problem definition validation."""
    
    def test_validate_complete_problem(self, analyzer):
        """Test validating a complete problem definition."""
        from sovereign_data_models import ProblemDefinition, generate_id
        
        problem = ProblemDefinition(
            id=generate_id("problem"),
            title="Valid Problem",
            description="This is a valid problem description with sufficient detail.",
            problem_type=ProblemType.ANALYSIS,
            domain_context=DomainContext(domain="data_science"),
            complexity_score=ComplexityScore(
                cognitive_complexity=5.0,
                computational_complexity=5.0,
                domain_complexity=5.0,
                integration_complexity=5.0,
                overall_complexity=5.0,
                explanation="Valid"
            ),
            constraints=[],
            success_criteria=[
                SuccessCriterion(
                    id="sc1",
                    description="Analysis complete",
                    metric="completeness",
                    threshold=0.9,
                    validation_method="review"
                )
            ],
            stakeholders=[],
            resources_available={}
        )
        
        is_valid, errors = analyzer.validate_problem_definition(problem)
        
        assert is_valid is True
        assert len(errors) == 0
    
    def test_validate_missing_title(self, analyzer):
        """Test validating problem with missing title."""
        from sovereign_data_models import ProblemDefinition, generate_id
        
        problem = ProblemDefinition(
            id=generate_id("problem"),
            title="",
            description="Valid description",
            problem_type=ProblemType.ANALYSIS,
            domain_context=DomainContext(domain="general"),
            complexity_score=ComplexityScore(
                cognitive_complexity=5.0,
                computational_complexity=5.0,
                domain_complexity=5.0,
                integration_complexity=5.0,
                overall_complexity=5.0,
                explanation="Valid"
            ),
            constraints=[],
            success_criteria=[
                SuccessCriterion(
                    id="sc1",
                    description="Complete",
                    metric="completeness",
                    threshold=0.9,
                    validation_method="review"
                )
            ],
            stakeholders=[],
            resources_available={}
        )
        
        is_valid, errors = analyzer.validate_problem_definition(problem)
        
        assert is_valid is False
        assert any("title" in error.lower() for error in errors)
    
    def test_validate_short_description(self, analyzer):
        """Test validating problem with too short description."""
        from sovereign_data_models import ProblemDefinition, generate_id
        
        problem = ProblemDefinition(
            id=generate_id("problem"),
            title="Valid Title",
            description="Short",
            problem_type=ProblemType.ANALYSIS,
            domain_context=DomainContext(domain="general"),
            complexity_score=ComplexityScore(
                cognitive_complexity=5.0,
                computational_complexity=5.0,
                domain_complexity=5.0,
                integration_complexity=5.0,
                overall_complexity=5.0,
                explanation="Valid"
            ),
            constraints=[],
            success_criteria=[
                SuccessCriterion(
                    id="sc1",
                    description="Complete",
                    metric="completeness",
                    threshold=0.9,
                    validation_method="review"
                )
            ],
            stakeholders=[],
            resources_available={}
        )
        
        is_valid, errors = analyzer.validate_problem_definition(problem)
        
        assert is_valid is False
        assert any("description" in error.lower() for error in errors)
    
    def test_validate_missing_success_criteria(self, analyzer):
        """Test validating problem with no success criteria."""
        from sovereign_data_models import ProblemDefinition, generate_id
        
        problem = ProblemDefinition(
            id=generate_id("problem"),
            title="Valid Title",
            description="This is a valid description with enough detail.",
            problem_type=ProblemType.ANALYSIS,
            domain_context=DomainContext(domain="general"),
            complexity_score=ComplexityScore(
                cognitive_complexity=5.0,
                computational_complexity=5.0,
                domain_complexity=5.0,
                integration_complexity=5.0,
                overall_complexity=5.0,
                explanation="Valid"
            ),
            constraints=[],
            success_criteria=[],
            stakeholders=[],
            resources_available={}
        )
        
        is_valid, errors = analyzer.validate_problem_definition(problem)
        
        assert is_valid is False
        assert any("success" in error.lower() or "criterion" in error.lower() for error in errors)


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
